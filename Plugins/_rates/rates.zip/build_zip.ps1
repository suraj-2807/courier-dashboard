$zipPath = 'e:\PrinceExp Dashboard\courier-admin\Plugins\_rates\rates.zip'
if (Test-Path $zipPath) { [System.IO.File]::Delete($zipPath) }
Add-Type -AssemblyName System.IO.Compression.FileSystem
$sourceDir = 'e:\PrinceExp Dashboard\courier-admin\Plugins\_rates'
$tempDir = [System.IO.Path]::Combine([System.IO.Path]::GetTempPath(), [System.Guid]::NewGuid().ToString())
New-Item -ItemType Directory -Path $tempDir | Out-Null
Get-ChildItem -Path $sourceDir -Exclude 'rates.zip','storage','vendor' | ForEach-Object {
    Copy-Item -Path $_.FullName -Destination $tempDir -Recurse
}
[System.IO.Compression.ZipFile]::CreateFromDirectory($tempDir, $zipPath)
Remove-Item -Path $tempDir -Recurse -Force
$fi = Get-Item $zipPath
Write-Host "Created rates.zip, size:" $fi.Length "bytes, time:" $fi.LastWriteTime

<?php
// Copy to config.php and enter your Hostinger database password.
// Keep config.php private; never commit or publish it.
return [
    'db' => [
        'host' => 'localhost',
        'name' => 'u364134727_rates',
        'user' => 'u364134727_rates_user',
        'pass' => 'yK1&HXN5>',
        'charset' => 'utf8mb4',
    ],
    // Change this before deployment.
    'admin_password' => 'PacificRates@2026',
    // Generate a long random string for API access.
    'api_key' => 'CHANGE_THIS_TO_A_LONG_RANDOM_API_KEY',
    'upload_dir' => __DIR__ . '/storage/uploads',
    'max_upload_mb' => 30,
];
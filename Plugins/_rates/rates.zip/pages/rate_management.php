<?php
// Rate Management Page — edit rates across vendors
$vendors = $pdo->query("SELECT * FROM vendors WHERE is_active = 1 ORDER BY name")->fetchAll();
$selectedVendor = trim($_GET['vendor'] ?? '');
$selectedSheet = trim($_GET['sheet'] ?? '');

$vendorObj = null;
$worksheets = [];
$batchId = null;

if ($selectedVendor) {
    $vendorObj = getVendorBySlug($pdo, $selectedVendor);
    if ($vendorObj) {
        $batchId = getActiveBatchId($pdo, (int)$vendorObj['id']);
        if ($batchId) {
            $worksheets = getVendorWorksheets($pdo, (int)$vendorObj['id'], $batchId);
            if (empty($worksheets)) {
                // Detect from data
                $st = $pdo->prepare("SELECT DISTINCT sheet_name, rate_type FROM vendor_rate_rows WHERE vendor_id = ? AND batch_id = ?");
                $st->execute([(int)$vendorObj['id'], $batchId]);
                foreach ($st->fetchAll() as $row) {
                    $worksheets[] = ['sheet_name' => $row['sheet_name'], 'sheet_type' => $row['rate_type']];
                }
            }
        }
    }
}
?>

<div class="mb-24">
    <h2>Rate Management</h2>
    <p class="text-muted text-sm">Edit, add, and delete rate records across all vendors</p>
</div>

<div class="card">
    <form class="form-inline" method="get">
        <input type="hidden" name="page" value="rate_management">
        <div class="form-group">
            <label class="form-label">Vendor</label>
            <select class="form-control" name="vendor" onchange="this.form.submit()" style="min-width:200px;">
                <option value="">Select vendor...</option>
                <?php foreach ($vendors as $v): ?>
                <option value="<?= h($v['slug']) ?>" <?= $selectedVendor === $v['slug'] ? 'selected' : '' ?>><?= h($v['name']) ?></option>
                <?php endforeach; ?>
            </select>
        </div>
        <?php if ($worksheets): ?>
        <div class="form-group">
            <label class="form-label">Worksheet</label>
            <select class="form-control" name="sheet" onchange="this.form.submit()" style="min-width:200px;">
                <option value="">Select sheet...</option>
                <?php foreach ($worksheets as $ws): ?>
                <option value="<?= h($ws['sheet_name']) ?>" <?= $selectedSheet === $ws['sheet_name'] ? 'selected' : '' ?>><?= h($ws['sheet_name']) ?> (<?= h($ws['sheet_type']) ?>)</option>
                <?php endforeach; ?>
            </select>
        </div>
        <?php endif; ?>
    </form>
</div>

<?php if ($vendorObj && $batchId && $selectedSheet): ?>
<?php
    // Load data for the selected sheet
    $sheetType = 'regular';
    foreach ($worksheets as $ws) {
        if ($ws['sheet_name'] === $selectedSheet) { $sheetType = $ws['sheet_type']; break; }
    }

    $pagination = paginationParams();
    $searchQuery = trim($_GET['q'] ?? '');
    $vendorId = (int)$vendorObj['id'];

    if ($sheetType === 'zones') {
        $where = "vendor_id = ? AND batch_id = ?";
        $args = [$vendorId, $batchId];
        if ($searchQuery !== '') { $where .= " AND (country LIKE ? OR postcode LIKE ? OR zone LIKE ?)"; $args[] = "%$searchQuery%"; $args[] = "%$searchQuery%"; $args[] = "%$searchQuery%"; }
        $total = $pdo->prepare("SELECT COUNT(*) FROM vendor_zone_rows WHERE $where"); $total->execute($args); $total = (int)$total->fetchColumn();
        $st = $pdo->prepare("SELECT * FROM vendor_zone_rows WHERE $where ORDER BY country, postcode LIMIT {$pagination['per_page']} OFFSET {$pagination['offset']}");
        $st->execute($args);
        $rows = $st->fetchAll();
?>
    <div class="card card-flush mt-16">
        <div class="card-header">
            <h3><?= h($selectedSheet) ?> — Zone Mappings <span class="text-muted text-sm">(<?= number_format($total) ?>)</span></h3>
            <div class="flex gap-8">
                <button class="btn btn-outline btn-sm" onclick="openAddModal(<?= $vendorId ?>, <?= $batchId ?>, 'zones')">+ Add</button>
                <button class="btn btn-outline btn-sm" onclick="exportTableCSV('mgmt-table', 'zone_data.csv')">⬇ Export</button>
            </div>
        </div>
        <div style="padding:0 24px">
            <form class="filter-bar" method="get">
                <input type="hidden" name="page" value="rate_management">
                <input type="hidden" name="vendor" value="<?= h($selectedVendor) ?>">
                <input type="hidden" name="sheet" value="<?= h($selectedSheet) ?>">
                <div class="search-input"><input class="form-control" name="q" placeholder="Search..." value="<?= h($searchQuery) ?>"></div>
                <button type="submit" class="btn btn-primary btn-sm">Search</button>
            </form>
        </div>
        <div class="card-body table-wrapper">
            <table class="data-table" id="mgmt-table">
                <thead><tr><th class="sortable">Country</th><th class="sortable">Postcode</th><th class="sortable">Zone</th><th>Town/City</th><th>Status</th><th>Actions</th></tr></thead>
                <tbody>
                <?php foreach ($rows as $r): ?>
                <tr>
                    <td><?= h($r['country']) ?></td>
                    <td class="font-mono"><?= h($r['postcode']) ?></td>
                    <td class="editable-cell" onclick="makeEditable(this, <?= $r['id'] ?>, 'zone', 'vendor_zone_rows')"><?= h($r['zone'] ?? '—') ?></td>
                    <td class="editable-cell" onclick="makeEditable(this, <?= $r['id'] ?>, 'town_city', 'vendor_zone_rows')"><?= h($r['town_city'] ?? '—') ?></td>
                    <td><?= ($r['is_manually_modified'] ?? 0) ? '<span class="badge-modified">edited</span>' : '<span class="badge badge-neutral">imported</span>' ?></td>
                    <td><button class="btn btn-ghost btn-sm" style="color:var(--accent-danger)" onclick="deleteRecord(<?= $r['id'] ?>, 'vendor_zone_rows', this.closest('tr'))">🗑</button></td>
                </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
            <?php include __DIR__ . '/_pagination.php'; ?>
        </div>
    </div>
<?php } else { ?>
    <?php
        $where = "vendor_id = ? AND batch_id = ? AND sheet_name = ?";
        $args = [$vendorId, $batchId, $selectedSheet];
        if ($searchQuery !== '') { $where .= " AND (service_code LIKE ? OR country LIKE ? OR service_name LIKE ?)"; $args[] = "%$searchQuery%"; $args[] = "%$searchQuery%"; $args[] = "%$searchQuery%"; }
        $total = $pdo->prepare("SELECT COUNT(*) FROM vendor_rate_rows WHERE $where"); $total->execute($args); $total = (int)$total->fetchColumn();
        $st = $pdo->prepare("SELECT * FROM vendor_rate_rows WHERE $where ORDER BY service_code, country, weight_kg LIMIT {$pagination['per_page']} OFFSET {$pagination['offset']}");
        $st->execute($args);
        $rows = $st->fetchAll();
    ?>
    <div class="card card-flush mt-16">
        <div class="card-header">
            <h3><?= h($selectedSheet) ?> — Rates <span class="text-muted text-sm">(<?= number_format($total) ?>)</span></h3>
            <div class="flex gap-8">
                <button class="btn btn-outline btn-sm" onclick="openAddModal(<?= $vendorId ?>, <?= $batchId ?>, '<?= h($sheetType) ?>')">+ Add</button>
                <button class="btn btn-outline btn-sm" onclick="exportTableCSV('mgmt-table', 'rate_data.csv')">⬇ Export</button>
            </div>
        </div>
        <div style="padding:0 24px">
            <form class="filter-bar" method="get">
                <input type="hidden" name="page" value="rate_management">
                <input type="hidden" name="vendor" value="<?= h($selectedVendor) ?>">
                <input type="hidden" name="sheet" value="<?= h($selectedSheet) ?>">
                <div class="search-input"><input class="form-control" name="q" placeholder="Search service, country..." value="<?= h($searchQuery) ?>"></div>
                <button type="submit" class="btn btn-primary btn-sm">Search</button>
            </form>
        </div>
        <div class="card-body table-wrapper">
            <table class="data-table" id="mgmt-table">
                <thead><tr>
                    <th class="sortable">Service Code</th><th>Service</th><th class="sortable">Country</th>
                    <th class="sortable">Weight</th><th>kg</th>
                    <?php if ($sheetType === 'zonewise'): ?><th class="sortable">Zone</th><?php endif; ?>
                    <th class="sortable">Rate</th><th>Raw</th><th>Transit</th><th>Status</th><th>Actions</th>
                </tr></thead>
                <tbody>
                <?php foreach ($rows as $r): ?>
                <tr>
                    <td class="font-mono editable-cell" onclick="makeEditable(this, <?= $r['id'] ?>, 'service_code', 'vendor_rate_rows')"><?= h($r['service_code']) ?></td>
                    <td class="text-sm editable-cell" onclick="makeEditable(this, <?= $r['id'] ?>, 'service_name', 'vendor_rate_rows')"><?= h($r['service_name'] ?? '—') ?></td>
                    <td class="editable-cell" onclick="makeEditable(this, <?= $r['id'] ?>, 'country', 'vendor_rate_rows')"><?= h($r['country'] ?? '—') ?></td>
                    <td class="text-sm"><?= h($r['weight_label'] ?? '—') ?></td>
                    <td class="font-mono"><?= $r['weight_kg'] !== null ? $r['weight_kg'] : '—' ?></td>
                    <?php if ($sheetType === 'zonewise'): ?><td><?= h($r['zone'] ?? '—') ?></td><?php endif; ?>
                    <td class="rate-cell editable-cell" onclick="makeEditable(this, <?= $r['id'] ?>, 'rate', 'vendor_rate_rows')"><?= formatRate($r['rate'], $r['rate_raw']) ?></td>
                    <td class="text-sm text-muted"><?= h($r['rate_raw'] ?? '') ?></td>
                    <td class="text-sm editable-cell" onclick="makeEditable(this, <?= $r['id'] ?>, 'transit_time', 'vendor_rate_rows')"><?= h($r['transit_time'] ?? '—') ?></td>
                    <td><?= ($r['is_manually_modified'] ?? 0) ? '<span class="badge-modified">edited</span>' : '<span class="badge badge-neutral">imported</span>' ?></td>
                    <td><button class="btn btn-ghost btn-sm" style="color:var(--accent-danger)" onclick="deleteRecord(<?= $r['id'] ?>, 'vendor_rate_rows', this.closest('tr'))">🗑</button></td>
                </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
            <?php include __DIR__ . '/_pagination.php'; ?>
        </div>
    </div>
<?php } ?>

<!-- Add Record Modal (same as vendor_detail) -->
<div id="add-record-modal" class="modal-overlay" style="display:none">
    <div class="modal">
        <div class="modal-header"><h3>Add Record</h3><button class="modal-close" onclick="closeAddModal()">✕</button></div>
        <form id="add-record-form">
            <input type="hidden" name="vendor_id" id="add-vendor-id" value="<?= $vendorId ?>">
            <input type="hidden" name="batch_id" id="add-batch-id" value="<?= $batchId ?>">
            <input type="hidden" name="sheet_type" id="add-sheet-type" value="">
            <input type="hidden" name="sheet_name" value="<?= h($selectedSheet) ?>">
            <div id="add-rate-fields">
                <div class="form-row"><div class="form-group"><label class="form-label">Service Code</label><input class="form-control" name="service_code"></div><div class="form-group"><label class="form-label">Service Name</label><input class="form-control" name="service_name"></div></div>
                <div class="form-row"><div class="form-group"><label class="form-label">Country</label><input class="form-control" name="country"></div><div class="form-group"><label class="form-label">Weight Label</label><input class="form-control" name="weight_label"></div></div>
                <div class="form-row"><div class="form-group"><label class="form-label">Weight (kg)</label><input class="form-control" name="weight_kg" type="number" step="0.0001"></div><div class="form-group"><label class="form-label">Zone</label><input class="form-control" name="zone"></div></div>
                <div class="form-row"><div class="form-group"><label class="form-label">Rate</label><input class="form-control" name="rate" type="number" step="0.01"></div><div class="form-group"><label class="form-label">Transit</label><input class="form-control" name="transit_time"></div></div>
            </div>
            <div id="add-zone-fields" class="hidden">
                <div class="form-row"><div class="form-group"><label class="form-label">Country</label><input class="form-control" name="zone_country"></div><div class="form-group"><label class="form-label">Postcode</label><input class="form-control" name="postcode"></div></div>
                <div class="form-row"><div class="form-group"><label class="form-label">Zone</label><input class="form-control" name="zone_value"></div><div class="form-group"><label class="form-label">Town/City</label><input class="form-control" name="town_city"></div></div>
            </div>
            <div class="flex gap-8 mt-16"><button type="button" class="btn btn-primary" onclick="submitAddRecord()">Add Record</button><button type="button" class="btn btn-ghost" onclick="closeAddModal()">Cancel</button></div>
        </form>
    </div>
</div>

<?php elseif ($vendorObj && !$batchId): ?>
    <div class="empty-state card mt-16"><div class="empty-icon">📭</div><p>No active import version for this vendor. Upload a workbook first.</p></div>
<?php elseif (!$selectedVendor): ?>
    <div class="empty-state card mt-16"><div class="empty-icon">👆</div><p>Select a vendor to manage rates.</p></div>
<?php endif; ?>

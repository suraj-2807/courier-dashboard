<?php
// Rate Calculator Page
$vendors = $pdo->query("SELECT * FROM vendors WHERE is_active = 1 ORDER BY name")->fetchAll();
$selectedVendor = trim($_GET['vendor'] ?? ($_POST['vendor'] ?? ''));
$calcResult = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['calculate'])) {
    $vendor = trim($_POST['vendor'] ?? '');
    $country = trim($_POST['country'] ?? '');
    $serviceCode = trim($_POST['service_code'] ?? '');
    $weightKg = (float)($_POST['weight_kg'] ?? 0);
    $postcode = trim($_POST['postcode'] ?? '');

    if ($vendor && $country && $serviceCode && $weightKg > 0) {
        $v = getVendorBySlug($pdo, $vendor);
        if ($v) {
            $batchId = getActiveBatchId($pdo, (int)$v['id']);
            if ($batchId) {
                $calc = new RateCalculator($pdo, (int)$v['id'], $batchId, $v['name']);
                $calcResult = $calc->calculate($country, $serviceCode, $weightKg, $postcode ?: null);
            } else {
                $calcResult = ['success' => false, 'error' => 'No active import version found for this vendor.'];
            }
        } else {
            $calcResult = ['success' => false, 'error' => 'Vendor not found.'];
        }
    } else {
        $calcResult = ['success' => false, 'error' => 'Please fill in all required fields (vendor, country, service, weight).'];
    }
}

// Get countries/services for selected vendor
$vendorCountries = [];
$vendorServices = [];
if ($selectedVendor) {
    $v = getVendorBySlug($pdo, $selectedVendor);
    if ($v) {
        $batchId = getActiveBatchId($pdo, (int)$v['id']);
        if ($batchId) {
            $calc = new RateCalculator($pdo, (int)$v['id'], $batchId);
            $vendorCountries = $calc->getAvailableCountries();
            $vendorServices = $calc->getAvailableServices();
        }
    }
}
?>

<div class="mb-24">
    <h2>Rate Calculator</h2>
    <p class="text-muted text-sm">Calculate shipping rates based on vendor rate data</p>
</div>

<div style="display:grid; grid-template-columns: 1fr 1fr; gap:24px;">
    <div class="card">
        <h3 class="mb-16">📦 Shipment Details</h3>
        <form method="post" id="calc-form" action="?page=rate_calculator">
            <div class="form-group">
                <label class="form-label">Vendor *</label>
                <select class="form-control" name="vendor" required onchange="this.form.action='?page=rate_calculator&vendor='+this.value; this.form.method='get'; this.form.submit();">
                    <option value="">Select vendor...</option>
                    <?php foreach ($vendors as $v): ?>
                    <option value="<?= h($v['slug']) ?>" <?= $selectedVendor === $v['slug'] ? 'selected' : '' ?>><?= h($v['name']) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div class="form-group">
                <label class="form-label">Destination Country *</label>
                <?php if ($vendorCountries): ?>
                <select class="form-control" name="country" required>
                    <option value="">Select country...</option>
                    <?php foreach ($vendorCountries as $c): ?>
                    <option value="<?= h($c) ?>" <?= ($_POST['country'] ?? '') === $c ? 'selected' : '' ?>><?= h($c) ?></option>
                    <?php endforeach; ?>
                </select>
                <?php else: ?>
                <input class="form-control" name="country" placeholder="e.g. USA" value="<?= h($_POST['country'] ?? '') ?>" required>
                <?php endif; ?>
            </div>

            <div class="form-group">
                <label class="form-label">Service *</label>
                <?php if ($vendorServices): ?>
                <select class="form-control" name="service_code" required>
                    <option value="">Select service...</option>
                    <?php foreach ($vendorServices as $s): ?>
                    <option value="<?= h($s['service_code']) ?>" <?= ($_POST['service_code'] ?? '') === $s['service_code'] ? 'selected' : '' ?>>
                        <?= h($s['service_code']) ?><?= $s['service_name'] ? ' — ' . h($s['service_name']) : '' ?> (<?= h($s['rate_type']) ?>)
                    </option>
                    <?php endforeach; ?>
                </select>
                <?php else: ?>
                <input class="form-control" name="service_code" placeholder="e.g. PXC-EX NY SELF" value="<?= h($_POST['service_code'] ?? '') ?>" required>
                <?php endif; ?>
            </div>

            <div class="form-row">
                <div class="form-group">
                    <label class="form-label">Weight (kg) *</label>
                    <input class="form-control" name="weight_kg" type="number" step="0.01" min="0.01" placeholder="e.g. 1.25" value="<?= h($_POST['weight_kg'] ?? '') ?>" required>
                </div>
                <div class="form-group">
                    <label class="form-label">Postcode / ZIP</label>
                    <input class="form-control" name="postcode" placeholder="e.g. 10001" value="<?= h($_POST['postcode'] ?? '') ?>">
                    <p class="form-hint">Required for zone-wise services</p>
                </div>
            </div>

            <button type="submit" name="calculate" class="btn btn-primary btn-lg btn-block mt-16">
                🔍 Calculate Rate
            </button>
        </form>
    </div>

    <div>
        <?php if ($calcResult): ?>
            <?php if ($calcResult['success']): ?>
                <div class="calc-result">
                    <h3>💰 Rate Calculation Result</h3>
                    <div class="final-rate"><?= h($calcResult['currency'] ?? 'INR') ?> <?= number_format($calcResult['final_rate'], 2) ?></div>
                    <div class="calc-breakdown">
                        <div class="breakdown-item">
                            <div class="breakdown-label">Vendor</div>
                            <div class="breakdown-value"><?= h($calcResult['vendor']) ?></div>
                        </div>
                        <div class="breakdown-item">
                            <div class="breakdown-label">Service</div>
                            <div class="breakdown-value"><?= h($calcResult['service'] ?? $calcResult['service_code']) ?></div>
                        </div>
                        <div class="breakdown-item">
                            <div class="breakdown-label">Country</div>
                            <div class="breakdown-value"><?= h($calcResult['country']) ?></div>
                        </div>
                        <?php if (!empty($calcResult['postcode'])): ?>
                        <div class="breakdown-item">
                            <div class="breakdown-label">Postcode</div>
                            <div class="breakdown-value"><?= h($calcResult['postcode']) ?></div>
                        </div>
                        <?php endif; ?>
                        <?php if (!empty($calcResult['zone'])): ?>
                        <div class="breakdown-item">
                            <div class="breakdown-label">Zone</div>
                            <div class="breakdown-value"><?= h($calcResult['zone']) ?></div>
                        </div>
                        <?php endif; ?>
                        <div class="breakdown-item">
                            <div class="breakdown-label">Rate Type</div>
                            <div class="breakdown-value"><?= h($calcResult['rate_type']) ?></div>
                        </div>
                        <div class="breakdown-item">
                            <div class="breakdown-label">Actual Weight</div>
                            <div class="breakdown-value"><?= $calcResult['actual_weight'] ?> kg</div>
                        </div>
                        <div class="breakdown-item">
                            <div class="breakdown-label">Chargeable Weight</div>
                            <div class="breakdown-value"><?= $calcResult['chargeable_weight'] ?> kg</div>
                        </div>
                        <div class="breakdown-item">
                            <div class="breakdown-label">Base Rate</div>
                            <div class="breakdown-value"><?= h($calcResult['currency'] ?? 'INR') ?> <?= number_format($calcResult['base_rate'], 2) ?></div>
                        </div>
                        <?php if (($calcResult['additional_weight_units'] ?? 0) > 0): ?>
                        <div class="breakdown-item">
                            <div class="breakdown-label">Additional Units</div>
                            <div class="breakdown-value"><?= $calcResult['additional_weight_units'] ?></div>
                        </div>
                        <div class="breakdown-item">
                            <div class="breakdown-label">Additional Charge</div>
                            <div class="breakdown-value"><?= h($calcResult['currency'] ?? 'INR') ?> <?= number_format($calcResult['additional_charge'], 2) ?></div>
                        </div>
                        <?php endif; ?>
                    </div>
                    <?php if (!empty($calcResult['calculation']['note'])): ?>
                    <div style="margin-top:16px; padding-top:16px; border-top:1px solid rgba(255,255,255,0.1); font-size:0.85rem; color:rgba(255,255,255,0.6);">
                        <strong>Method:</strong> <?= h($calcResult['calculation']['method'] ?? '') ?><br>
                        <?= h($calcResult['calculation']['note']) ?>
                    </div>
                    <?php endif; ?>
                    <div style="margin-top:12px; font-size:0.75rem; color:rgba(255,255,255,0.35);">Batch ID: <?= $calcResult['batch_id'] ?? 'N/A' ?></div>
                </div>
            <?php else: ?>
                <div class="calc-error">
                    <strong>⚠ Calculation Error</strong><br>
                    <?= h($calcResult['error']) ?>
                </div>
            <?php endif; ?>
        <?php else: ?>
            <div class="card" style="text-align:center; padding:48px;">
                <div style="font-size:4rem; opacity:0.2; margin-bottom:16px;">📊</div>
                <h3 class="text-muted">Enter shipment details</h3>
                <p class="text-muted text-sm">Select a vendor, enter destination and weight to calculate the shipping rate.</p>
            </div>
        <?php endif; ?>
    </div>
</div>

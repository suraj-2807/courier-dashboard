<?php
declare(strict_types=1);

// Available Services API Endpoint — Filter by Vendor and Destination Country
// Returns available shipping services and clean service codes for dependent dropdowns
require_once __DIR__ . '/_middleware.php';
require_once dirname(__DIR__) . '/includes/calculator.php';

$pdo = db();

try {
    $vendorSlug = trim((string)($_GET['vendor'] ?? ''));
    if ($vendorSlug === '') {
        apiRespond(400, ['success' => false, 'ok' => false, 'error' => "Parameter 'vendor' is required."]);
    }

    $v = getVendorBySlug($pdo, $vendorSlug);
    if (!$v) {
        apiRespond(404, ['success' => false, 'ok' => false, 'error' => "Vendor '{$vendorSlug}' not found."]);
    }

    $batchId = getActiveBatchId($pdo, (int)$v['id']);
    if (!$batchId) {
        apiRespond(404, ['success' => false, 'ok' => false, 'error' => "No active rate workbook found for vendor '{$vendorSlug}'."]);
    }

    $country = clean($_GET['country'] ?? null);
    $destination = clean($_GET['destination'] ?? null);

    $calc = new RateCalculator($pdo, (int)$v['id'], $batchId, $v['name']);
    $services = $calc->getAvailableServices($country, $destination);
    $destinationVariants = $country ? $calc->getDestinationVariants($country) : [];
    $isZonewiseCountry = $country ? $calc->isCountryZonewise($country) : false;

    $serviceCodes = array_values(array_unique(array_filter(array_column($services, 'service_code'))));

    apiRespond(200, [
        'success' => true,
        'ok' => true,
        'vendor' => [
            'name' => $v['name'],
            'slug' => $v['slug'],
            'batch_id' => $batchId
        ],
        'country' => $country,
        'destination' => $destination,
        'destination_variants' => $destinationVariants,
        'is_country_zonewise' => $isZonewiseCountry,
        'count' => count($serviceCodes),
        'service_codes' => $serviceCodes,
        'services' => $services
    ]);

} catch (Throwable $e) {
    apiRespond(500, ['success' => false, 'ok' => false, 'error' => 'Server error', 'detail' => $e->getMessage()]);
}

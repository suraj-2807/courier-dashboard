<?php
declare(strict_types=1);

// Automated Test Suite for Vendor Rate Management Portal
// Runnable directly from CLI, HTTP, or integrated into the admin portal (?page=tests)

if (session_status() === PHP_SESSION_NONE) session_start();

$isWeb = php_sapi_name() !== 'cli';
$inPortal = isset($pdo); // If included from index.php

if (!$inPortal) {
    require_once dirname(__DIR__) . '/includes/db.php';
    require_once dirname(__DIR__) . '/includes/helpers.php';
    require_once dirname(__DIR__) . '/includes/auth.php';
    require_once dirname(__DIR__) . '/includes/calculator.php';
    $pdo = db();
} else {
    require_once dirname(__DIR__) . '/includes/calculator.php';
}

class TestRunner {
    private array $results = [];
    private int $passed = 0;
    private int $failed = 0;

    public function test(string $name, callable $fn): void {
        try {
            $fn();
            $this->results[] = ['name' => $name, 'status' => 'PASS', 'message' => ''];
            $this->passed++;
        } catch (Throwable $e) {
            $this->results[] = ['name' => $name, 'status' => 'FAIL', 'message' => $e->getMessage()];
            $this->failed++;
        }
    }

    public function assert(bool $condition, string $msg = 'Assertion failed'): void {
        if (!$condition) throw new RuntimeException($msg);
    }

    public function assertEquals($expected, $actual, string $msg = ''): void {
        if ($expected !== $actual) {
            $expStr = var_export($expected, true);
            $actStr = var_export($actual, true);
            throw new RuntimeException($msg ?: "Expected {$expStr}, got {$actStr}");
        }
    }

    public function getResults(): array {
        return [
            'results' => $this->results,
            'passed' => $this->passed,
            'failed' => $this->failed,
            'total' => $this->passed + $this->failed
        ];
    }
}

$runner = new TestRunner();

// --- TEST GROUP 1: Helpers & Parsing ---
$runner->test('slugify transforms strings correctly', function() use ($runner) {
    $runner->assertEquals('pacific-express', slugify('Pacific Express'));
    $runner->assertEquals('dhl-express-uk', slugify('DHL Express (UK)!'));
    $runner->assertEquals('vendor', slugify(''));
    $runner->assertEquals('fedex-2026', slugify('FedEx #2026'));
});

$runner->test('numericRate parses numbers and handles dashes/nulls', function() use ($runner) {
    [$num, $raw] = numericRate('450.50');
    $runner->assertEquals(450.50, $num);

    [$num2, $raw2] = numericRate('₹ 1,200');
    $runner->assertEquals(1200.0, $num2);

    [$num3, $raw3] = numericRate('-');
    $runner->assertEquals(null, $num3);
    $runner->assertEquals('-', $raw3);

    [$num4, $raw4] = numericRate('N/A');
    $runner->assertEquals(null, $num4);
});

$runner->test('weightKg extracts kilograms accurately', function() use ($runner) {
    $runner->assertEquals(0.5, weightKg('500 Gms'));
    $runner->assertEquals(0.5, weightKg('Addl 500 Gms'));
    $runner->assertEquals(1.0, weightKg('1 Kg'));
    $runner->assertEquals(10.0, weightKg('10 Kgs++'));
    $runner->assertEquals(0.25, weightKg('250g'));
    $runner->assertEquals(null, weightKg('Invalid'));
});

$runner->test('isUnavailableRate correctly identifies unquoted rates', function() use ($runner) {
    $runner->assert(isUnavailableRate('-'));
    $runner->assert(isUnavailableRate('—'));
    $runner->assert(isUnavailableRate('N/A'));
    $runner->assert(isUnavailableRate(null));
    $runner->assert(!isUnavailableRate('450.00'));
    $runner->assert(!isUnavailableRate('0'));
});

// --- TEST GROUP 2: Database Schema & Connectivity ---
$runner->test('Database connection is functional', function() use ($runner, $pdo) {
    $val = $pdo->query("SELECT 1")->fetchColumn();
    $runner->assertEquals(1, (int)$val);
});

$runner->test('Core rate tables exist and are readable', function() use ($runner, $pdo) {
    $tables = ['vendors', 'import_batches', 'vendor_rate_rows', 'vendor_zone_rows', 'vendor_country_services'];
    foreach ($tables as $t) {
        $st = $pdo->query("SELECT COUNT(*) FROM `{$t}`");
        $runner->assert($st !== false, "Table {$t} query failed");
    }
});

// --- TEST GROUP 3: Rate Calculation Unit Logic ---
$runner->test('RateCalculator handles zero or negative weights properly', function() use ($runner, $pdo) {
    // Look for any vendor
    $vendor = $pdo->query("SELECT id, name FROM vendors LIMIT 1")->fetch();
    if ($vendor) {
        $batchId = getActiveBatchId($pdo, (int)$vendor['id']) ?? 1;
        $calc = new RateCalculator($pdo, (int)$vendor['id'], $batchId, $vendor['name']);
        $res = $calc->calculate('USA', 'PXC-EX NY SELF', 0);
        $runner->assertEquals(false, $res['success']);
        $runner->assert(str_contains($res['error'], 'Weight must be greater than 0'));
    }
});

$runner->test('RateCalculator handles missing country or service gracefully', function() use ($runner, $pdo) {
    $vendor = $pdo->query("SELECT id, name FROM vendors LIMIT 1")->fetch();
    if ($vendor) {
        $batchId = getActiveBatchId($pdo, (int)$vendor['id']) ?? 1;
        $calc = new RateCalculator($pdo, (int)$vendor['id'], $batchId, $vendor['name']);
        $res1 = $calc->calculate('', 'PXC-EX NY SELF', 1.0);
        $runner->assertEquals(false, $res1['success']);
        $runner->assert(str_contains($res1['error'], 'country is required'));

        $res2 = $calc->calculate('USA', '', 1.0);
        $runner->assertEquals(false, $res2['success']);
        $runner->assert(str_contains($res2['error'], 'Service code is required'));
    }
});

// --- TEST GROUP 4: Security & Authentication ---
$runner->test('Auth check rejects invalid API keys', function() use ($runner) {
    $config = getConfig();
    $validKey = (string)$config['api_key'];
    $invalidKey = 'wrong_test_key_xyz_123';
    $runner->assert(!hash_equals($validKey, $invalidKey));
    $runner->assert(hash_equals($validKey, $validKey));
});

$report = $runner->getResults();

// If run from CLI, print text summary
if (!$isWeb) {
    echo "===========================================\n";
    echo "Vendor Rate Management Portal Test Suite\n";
    echo "===========================================\n";
    foreach ($report['results'] as $r) {
        $mark = $r['status'] === 'PASS' ? ' [✓ PASS] ' : ' [✕ FAIL] ';
        echo $mark . $r['name'] . "\n";
        if ($r['message']) echo "    Error: " . $r['message'] . "\n";
    }
    echo "-------------------------------------------\n";
    echo "Total: {$report['total']} | Passed: {$report['passed']} | Failed: {$report['failed']}\n";
    echo "===========================================\n";
    exit($report['failed'] > 0 ? 1 : 0);
}
?>

<!-- HTML View for Test Suite inside Portal -->
<div class="flex-between mb-24">
    <div>
        <h2>System Automated Test Suite</h2>
        <p class="text-muted text-sm">Comprehensive unit & regression tests validating helpers, database schema, rate calculator, and security</p>
    </div>
    <div>
        <?php if ($report['failed'] === 0): ?>
            <span class="badge badge-success" style="font-size:0.95rem; padding:6px 14px;">All <?= $report['total'] ?> Tests Passed ✓</span>
        <?php else: ?>
            <span class="badge badge-danger" style="font-size:0.95rem; padding:6px 14px;"><?= $report['failed'] ?> Failed / <?= $report['total'] ?> Total</span>
        <?php endif; ?>
    </div>
</div>

<div class="stats-grid mb-24">
    <div class="stat-card blue">
        <div class="stat-label">Total Test Cases</div>
        <div class="stat-value"><?= $report['total'] ?></div>
        <div class="stat-icon">🧪</div>
    </div>
    <div class="stat-card green">
        <div class="stat-label">Passed</div>
        <div class="stat-value"><?= $report['passed'] ?></div>
        <div class="stat-icon">✓</div>
    </div>
    <div class="stat-card <?= $report['failed'] > 0 ? 'red' : 'green' ?>">
        <div class="stat-label">Failed</div>
        <div class="stat-value"><?= $report['failed'] ?></div>
        <div class="stat-icon"><?= $report['failed'] > 0 ? '✕' : '✓' ?></div>
    </div>
</div>

<div class="card card-flush">
    <div class="card-header">
        <h3>Test Case Execution Details</h3>
        <a href="?page=tests" class="btn btn-outline btn-sm">↻ Re-run All Tests</a>
    </div>
    <div class="table-wrapper">
        <table class="data-table">
            <thead>
                <tr>
                    <th style="width:50px;">#</th>
                    <th>Test Description</th>
                    <th style="width:120px;">Result</th>
                    <th>Details</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($report['results'] as $i => $r): ?>
                    <tr>
                        <td class="font-mono text-muted"><?= $i + 1 ?></td>
                        <td><strong><?= h($r['name']) ?></strong></td>
                        <td>
                            <?php if ($r['status'] === 'PASS'): ?>
                                <span class="badge badge-success">✓ PASS</span>
                            <?php else: ?>
                                <span class="badge badge-danger">✕ FAIL</span>
                            <?php endif; ?>
                        </td>
                        <td>
                            <?php if ($r['message']): ?>
                                <span class="text-danger font-mono text-sm"><?= h($r['message']) ?></span>
                            <?php else: ?>
                                <span class="text-muted text-sm">Assertion verified</span>
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>

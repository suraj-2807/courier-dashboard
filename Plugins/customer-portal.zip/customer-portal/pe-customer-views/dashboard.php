<?php
if (!defined('ABSPATH')) exit;
$cust = pe_cp_get_user();
global $wpdb;

// Quick stats
$customer_name = $wpdb->esc_like($cust['name']);
$customer_phone = $wpdb->esc_like($cust['phone'] ?? '');
$where_cust = $wpdb->prepare(
    "(a.SNAME LIKE %s OR a.SPHONE1 LIKE %s OR a.CUSTNAME LIKE %s)",
    '%' . $customer_name . '%',
    '%' . $customer_phone . '%',
    '%' . $customer_name . '%'
);
$_st = "(SELECT ph.activity FROM parcel_history ph WHERE ph.AWBNO = a.AWBNO ORDER BY ph.date DESC, ph.time DESC LIMIT 1)";
$ts = intval($wpdb->get_var("SELECT COUNT(*) FROM AWBENTRY a WHERE $where_cust"));
$dc = intval($wpdb->get_var("SELECT COUNT(*) FROM AWBENTRY a WHERE $where_cust AND LOWER(COALESCE($_st, '')) LIKE '%delivered%'"));
$tc = intval($wpdb->get_var("SELECT COUNT(*) FROM AWBENTRY a WHERE $where_cust AND (LOWER(COALESCE($_st, '')) LIKE '%transit%' OR LOWER(COALESCE($_st, '')) LIKE '%departed%')"));
?>
<style>
#wpadminbar{display:none!important}html{margin-top:0!important}
*,*::before,*::after{box-sizing:border-box}

@keyframes cp-fadeIn{from{opacity:0}to{opacity:1}}
@keyframes cp-fadeUp{from{opacity:0;transform:translateY(20px)}to{opacity:1;transform:translateY(0)}}
@keyframes cp-slideIn{from{transform:translateX(100%)}to{transform:translateX(0)}}
@keyframes cp-shimmer{0%{background-position:-400px 0}100%{background-position:400px 0}}
@keyframes cp-countUp{from{opacity:0;transform:translateY(10px)}to{opacity:1;transform:translateY(0)}}
@keyframes cp-spin{to{transform:rotate(360deg)}}

:root{--cpbg:#f0f2f5;--cpcard:#fff;--cpbdr:#e5e7eb;--cptext:#0f172a;--cptext2:#475569;--cptext3:#94a3b8;--cpred:#bb0013;--cpgreen:#22c55e;--cpblue:#3b82f6;--cpamber:#f59e0b;--cpsh:0 2px 8px rgba(0,0,0,.06);--cpsh2:0 8px 32px rgba(0,0,0,.08)}

.cp-app{position:fixed;inset:0;z-index:99999;display:flex;flex-direction:column;font-family:'Inter',sans-serif;background:var(--cpbg);color:var(--cptext);font-size:15px}

/* ── TOPBAR ── */
.cp-topbar{display:flex;align-items:center;gap:16px;padding:14px 28px;background:var(--cpcard);border-bottom:1px solid var(--cpbdr);flex-shrink:0}
.cp-topbar-brand{display:flex;align-items:center;gap:12px}
.cp-topbar-brand img{width:36px;height:36px;border-radius:8px;object-fit:contain}
.cp-topbar-brand h3{font-size:16px;font-weight:900;color:var(--cpred);margin:0;letter-spacing:1px}
.cp-topbar-brand p{font-size:10px;font-weight:700;color:var(--cptext3);letter-spacing:2px;margin:2px 0 0;text-transform:uppercase}
.cp-topbar-r{display:flex;align-items:center;gap:12px;margin-left:auto}
.cp-topbar-user{display:flex;align-items:center;gap:10px;padding-left:16px;border-left:1px solid var(--cpbdr)}
.cp-topbar-user .nm{font-size:14px;font-weight:700;color:var(--cptext)}
.cp-topbar-user .rl{font-size:10px;font-weight:700;color:var(--cptext3);text-transform:uppercase;letter-spacing:1px}
.cp-avatar{width:38px;height:38px;background:linear-gradient(135deg,#bb0013,#d4001a);border-radius:10px;display:flex;align-items:center;justify-content:center;color:#fff;font-size:15px;font-weight:800;box-shadow:0 2px 8px rgba(187,0,19,.3)}
.cp-logout-btn{padding:8px 16px;border-radius:8px;border:1.5px solid var(--cpbdr);background:var(--cpcard);color:var(--cptext2);font-size:13px;font-weight:700;font-family:inherit;cursor:pointer;display:flex;align-items:center;gap:6px;transition:all .15s}
.cp-logout-btn:hover{border-color:var(--cpred);color:var(--cpred);background:rgba(187,0,19,.04)}
.cp-logout-btn i{font-size:12px}

/* ── CONTENT ── */
.cp-content{flex:1;overflow-y:auto;padding:28px}
.cp-page-title{font-size:28px;font-weight:900;color:var(--cptext);letter-spacing:-.5px;margin:0 0 4px}
.cp-page-sub{font-size:14px;color:var(--cptext3);margin:0 0 24px;font-weight:500}

/* ── STATS ── */
.cp-stats{display:grid;grid-template-columns:repeat(4,1fr);gap:16px;margin-bottom:24px}
.cp-stat{background:var(--cpcard);border-radius:16px;padding:22px 24px;border:1px solid var(--cpbdr);box-shadow:var(--cpsh);display:flex;justify-content:space-between;align-items:flex-start;position:relative;overflow:hidden;transition:all .2s;cursor:default}
.cp-stat:hover{transform:translateY(-3px);box-shadow:var(--cpsh2)}
.cp-stat::before{content:'';position:absolute;left:0;top:0;bottom:0;width:4px;background:var(--cpred)}
.cp-stat:nth-child(2)::before{background:var(--cpamber)}
.cp-stat:nth-child(3)::before{background:var(--cpgreen)}
.cp-stat:nth-child(4)::before{background:var(--cpblue)}
.cp-stat-label{font-size:11px;font-weight:800;color:var(--cptext3);text-transform:uppercase;letter-spacing:1.5px;margin-bottom:6px}
.cp-stat-value{font-size:36px;font-weight:900;color:var(--cptext);letter-spacing:-1px;line-height:1;animation:cp-countUp .5s ease}
.cp-stat-desc{font-size:12px;font-weight:600;margin-top:6px}
.cp-stat-desc.g{color:var(--cpgreen)}.cp-stat-desc.w{color:var(--cpamber)}.cp-stat-desc.b{color:var(--cpblue)}.cp-stat-desc.r{color:var(--cpred)}
.cp-stat-icon{width:44px;height:44px;border-radius:12px;display:flex;align-items:center;justify-content:center;font-size:18px;flex-shrink:0}
.cp-stat:nth-child(1) .cp-stat-icon{background:rgba(187,0,19,.08);color:var(--cpred)}
.cp-stat:nth-child(2) .cp-stat-icon{background:rgba(245,158,11,.08);color:var(--cpamber)}
.cp-stat:nth-child(3) .cp-stat-icon{background:rgba(34,197,94,.08);color:var(--cpgreen)}
.cp-stat:nth-child(4) .cp-stat-icon{background:rgba(59,130,246,.08);color:var(--cpblue)}

/* ── NEW BOOKING CTA ── */
.cp-cta-card{background:linear-gradient(135deg,#0a1020 0%,#0d1a30 100%);border-radius:16px;padding:28px 32px;margin-bottom:24px;display:flex;align-items:center;justify-content:space-between;gap:24px;box-shadow:0 4px 24px rgba(0,0,0,.15);position:relative;overflow:hidden}
.cp-cta-card::before{content:'';position:absolute;top:-60px;right:-40px;width:250px;height:250px;background:radial-gradient(circle,rgba(187,0,19,.15),transparent 70%);pointer-events:none}
.cp-cta-info h3{font-size:22px;font-weight:800;color:#fff;margin:0 0 6px}
.cp-cta-info p{font-size:14px;color:#64748b;margin:0;max-width:400px}
.cp-cta-btn{display:inline-flex;align-items:center;gap:10px;padding:14px 28px;background:linear-gradient(135deg,#bb0013,#d4001a);color:#fff;border:none;border-radius:12px;font-size:15px;font-weight:800;font-family:inherit;cursor:pointer;letter-spacing:.5px;transition:all .2s;white-space:nowrap;text-decoration:none;box-shadow:0 4px 16px rgba(187,0,19,.35);position:relative;z-index:1}
.cp-cta-btn:hover{transform:translateY(-2px);box-shadow:0 6px 24px rgba(187,0,19,.45)}
.cp-cta-btn:active{transform:translateY(0)}
.cp-cta-btn i{font-size:14px}

/* ── TABLE ── */
.cp-tc{background:var(--cpcard);border-radius:16px;border:1px solid var(--cpbdr);box-shadow:var(--cpsh);overflow:hidden}
.cp-th{display:flex;justify-content:space-between;align-items:center;padding:18px 22px;border-bottom:1px solid var(--cpbdr)}
.cp-th h3{font-size:16px;font-weight:800;display:flex;align-items:center;gap:10px;margin:0;color:var(--cptext)}
.cp-th h3 i{color:var(--cpred);font-size:15px}
.cp-th .badge{font-size:11px;font-weight:700;background:rgba(187,0,19,.08);color:var(--cpred);padding:4px 12px;border-radius:14px;margin-left:8px}
.cp-tw{overflow-x:auto}
table.cp-t{width:100%;border-collapse:collapse;min-width:800px}
.cp-t thead th{padding:13px 16px;font-size:10px;font-weight:800;color:var(--cptext3);text-transform:uppercase;letter-spacing:1.2px;text-align:left;border-bottom:1px solid var(--cpbdr);background:#f8f9fb;white-space:nowrap}
.cp-t tbody tr{border-bottom:1px solid rgba(0,0,0,.04);cursor:pointer;transition:all .12s}
.cp-t tbody tr:hover{background:rgba(187,0,19,.02)}
.cp-t tbody td{padding:14px 16px;font-size:14px;font-weight:500;color:var(--cptext2);white-space:nowrap}
.cp-t .awbc{font-weight:700;color:var(--cptext);font-family:'Courier New',monospace;font-size:14px;letter-spacing:.5px}
.cp-t .nmc{font-weight:600;color:var(--cptext);max-width:200px;overflow:hidden;text-overflow:ellipsis}
.cp-st{display:flex;align-items:center;gap:7px;font-size:13px;font-weight:600}
.cp-dot{width:8px;height:8px;border-radius:50%;flex-shrink:0}
.dd{background:var(--cpgreen)}.dt{background:var(--cpamber)}.db{background:var(--cptext3)}.dr{background:#dc2626}.dbl{background:var(--cpblue)}

/* ── FILTER BAR ── */
.cp-fb{display:flex;align-items:center;gap:10px;margin-bottom:16px;flex-wrap:wrap}
.cp-fs{flex:1;min-width:220px;display:flex;align-items:center;gap:10px;background:var(--cpcard);border:1.5px solid var(--cpbdr);border-radius:12px;padding:0 16px;transition:all .2s}
.cp-fs:focus-within{border-color:var(--cpred);box-shadow:0 0 0 3px rgba(187,0,19,.06)}
.cp-fs i{color:var(--cptext3);font-size:15px}
.cp-fs input{flex:1;padding:12px 0;border:none;background:transparent;font-size:14px;font-family:inherit;color:var(--cptext);outline:none;font-weight:500}
.cp-fs input::placeholder{color:var(--cptext3)}

/* ── PAGINATION ── */
.cp-pg{display:flex;justify-content:space-between;align-items:center;padding:14px 22px;border-top:1px solid var(--cpbdr)}
.cp-pi{font-size:13px;color:var(--cptext3)}.cp-pi strong{color:var(--cpred)}
.cp-pbs{display:flex;gap:4px}
.cp-pb{width:36px;height:36px;border-radius:8px;border:1.5px solid var(--cpbdr);background:var(--cpcard);color:var(--cptext3);font-size:12px;font-weight:700;font-family:inherit;cursor:pointer;display:flex;align-items:center;justify-content:center;transition:all .15s}
.cp-pb:hover{background:#f1f5f9;transform:translateY(-1px)}.cp-pb.on{background:var(--cpred);color:#fff;border-color:var(--cpred)}.cp-pb:disabled{opacity:.3;cursor:not-allowed}

/* ── DETAIL PANEL ── */
.cp-do{display:none;position:fixed;inset:0;background:rgba(0,0,0,.5);z-index:100000;justify-content:flex-end;backdrop-filter:blur(6px)}
.cp-do.show{display:flex}
.cp-dp{width:580px;max-width:100%;background:var(--cpcard);height:100%;overflow-y:auto;border-left:1px solid var(--cpbdr);animation:cp-slideIn .3s ease}
.cp-dh{padding:22px 24px;border-bottom:1px solid var(--cpbdr);display:flex;justify-content:space-between;align-items:center;position:sticky;top:0;background:var(--cpcard);z-index:2}
.cp-dh h3{font-size:18px;font-weight:800;margin:0;display:flex;align-items:center;gap:10px;color:var(--cptext)}
.cp-dh h3 i{color:var(--cpred)}
.cp-dc{width:34px;height:34px;border-radius:8px;border:1.5px solid var(--cpbdr);background:var(--cpcard);cursor:pointer;display:flex;align-items:center;justify-content:center;color:var(--cptext3);font-size:13px;transition:all .15s}
.cp-dc:hover{background:rgba(187,0,19,.08);color:var(--cpred)}
.cp-db-body{padding:24px}
.cp-ds{margin-bottom:22px;animation:cp-fadeUp .3s ease both}
.cp-ds:nth-child(2){animation-delay:.05s}.cp-ds:nth-child(3){animation-delay:.1s}
.cp-ds h4{font-size:11px;font-weight:800;color:var(--cptext3);text-transform:uppercase;letter-spacing:2px;margin:0 0 12px;display:flex;align-items:center;gap:8px}
.cp-ds h4 i{color:var(--cpred);font-size:12px}
.cp-dg{display:grid;grid-template-columns:1fr 1fr;gap:8px}
.cp-df{background:#f8f9fb;border:1px solid var(--cpbdr);border-radius:10px;padding:10px 14px}
.cp-df .l{font-size:9px;font-weight:800;color:var(--cptext3);text-transform:uppercase;letter-spacing:1px;margin-bottom:4px}
.cp-df .v{font-size:13px;font-weight:600;color:var(--cptext);word-break:break-all}
.cp-df.fl{grid-column:1/-1}

/* ── TRACKING TIMELINE ── */
.cp-tl{list-style:none;padding:0;margin:0}
.cp-tl li{position:relative;padding:12px 0 12px 32px;border-left:2px solid var(--cpred);margin-left:8px;animation:cp-fadeUp .3s ease both}
.cp-tl li::before{content:'';position:absolute;left:-6px;top:16px;width:10px;height:10px;border-radius:50%;background:var(--cpred);border:2px solid var(--cpcard);box-shadow:0 0 0 2px rgba(187,0,19,.2)}
.cp-tl li:first-child::before{background:var(--cpgreen);box-shadow:0 0 0 2px rgba(34,197,94,.2)}
.cp-tl-card{background:#f8f9fb;border:1px solid var(--cpbdr);border-radius:8px;padding:12px 14px}
.cp-tla{font-weight:700;color:var(--cptext);font-size:14px;margin-bottom:4px;display:flex;align-items:center;gap:6px}
.cp-tla i{font-size:11px;color:var(--cpred)}
.cp-tl li:first-child .cp-tla i{color:var(--cpgreen)}
.cp-tlm{font-size:12px;color:var(--cptext3);display:flex;align-items:center;gap:6px}
.cp-tl-empty{text-align:center;padding:40px;color:var(--cptext3)}
.cp-tl-empty i{font-size:36px;display:block;margin-bottom:12px;opacity:.2}

/* ── SKELETON ── */
.cp-skeleton{background:linear-gradient(90deg,#f0f0f0 25%,#e0e0e0 50%,#f0f0f0 75%);background-size:800px 100%;animation:cp-shimmer 1.5s ease infinite;border-radius:8px;height:18px}

/* ── FOOTER ── */
.cp-footer{display:flex;justify-content:center;align-items:center;gap:28px;padding:12px 28px;background:var(--cpcard);border-top:1px solid var(--cpbdr);flex-shrink:0}
.cp-footer span{font-size:10px;font-weight:700;color:var(--cptext3);letter-spacing:1px;text-transform:uppercase;display:flex;align-items:center;gap:6px}
.cp-footer .dg{width:7px;height:7px;border-radius:50%;background:var(--cpgreen)}

/* ── RESPONSIVE ── */
@media(max-width:900px){
    .cp-stats{grid-template-columns:repeat(2,1fr)}
    .cp-dp{width:100%}
    .cp-content{padding:18px 16px}
    .cp-page-title{font-size:22px}
    .cp-cta-card{flex-direction:column;text-align:center;padding:24px}
    .cp-topbar{padding:12px 16px}
    .cp-topbar-user .nm-wrap{display:none}
}
@media(max-width:480px){
    .cp-stats{grid-template-columns:1fr}
    .cp-stat-value{font-size:28px}
    .cp-content{padding:14px 12px}
    .cp-cta-info h3{font-size:18px}
    .cp-fb{flex-direction:column;align-items:stretch}
}
</style>

<div class="cp-app" id="cp-app">

<!-- TOPBAR -->
<header class="cp-topbar">
    <div class="cp-topbar-brand">
        <img src="<?php echo esc_url(PE_CP_LOGO_URL); ?>" alt="PE">
        <div>
            <h3>Prince Express</h3>
            <p>Customer Portal</p>
        </div>
    </div>
    <div class="cp-topbar-r">
        <div class="cp-topbar-user">
            <div class="nm-wrap">
                <span class="nm"><?php echo esc_html(ucfirst($cust['name'])); ?></span><br>
                <span class="rl">Customer</span>
            </div>
        </div>
        <div class="cp-avatar"><?php echo strtoupper(substr($cust['name'], 0, 1)); ?></div>
        <button class="cp-logout-btn" onclick="cpLogout()"><i class="fa-solid fa-right-from-bracket"></i> Sign Out</button>
    </div>
</header>

<!-- CONTENT -->
<div class="cp-content">

    <h1 class="cp-page-title">Welcome, <?php echo esc_html(ucfirst($cust['name'])); ?></h1>
    <p class="cp-page-sub">Manage your shipments, book new parcels, and track deliveries.</p>

    <!-- STATS -->
    <div class="cp-stats">
        <div class="cp-stat"><div><div class="cp-stat-label">Total Shipments</div><div class="cp-stat-value"><?php echo number_format($ts); ?></div><div class="cp-stat-desc r">All time</div></div><div class="cp-stat-icon"><i class="fa-solid fa-boxes-stacked"></i></div></div>
        <div class="cp-stat"><div><div class="cp-stat-label">In Transit</div><div class="cp-stat-value"><?php echo str_pad($tc, 2, '0', STR_PAD_LEFT); ?></div><div class="cp-stat-desc w">On the way</div></div><div class="cp-stat-icon"><i class="fa-solid fa-truck"></i></div></div>
        <div class="cp-stat"><div><div class="cp-stat-label">Delivered</div><div class="cp-stat-value"><?php echo number_format($dc); ?></div><div class="cp-stat-desc g">Completed</div></div><div class="cp-stat-icon"><i class="fa-solid fa-circle-check"></i></div></div>
        <div class="cp-stat"><div><div class="cp-stat-label">Active</div><div class="cp-stat-value"><?php echo str_pad($ts - $dc, 2, '0', STR_PAD_LEFT); ?></div><div class="cp-stat-desc b">In progress</div></div><div class="cp-stat-icon"><i class="fa-solid fa-signal"></i></div></div>
    </div>

    <!-- NEW BOOKING CTA -->
    <div class="cp-cta-card">
        <div class="cp-cta-info">
            <h3>Ready to ship? 📦</h3>
            <p>Create a new international shipment booking and get your invoice label instantly.</p>
        </div>
        <a class="cp-cta-btn" href="<?php echo esc_url(home_url('/new-booking/')); ?>">
            <i class="fa-solid fa-plus"></i> New Shipment Booking
        </a>
    </div>

    <!-- SHIPMENTS TABLE -->
    <div class="cp-fb">
        <div class="cp-fs"><i class="fa-solid fa-magnifying-glass"></i><input type="text" id="cp-search" placeholder="Search AWB, consignee, destination..." onkeydown="if(event.key==='Enter')cpLoadShipments(1);"></div>
    </div>
    <div id="cp-shipments-container"></div>

</div>

<!-- FOOTER -->
<footer class="cp-footer">
    <span><span class="dg"></span> Systems Online</span>
    <span><img src="<?php echo esc_url(PE_CP_LOGO_URL); ?>" alt="" style="width:14px;height:14px;border-radius:3px"> Prince Express Customer Portal v1.0</span>
</footer>
</div>

<!-- DETAIL PANEL -->
<div class="cp-do" id="cp-detail-overlay" onclick="if(event.target===this)cpCloseDetail()">
    <div class="cp-dp" id="cp-detail-panel"></div>
</div>

<script>
var cpPage=1,cpSearch='';

function cpAjax(action,params,callback,retried){
    var fd=new FormData();fd.append('action',action);fd.append('nonce',PE_CP.nonce);
    if(params){for(var k in params){if(params.hasOwnProperty(k))fd.append(k,params[k]);}}
    fetch(PE_CP.ajax_url,{method:'POST',body:fd,credentials:'same-origin'})
    .then(function(r){return r.json();})
    .then(function(d){
        if(!d.success&&d.data){
            if(d.data.nonce_expired&&d.data.new_nonce&&!retried){PE_CP.nonce=d.data.new_nonce;return cpAjax(action,params,callback,true);}
            if(d.data.expired){location.reload();return;}
        }
        if(callback)callback(d);
    }).catch(function(err){console.error('CP AJAX error:',action,err);});
}

function cpLogout(){
    cpAjax('pe_cp_logout',{},function(){location.reload();});
}

function cpGetStatusDot(st){
    if(!st)return{dot:'db',label:'Booked'};
    var s=st.toLowerCase();
    if(s.indexOf('deliver')>=0)return{dot:'dd',label:'Delivered'};
    if(s.indexOf('transit')>=0||s.indexOf('depart')>=0||s.indexOf('dispatch')>=0)return{dot:'dt',label:'In Transit'};
    if(s.indexOf('customs')>=0)return{dot:'dbl',label:'Customs'};
    if(s.indexOf('book')>=0||s.indexOf('received')>=0)return{dot:'db',label:'Booked'};
    return{dot:'dt',label:st.length>25?st.substring(0,25)+'…':st};
}

function cpSkeleton(){
    var h='<div class="cp-tc"><div class="cp-th"><h3><i class="fa-solid fa-layer-group"></i> Loading...</h3></div><div class="cp-tw"><table class="cp-t"><tbody>';
    for(var i=0;i<5;i++)h+='<tr><td colspan="7" style="padding:18px 16px"><div class="cp-skeleton" style="width:'+(50+Math.random()*40)+'%;height:16px"></div></td></tr>';
    h+='</tbody></table></div></div>';return h;
}

function cpLoadShipments(p){
    cpPage=p||1;
    cpSearch=document.getElementById('cp-search').value;
    document.getElementById('cp-shipments-container').innerHTML=cpSkeleton();
    cpAjax('pe_cp_shipments',{page:cpPage,search:cpSearch},function(d){
        if(!d.success)return;
        var r=d.data,h='';
        h+='<div class="cp-tc"><div class="cp-th"><h3><i class="fa-solid fa-layer-group"></i> Your Shipments <span class="badge">'+r.total+'</span></h3></div>';
        h+='<div class="cp-tw"><table class="cp-t"><thead><tr><th>AWB</th><th>Date</th><th>Consignee</th><th>Destination</th><th>Weight</th><th>Status</th></tr></thead><tbody>';
        if(!r.rows.length)h+='<tr><td colspan="7" style="text-align:center;padding:50px;color:var(--cptext3)"><i class="fa-solid fa-inbox" style="font-size:28px;display:block;margin-bottom:10px;opacity:.2"></i>No shipments found</td></tr>';
        r.rows.forEach(function(rw){
            var stDot=cpGetStatusDot(rw.status);
            h+='<tr onclick="cpShowDetail(\''+rw.awb+'\')">';
            h+='<td class="awbc">'+rw.awb+'</td>';
            h+='<td style="font-weight:600;color:var(--cptext2)">'+(rw.booking_date||'—')+'</td>';
            h+='<td class="nmc">'+rw.consignee+'</td>';
            h+='<td><i class="fa-solid fa-location-dot" style="color:var(--cptext3);font-size:10px;margin-right:4px"></i>'+rw.destination+'</td>';
            h+='<td style="font-weight:600">'+(rw.weight||'—')+' kg</td>';
            h+='<td><div class="cp-st"><span class="cp-dot '+stDot.dot+'"></span>'+stDot.label+'</div></td></tr>';
        });
        h+='</tbody></table></div>';
        h+='<div class="cp-pg"><div class="cp-pi">Showing <strong>'+r.rows.length+'</strong> of <strong>'+r.total+'</strong> · Page '+r.page+'/'+r.pages+'</div><div class="cp-pbs">';
        h+='<button class="cp-pb" onclick="cpLoadShipments('+(r.page-1)+')" '+(r.page<=1?'disabled':'')+'><i class="fa-solid fa-chevron-left" style="font-size:10px"></i></button>';
        for(var i=Math.max(1,r.page-2);i<=Math.min(r.pages,r.page+2);i++)h+='<button class="cp-pb'+(i===r.page?' on':'')+'" onclick="cpLoadShipments('+i+')">'+i+'</button>';
        h+='<button class="cp-pb" onclick="cpLoadShipments('+(r.page+1)+')" '+(r.page>=r.pages?'disabled':'')+'><i class="fa-solid fa-chevron-right" style="font-size:10px"></i></button>';
        h+='</div></div></div>';
        document.getElementById('cp-shipments-container').innerHTML=h;
    });
}

function cpShowDetail(awb){
    var panel=document.getElementById('cp-detail-panel');
    panel.innerHTML='<div style="padding:40px;text-align:center"><div style="width:30px;height:30px;border:3px solid #e5e7eb;border-top-color:#bb0013;border-radius:50%;animation:cp-spin .6s linear infinite;margin:0 auto 16px"></div><p style="color:#94a3b8;font-size:14px">Loading shipment details...</p></div>';
    document.getElementById('cp-detail-overlay').classList.add('show');
    cpAjax('pe_cp_shipment_detail',{awb:awb},function(d){
        if(!d.success){panel.innerHTML='<div style="padding:40px;text-align:center;color:#dc2626">Failed to load details</div>';return;}
        var s=d.data.shipment,tr=d.data.tracking;
        var stDot=cpGetStatusDot(tr.length?tr[0].activity:'');
        var h='';
        h+='<div class="cp-dh"><h3><i class="fa-solid fa-box"></i> AWB '+s.awb+'</h3><button class="cp-dc" onclick="cpCloseDetail()"><i class="fa-solid fa-xmark"></i></button></div>';
        h+='<div class="cp-db-body">';
        // Status
        h+='<div class="cp-ds"><h4><i class="fa-solid fa-circle-info"></i> Current Status</h4><div style="display:flex;align-items:center;gap:8px;padding:12px 16px;background:#f8f9fb;border-radius:10px;border:1px solid #e5e7eb"><span class="cp-dot '+stDot.dot+'" style="width:10px;height:10px"></span><span style="font-size:15px;font-weight:700;color:#0f172a">'+stDot.label+'</span></div></div>';
        // Shipment Info
        h+='<div class="cp-ds"><h4><i class="fa-solid fa-box"></i> Shipment Details</h4><div class="cp-dg">';
        h+='<div class="cp-df"><div class="l">AWB Number</div><div class="v" style="font-family:Courier New,monospace">'+s.awb+'</div></div>';
        h+='<div class="cp-df"><div class="l">Booking Date</div><div class="v">'+(s.date||'—')+'</div></div>';
        h+='<div class="cp-df"><div class="l">Shipper</div><div class="v">'+(s.shipper||'—')+'</div></div>';
        h+='<div class="cp-df"><div class="l">Consignee</div><div class="v">'+(s.consignee||'—')+'</div></div>';
        h+='<div class="cp-df"><div class="l">Origin</div><div class="v">'+(s.origin||'—')+'</div></div>';
        h+='<div class="cp-df"><div class="l">Destination</div><div class="v">'+(s.destination||'—')+'</div></div>';
        h+='<div class="cp-df"><div class="l">Weight</div><div class="v">'+(s.weight||'—')+' kg</div></div>';
        h+='<div class="cp-df"><div class="l">Pieces</div><div class="v">'+(s.pieces||'1')+'</div></div>';
        if(s.vendor)h+='<div class="cp-df"><div class="l">Carrier</div><div class="v">'+s.vendor+'</div></div>';
        if(s.vendor_awb)h+='<div class="cp-df"><div class="l">Vendor AWB</div><div class="v" style="font-family:Courier New,monospace">'+s.vendor_awb+'</div></div>';
        h+='</div></div>';
        // Tracking Timeline
        h+='<div class="cp-ds"><h4><i class="fa-solid fa-route"></i> Tracking History</h4>';
        if(tr.length){
            h+='<ul class="cp-tl">';
            tr.forEach(function(t,i){
                h+='<li style="animation-delay:'+(.03*i)+'s"><div class="cp-tl-card"><div class="cp-tla"><i class="fa-solid '+(i===0?'fa-circle-check':'fa-circle-dot')+'"></i>'+t.activity+'</div><div class="cp-tlm"><i class="fa-solid fa-calendar"></i> '+t.date+' '+t.time+(t.location?' &nbsp;·&nbsp; <i class="fa-solid fa-location-dot"></i> '+t.location:'')+'</div></div></li>';
            });
            h+='</ul>';
        } else {
            h+='<div class="cp-tl-empty"><i class="fa-solid fa-route"></i><p>No tracking events yet</p></div>';
        }
        h+='</div></div>';
        panel.innerHTML=h;
    });
}

function cpCloseDetail(){
    document.getElementById('cp-detail-overlay').classList.remove('show');
}

// ── Heartbeat ──
setInterval(function(){cpAjax('pe_cp_heartbeat',{},function(){});},30000);

// ── Init ──
cpLoadShipments(1);
</script>

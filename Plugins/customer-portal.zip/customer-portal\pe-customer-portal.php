<?php
/*
Plugin Name: PE Customer Portal
Description: Customer-facing portal for shipment booking, tracking, and self-service dashboard.
Version: 1.0
Author: Suraj
*/
if (!defined('ABSPATH'))
    exit;

// ══════════════════════════════════════
//  CONSTANTS
// ══════════════════════════════════════
define('PE_CP_DIR', plugin_dir_path(__FILE__));
define('PE_CP_URL', plugin_dir_url(__FILE__));

// Admin portal URL (where the React booking form is hosted)
if (!defined('PE_ADMIN_PORTAL_URL')) {
    define('PE_ADMIN_PORTAL_URL', 'https://purple-raccoon-753399.hostingersite.com/customer/booking');
}

// Logo URL constant (same as admin)
if (!defined('PE_CP_LOGO_URL')) {
    define('PE_CP_LOGO_URL', 'https://princeexp.com/wp-content/uploads/2026/04/ChatGPT-Image-Apr-14-2026-06_03_34-AM.png');
}

// Session cookie name (different from admin)
if (!defined('PE_CP_COOKIE_NAME')) {
    define('PE_CP_COOKIE_NAME', 'pe_customer_sid');
}

// Sync API key (must match WP_SYNC_KEY in Node.js .env)
if (!defined('PE_CP_SYNC_KEY')) {
    define('PE_CP_SYNC_KEY', 'pe_sync_2026_prince_express_secret');
}

// Secret key for customer session encryption
if (!defined('PE_CP_SESSION_SECRET')) {
    define('PE_CP_SESSION_SECRET', defined('AUTH_KEY') ? AUTH_KEY . 'PE_CUSTOMER_V1' : 'pe_cust_default_secret_change_me_2026');
}

// ══════════════════════════════════════
//  SESSION ENGINE (same pattern as admin plugin)
// ══════════════════════════════════════

function pe_cp_encrypt($data)
{
    $key = hash('sha256', PE_CP_SESSION_SECRET, true);
    $iv = openssl_random_pseudo_bytes(16);
    $encrypted = openssl_encrypt(serialize($data), 'aes-256-cbc', $key, OPENSSL_RAW_DATA, $iv);
    if ($encrypted === false)
        return null;
    return base64_encode($iv . $encrypted);
}

function pe_cp_decrypt($payload)
{
    if (empty($payload))
        return null;
    $key = hash('sha256', PE_CP_SESSION_SECRET, true);
    $raw = base64_decode($payload, true);
    if ($raw === false || strlen($raw) < 17)
        return null;
    $iv = substr($raw, 0, 16);
    $encrypted = substr($raw, 16);
    $decrypted = openssl_decrypt($encrypted, 'aes-256-cbc', $key, OPENSSL_RAW_DATA, $iv);
    if ($decrypted === false)
        return null;
    $data = @unserialize($decrypted);
    return $data !== false ? $data : null;
}

function pe_cp_session_get()
{
    $token = $_COOKIE[PE_CP_COOKIE_NAME] ?? null;
    if (!$token)
        return null;
    $encrypted = get_transient('pe_cp_sess_' . $token);
    if (!$encrypted)
        return null;
    return pe_cp_decrypt($encrypted);
}

function pe_cp_session_set($data, $token = null)
{
    if (!$token)
        $token = $_COOKIE[PE_CP_COOKIE_NAME] ?? null;
    if (!$token)
        return false;
    $encrypted = pe_cp_encrypt($data);
    if (!$encrypted)
        return false;
    set_transient('pe_cp_sess_' . $token, $encrypted, 86400);
    return true;
}

function pe_cp_session_create($data)
{
    $token = bin2hex(random_bytes(32));
    $secure = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off');
    setcookie(PE_CP_COOKIE_NAME, $token, [
        'expires' => 0,
        'path' => '/',
        'domain' => '',
        'secure' => $secure,
        'httponly' => true,
        'samesite' => 'Lax',
    ]);
    $_COOKIE[PE_CP_COOKIE_NAME] = $token;
    pe_cp_session_set($data, $token);
    return $token;
}

function pe_cp_session_clear()
{
    $token = $_COOKIE[PE_CP_COOKIE_NAME] ?? null;
    if ($token) {
        delete_transient('pe_cp_sess_' . $token);
    }
    $secure = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off');
    setcookie(PE_CP_COOKIE_NAME, '', [
        'expires' => time() - 86400,
        'path' => '/',
        'domain' => '',
        'secure' => $secure,
        'httponly' => true,
        'samesite' => 'Lax',
    ]);
    unset($_COOKIE[PE_CP_COOKIE_NAME]);
}

function pe_cp_fingerprint()
{
    $ua = $_SERVER['HTTP_USER_AGENT'] ?? 'unknown';
    return hash('sha256', $ua . '|' . PE_CP_SESSION_SECRET);
}

// ══════════════════════════════════════
//  AUTH HELPERS
// ══════════════════════════════════════

function pe_cp_is_logged_in()
{
    $cust = pe_cp_session_get();
    return !empty($cust['logged_in']);
}

function pe_cp_get_user()
{
    $cust = pe_cp_session_get();
    return (!empty($cust['logged_in'])) ? $cust : null;
}

function pe_cp_check_ajax()
{
    if (!pe_cp_is_logged_in()) {
        wp_send_json_error(['message' => 'Session expired. Please login again.', 'expired' => true, 'new_nonce' => wp_create_nonce('pe_cp_nonce')], 401);
    }
    if (!check_ajax_referer('pe_cp_nonce', 'nonce', false)) {
        wp_send_json_error(['message' => 'Session token expired. Refreshing...', 'nonce_expired' => true, 'new_nonce' => wp_create_nonce('pe_cp_nonce')], 403);
    }
}

// ── Session Validation ──
add_action('init', function () {
    $cust = pe_cp_session_get();
    if ($cust) {
        if (!empty($cust['fingerprint']) && $cust['fingerprint'] !== pe_cp_fingerprint()) {
            pe_cp_session_clear();
            return;
        }
        $cust['last_activity'] = time();
        pe_cp_session_set($cust);
    }
}, 1);

// ══════════════════════════════════════
//  ENQUEUE ASSETS
// ══════════════════════════════════════

function pe_cp_enqueue()
{
    wp_enqueue_style('pe-cp-fonts', 'https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800;900&display=swap', [], null);
    wp_enqueue_style('pe-cp-fa', 'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css', [], '6.5.1');
    wp_register_script('pe-cp-config', '', [], false, false);
    wp_enqueue_script('pe-cp-config');
    wp_localize_script('pe-cp-config', 'PE_CP', [
        'ajax_url' => admin_url('admin-ajax.php'),
        'nonce' => wp_create_nonce('pe_cp_nonce'),
        'logo_url' => PE_CP_LOGO_URL,
        'portal_url' => PE_ADMIN_PORTAL_URL,
    ]);
}
add_action('wp_enqueue_scripts', 'pe_cp_enqueue');

// ══════════════════════════════════════
//  AJAX: LOGIN
// ══════════════════════════════════════

function pe_cp_ajax_login()
{
    if (!check_ajax_referer('pe_cp_nonce', 'nonce', false)) {
        wp_send_json_error(['message' => 'Security token expired. Please refresh the page.'], 403);
    }

    global $wpdb;
    $email_or_phone = isset($_POST['email_or_phone']) ? trim(sanitize_text_field(wp_unslash($_POST['email_or_phone']))) : '';
    $pwd = isset($_POST['pwd']) ? wp_unslash($_POST['pwd']) : '';

    if (!$email_or_phone || $pwd === '') {
        wp_send_json_error(['message' => 'Please enter your email/phone and password.']);
    }

    // Determine correct table name
    $table = 'tbl_customers';
    $table_check = $wpdb->get_var("SHOW TABLES LIKE 'tbl_customers'");
    if (!$table_check && !empty($wpdb->prefix)) {
        $prefixed_check = $wpdb->get_var("SHOW TABLES LIKE '{$wpdb->prefix}tbl_customers'");
        if ($prefixed_check) {
            $table = "{$wpdb->prefix}tbl_customers";
        }
    }

    // Case-insensitive email, trimmed phone, or name lookup
    $row = $wpdb->get_row($wpdb->prepare(
        "SELECT * FROM $table WHERE (LOWER(TRIM(email)) = LOWER(%s) OR TRIM(phone) = %s OR LOWER(TRIM(name)) = LOWER(%s)) LIMIT 1",
        $email_or_phone,
        $email_or_phone,
        $email_or_phone
    ));

    // Fallback: Check if user exists in standard WordPress users table
    if (!$row) {
        $wp_user = get_user_by('email', $email_or_phone);
        if (!$wp_user) {
            $wp_user = get_user_by('login', $email_or_phone);
        }
        if ($wp_user && wp_check_password($pwd, $wp_user->user_pass, $wp_user->ID)) {
            // Auto-create tbl_customers record
            $wpdb->insert($table, [
                'name' => $wp_user->display_name ?: $wp_user->user_login,
                'email' => $wp_user->user_email,
                'phone' => get_user_meta($wp_user->ID, 'billing_phone', true) ?: '',
                'password' => password_hash($pwd, PASSWORD_BCRYPT, ['cost' => 10]),
                'status' => 'active'
            ]);
            $row = $wpdb->get_row($wpdb->prepare("SELECT * FROM $table WHERE id = %d", $wpdb->insert_id));
        }
    }

    if (!$row) {
        wp_send_json_error(['message' => 'No account found with this email, username, or phone number.']);
    }

    // Check account active status
    if (isset($row->status) && $row->status !== 'active' && $row->status !== '1' && $row->status !== 1 && !empty($row->status)) {
        wp_send_json_error(['message' => 'Your account is currently disabled. Please contact the administrator.']);
    }

    // Verify password (supports bcrypt $2a$, $2b$, $2y$, and legacy MD5)
    $pwd_valid = false;
    if (!empty($row->password)) {
        if (password_verify($pwd, $row->password)) {
            $pwd_valid = true;
        } elseif (md5($pwd) === $row->password) {
            $pwd_valid = true;
            // Upgrade legacy MD5 hash to bcrypt
            $wpdb->update($table, [
                'password' => password_hash($pwd, PASSWORD_BCRYPT, ['cost' => 10])
            ], ['id' => $row->id]);
        } elseif ($pwd === $row->password) {
            // In case stored as plain text
            $pwd_valid = true;
            $wpdb->update($table, [
                'password' => password_hash($pwd, PASSWORD_BCRYPT, ['cost' => 10])
            ], ['id' => $row->id]);
        }
    }

    if (!$pwd_valid) {
        wp_send_json_error(['message' => 'Incorrect password. Please verify and try again or request a password reset from admin.']);
    }

    // Create session
    pe_cp_session_create([
        'customer_id' => $row->id,
        'name' => $row->name,
        'email' => $row->email,
        'phone' => $row->phone,
        'company' => $row->company ?? '',
        'logged_in' => true,
        'login_at' => time(),
        'last_activity' => time(),
        'fingerprint' => pe_cp_fingerprint(),
    ]);

    $wpdb->update($table, [
        'last_login' => current_time('mysql'),
    ], ['id' => $row->id]);

    wp_send_json_success([
        'message' => 'Welcome back, ' . esc_html($row->name) . '! Redirecting...',
        'new_nonce' => wp_create_nonce('pe_cp_nonce')
    ]);
}
add_action('wp_ajax_pe_cp_login', 'pe_cp_ajax_login');
add_action('wp_ajax_nopriv_pe_cp_login', 'pe_cp_ajax_login');

// ══════════════════════════════════════
//  AJAX: LOGOUT
// ══════════════════════════════════════

function pe_cp_ajax_logout()
{
    pe_cp_session_clear();
    wp_send_json_success();
}
add_action('wp_ajax_pe_cp_logout', 'pe_cp_ajax_logout');
add_action('wp_ajax_nopriv_pe_cp_logout', 'pe_cp_ajax_logout');

// ══════════════════════════════════════
//  AJAX: HEARTBEAT
// ══════════════════════════════════════

function pe_cp_ajax_heartbeat()
{
    $cust = pe_cp_session_get();
    if (!$cust || empty($cust['logged_in'])) {
        wp_send_json_error(['expired' => true]);
    }
    $cust['last_heartbeat'] = time();
    pe_cp_session_set($cust);
    wp_send_json_success(['alive' => true]);
}
add_action('wp_ajax_pe_cp_heartbeat', 'pe_cp_ajax_heartbeat');
add_action('wp_ajax_nopriv_pe_cp_heartbeat', 'pe_cp_ajax_heartbeat');

// ══════════════════════════════════════
//  AJAX: CUSTOMER SHIPMENTS
// ══════════════════════════════════════

function pe_cp_ajax_shipments()
{
    pe_cp_check_ajax();
    global $wpdb;

    $cust = pe_cp_get_user();
    $page = max(1, intval($_POST['page'] ?? 1));
    $per = 15;
    $offset = ($page - 1) * $per;
    $search = sanitize_text_field($_POST['search'] ?? '');

    // Build strict WHERE clause: only shipments belonging to this specific customer
    $cust_id = intval($cust['customer_id'] ?? ($cust['id'] ?? 0));
    $cust_email = strtolower(trim($cust['email'] ?? ''));
    $cust_name = trim($cust['name'] ?? '');
    $cust_company = trim($cust['company'] ?? '');
    $cust_phone = trim($cust['phone'] ?? '');

    $match_clauses = [];
    $match_params = [];

    // Check if shipments table exists in WP database
    static $has_shipments_tbl = null;
    if ($has_shipments_tbl === null) {
        $has_shipments_tbl = !empty($wpdb->get_var("SHOW TABLES LIKE 'shipments'"));
    }
    static $has_booking_req_tbl = null;
    if ($has_booking_req_tbl === null) {
        $has_booking_req_tbl = !empty($wpdb->get_var("SHOW TABLES LIKE 'booking_requests'"));
    }

    // 1. Direct match by registered customer ID / code (strictly excluding walk-in 'W001')
    if ($cust_id > 0) {
        $match_clauses[] = "(a.CUSTCODE IN (%s, %s, %s) AND a.CUSTCODE != 'W001' AND LOWER(COALESCE(a.CUSTNAME, '')) != 'walking customer')";
        $match_params[] = strval($cust_id);
        $match_params[] = 'CUST-' . $cust_id;
        $match_params[] = 'CUST-' . str_pad($cust_id, 4, '0', STR_PAD_LEFT);

        if ($has_shipments_tbl) {
            $match_clauses[] = "(a.AWBNO IN (SELECT tracking_number FROM shipments WHERE customer_id = %d) OR CAST(a.AWBNO AS CHAR) IN (SELECT tracking_number FROM shipments WHERE customer_id = %d))";
            $match_params[] = $cust_id;
            $match_params[] = $cust_id;
        }
    }

    // 2. Exact match on shipments converted and pushed from THIS customer's booking requests
    $breq_sub_conds = [];
    $breq_sub_params = [];
    if ($cust_id > 0) {
        $breq_sub_conds[] = "customer_id = %d";
        $breq_sub_params[] = $cust_id;
    }
    if ($cust_email !== '') {
        $breq_sub_conds[] = "LOWER(TRIM(customer_email)) = %s OR LOWER(TRIM(sender_email)) = %s";
        $breq_sub_params[] = $cust_email;
        $breq_sub_params[] = $cust_email;
    }
    $clean_cust_phone = preg_replace('/[^0-9]/', '', $cust_phone);
    $cust_phone_last10 = strlen($clean_cust_phone) >= 10 ? substr($clean_cust_phone, -10) : $clean_cust_phone;
    if ($cust_phone_last10) {
        $breq_sub_conds[] = "customer_phone LIKE %s OR sender_phone LIKE %s";
        $like_p = '%' . $wpdb->esc_like($cust_phone_last10) . '%';
        $breq_sub_params[] = $like_p;
        $breq_sub_params[] = $like_p;
    }
    if (strlen($cust_name) >= 3) {
        $breq_sub_conds[] = "LOWER(TRIM(customer_name)) = %s OR LOWER(TRIM(sender_name)) = %s";
        $breq_sub_params[] = strtolower($cust_name);
        $breq_sub_params[] = strtolower($cust_name);
    }
    if (!empty($cust_company) && strlen($cust_company) >= 3) {
        $breq_sub_conds[] = "LOWER(TRIM(customer_company)) = %s OR LOWER(TRIM(sender_company)) = %s";
        $breq_sub_params[] = strtolower($cust_company);
        $breq_sub_params[] = strtolower($cust_company);
    }

    if (!empty($breq_sub_conds)) {
        $breq_where = $wpdb->prepare("(" . implode(" OR ", $breq_sub_conds) . ")", ...$breq_sub_params);
        $match_clauses[] = "a.AWBNO IN (SELECT request_awb FROM booking_requests WHERE request_awb != '' AND $breq_where)";
        $match_clauses[] = "a.AWBNO IN (SELECT tracking_number FROM booking_requests WHERE tracking_number IS NOT NULL AND tracking_number != '' AND $breq_where)";
    }

    // 3. Direct match by sender phone in AWBENTRY
    if ($cust_phone_last10) {
        $match_clauses[] = "(a.SPHONE1 LIKE %s)";
        $match_params[] = '%' . $wpdb->esc_like($cust_phone_last10) . '%';
    }

    // 4. Match by customer name or company
    if (!empty($cust_name) && strtolower($cust_name) !== 'walking customer' && strlen($cust_name) >= 3) {
        $match_clauses[] = "(LOWER(TRIM(a.CUSTNAME)) = %s OR LOWER(TRIM(a.SNAME)) = %s)";
        $match_params[] = strtolower($cust_name);
        $match_params[] = strtolower($cust_name);
    }
    if (!empty($cust_company) && strtolower($cust_company) !== 'walking customer' && strtolower($cust_company) !== strtolower($cust_name) && strlen($cust_company) >= 3) {
        $match_clauses[] = "(LOWER(TRIM(a.CUSTNAME)) = %s OR LOWER(TRIM(a.SNAME)) = %s)";
        $match_params[] = strtolower($cust_company);
        $match_params[] = strtolower($cust_company);
    }

    if (empty($match_clauses)) {
        $where = "1=0";
    } else {
        $where_all = "(" . implode(" OR ", $match_clauses) . ") AND a.AWBNO > 0";
        if (!empty($match_params)) {
            $where_all = $wpdb->prepare($where_all, ...$match_params);
        }
        // Filter out data before September 1, 2026 in customer dashboard (include current/unassigned dates)
        $where = $where_all . " AND (a.AWBDATE >= '2026-09-01' OR a.AWBDATE = '0000-00-00' OR a.AWBDATE IS NULL)";
        // If date filter results in 0 shipments, fall back to all-time customer records
        $chk_count = intval($wpdb->get_var("SELECT COUNT(*) FROM AWBENTRY a WHERE $where"));
        if ($chk_count === 0) {
            $where = $where_all;
        }
        $where_base = $where;
    }

    if ($search) {
        $like = '%' . $wpdb->esc_like($search) . '%';
        $where .= $wpdb->prepare(
            " AND (CAST(a.AWBNO AS CHAR) LIKE %s OR a.CNEENAME LIKE %s OR a.DESTNAME LIKE %s OR a.SNAME LIKE %s OR a.VENDORAWB1 LIKE %s OR a.VENDORAWB2 LIKE %s OR a.VENDNAME LIKE %s OR CAST(a.AWBDATE AS CHAR) LIKE %s)",
            $like,
            $like,
            $like,
            $like,
            $like,
            $like,
            $like,
            $like
        );
    }

    $total = intval($wpdb->get_var("SELECT COUNT(*) FROM AWBENTRY a WHERE $where"));

    $rows = $wpdb->get_results(
        "SELECT a.AWBID as c_id, a.AWBNO, a.CNEENAME as CONSIGNEE, a.DESTNAME as DESTINATION,
                a.CHARGEWEIGHT as WEIGHT, a.ACTUALWEIGHT, a.RATE, a.AWBDATE as BOOKINGDATE, a.VENDNAME as vendor,
                a.SNAME, a.VENDORAWB1, a.VENDORAWB2, a.NETAMOUNT, a.TOTAL, a.CHARGES, a.RECEIPTAMOUNT,
                a.PODTOWEB, a.REMARKS, a.SERVICE, a.SHOWFWD, a.VENDCODE, a.TUSER, a.TPASS, a.ACCODE, a.APIKEY
         FROM AWBENTRY a
         WHERE $where
         ORDER BY a.AWBID DESC
         LIMIT " . intval($per) . " OFFSET " . intval($offset)
    );

    $clean_fwd = function($val, $primaryVendor = '', $ourAwb = '') {
        if ($val === null) return '';
        $s = trim(strval($val));
        if ($s === '' || $s === '0' || $s === '0.00' || $s === 'null' || $s === 'undefined' || $s === 'None' || $s === '-' || $s === '—') return '';
        $s = preg_replace('/^FWD\s*[:\-]\s*/i', '', $s);
        $s = trim($s);
        if ($s === '' || $s === $primaryVendor || $s === $ourAwb) return '';
        if (stripos($s, 'not found') !== false || stripos($s, 'error') !== false || strtolower($s) === 'pending') return '';
        return $s;
    };

    $data = [];
    foreach ($rows as $r) {
        $status = '';
        $latest_ph = $wpdb->get_row($wpdb->prepare(
            "SELECT activity, date, time, location FROM parcel_history WHERE AWBNO = %d OR CAST(AWBNO AS CHAR) = %s ORDER BY date DESC, time DESC LIMIT 1",
            intval($r->AWBNO),
            strval($r->AWBNO)
        ));
        $ph = $latest_ph ? trim($latest_ph->activity) : '';

        // Lookup node shipment if table exists
        $shp = null;
        if ($has_shipments_tbl) {
            $shp = $wpdb->get_row($wpdb->prepare(
                "SELECT id, vendor_code, vendor_awb_number, vendor_awb_number_2, forwarding_no, secondary_carrier, status, total_amount, shipping_charge, grand_total, final_grand_total, net_amount, vendor_raw_response FROM shipments WHERE tracking_number = %s OR order_id = %s OR vendor_awb_number = %s OR order_reference = %s OR invoice_no = %s LIMIT 1",
                strval($r->AWBNO),
                strval($r->AWBNO),
                strval($r->AWBNO),
                strval($r->AWBNO),
                strval($r->AWBNO)
            ));
            if (!$shp && !empty($r->VENDORAWB1)) {
                $shp = $wpdb->get_row($wpdb->prepare(
                    "SELECT id, vendor_code, vendor_awb_number, vendor_awb_number_2, forwarding_no, secondary_carrier, status, total_amount, shipping_charge, grand_total, final_grand_total, net_amount, vendor_raw_response FROM shipments WHERE vendor_awb_number = %s OR tracking_number = %s LIMIT 1",
                    strval($r->VENDORAWB1),
                    strval($r->VENDORAWB1)
                ));
            }
        }

        // Lookup booking request for amount if not found in AWBENTRY
        $breq = null;
        if (!empty($has_booking_req_tbl)) {
            $breq = $wpdb->get_row($wpdb->prepare(
                "SELECT shipping_charge, status FROM booking_requests WHERE request_awb = %s OR tracking_number = %s LIMIT 1",
                strval($r->AWBNO),
                strval($r->AWBNO)
            ));
        }

        // Pick first non-empty vendor name
        $vendor_name = trim(strval($shp->vendor_code ?? ''));
        if ($vendor_name === '') $vendor_name = trim(strval($r->vendor ?? ($r->VENDNAME ?? '')));

        // Pick first non-empty vendor AWB
        $vAwb = trim(strval($shp->vendor_awb_number ?? ''));
        if ($vAwb === '') $vAwb = trim(strval($r->VENDORAWB1 ?? ''));

        // Pick first non-empty forwarding number from all sources
        $fwd = $clean_fwd($shp->forwarding_no ?? '', $vAwb, strval($r->AWBNO));
        if ($fwd === '') $fwd = $clean_fwd($shp->vendor_awb_number_2 ?? '', $vAwb, strval($r->AWBNO));
        if ($fwd === '') $fwd = $clean_fwd($r->VENDORAWB2 ?? '', $vAwb, strval($r->AWBNO));
        if ($fwd === '') $fwd = $clean_fwd($breq->forwarding_no ?? '', $vAwb, strval($r->AWBNO));

        $fwdCarrier = trim(strval($shp->secondary_carrier ?? ''));

        // Parse vendor_raw_response if present for forwarding number & carrier (Pacific, ITDServices, FlySwift, etc.)
        if (!empty($shp->vendor_raw_response)) {
            $raw_resp = is_string($shp->vendor_raw_response) ? json_decode($shp->vendor_raw_response, true) : (is_array($shp->vendor_raw_response) ? $shp->vendor_raw_response : null);
            $raw_data = $raw_resp['response'] ?? ($raw_resp['data'] ?? ($raw_resp['Tracking'] ?? $raw_resp));
            if (is_array($raw_data)) {
                $trk_obj = isset($raw_data['Tracking'][0]) && is_array($raw_data['Tracking'][0]) ? $raw_data['Tracking'][0] : (isset($raw_data[0]) && is_array($raw_data[0]) ? $raw_data[0] : $raw_data);
                if ($fwd === '') {
                    $raw_cand = $trk_obj['VendorAWBNo2'] ?? $trk_obj['VendorAWBNo1'] ?? $trk_obj['VendorAWBNo'] ?? $trk_obj['VendorAwbNo2'] ?? $trk_obj['VendorAwbNo1'] ?? $trk_obj['VendorAwbNo'] ?? $trk_obj['ForwardingNo'] ?? $trk_obj['ForwardingNo1'] ?? $trk_obj['forwarding_no'] ?? $trk_obj['forwording_no'] ?? $trk_obj['Forwarding_No'] ?? $trk_obj['vendor_awb_2'] ?? $trk_obj['vendorAwb2'] ?? $raw_data['forwarding_no'] ?? $raw_data['forwording_no'] ?? $raw_data['vendor_awb_2'] ?? '';
                    
                    // FlySwift / ITDServices docket_info check
                    $d_info = !empty($raw_data['docket_info']) && is_array($raw_data['docket_info']) ? $raw_data['docket_info'] : (!empty($raw_data['data']['docket_info']) && is_array($raw_data['data']['docket_info']) ? $raw_data['data']['docket_info'] : null);
                    if (empty($raw_cand) && !empty($d_info)) {
                        foreach ($d_info as $info_pair) {
                            $k = ''; $v = '';
                            if (is_array($info_pair) && count($info_pair) >= 2) {
                                $k = strtolower(trim((string)$info_pair[0]));
                                $v = trim((string)$info_pair[1]);
                            } elseif (is_object($info_pair) && isset($info_pair->key)) {
                                $k = strtolower(trim((string)$info_pair->key));
                                $v = trim((string)($info_pair->value ?? ''));
                            }
                            if ((strpos($k, 'forwarding') !== false || strpos($k, 'forwording') !== false || strpos($k, 'secondary') !== false || strpos($k, 'fwd') !== false) && !empty($v)) {
                                $raw_cand = $v;
                                break;
                            }
                        }
                    }

                    $raw_fwd = $clean_fwd($raw_cand, $vAwb, strval($r->AWBNO));
                    if ($raw_fwd !== '') {
                        $fwd = $raw_fwd;
                    }
                }
                if ($fwdCarrier === '' || strtolower($fwdCarrier) === 'forwarded vendor' || strtolower($fwdCarrier) === 'carrier') {
                    $raw_c = trim(strval($trk_obj['VendorName2'] ?? ($trk_obj['VendorName'] ?? ($trk_obj['ForwardingCarrier'] ?? ($trk_obj['Carrier'] ?? ($trk_obj['carrier'] ?? ($trk_obj['secondary_carrier'] ?? '')))))));
                    if ($raw_c !== '') $fwdCarrier = $raw_c;
                }
            }
        }

        // Live vendor API fallback if forwarding number is still empty and service is configured
        if ($fwd === '' && intval($r->SERVICE ?? 0) > 0 && function_exists('pe_fetch_tracking')) {
            $c = new stdClass();
            $c->AWBNO = strval($r->AWBNO);
            $c->VENDORID1 = $vAwb ?: '';
            $c->VENDORID2 = '';
            $c->VENDCODE = $r->VENDCODE ?: '';
            $c->VENDNAME = $vendor_name ?: '';
            $c->SERVICE = intval($r->SERVICE);
            $c->API = 1;
            $c->TUSER = $r->TUSER ?: '';
            $c->TPASS = $r->TPASS ?: '';
            $c->ACCODE = $r->ACCODE ?: '';
            $c->APIKEY = $r->APIKEY ?: '';

            try {
                pe_fetch_tracking($c);
                if (!empty($c->VENDORID2)) {
                    $live_fwd = $clean_fwd($c->VENDORID2, $vAwb, strval($r->AWBNO));
                    if ($live_fwd !== '') {
                        $fwd = $live_fwd;
                        $wpdb->query($wpdb->prepare("UPDATE AWBENTRY SET VENDORAWB2 = %s WHERE AWBNO = %d", $fwd, intval($r->AWBNO)));
                        if (!empty($shp->id)) {
                            $wpdb->query($wpdb->prepare("UPDATE shipments SET vendor_awb_number_2 = %s, forwarding_no = %s WHERE id = %d", $fwd, $fwd, intval($shp->id)));
                        }
                    }
                }
            } catch (\Exception $ex) {}
        }

        // Auto-detect carrier from forwarding number pattern
        if ($fwd !== '' && ($fwdCarrier === '' || strtolower($fwdCarrier) === 'forwarded vendor' || strtolower($fwdCarrier) === 'carrier')) {
            if (preg_match('/^1Z/i', $fwd)) $fwdCarrier = 'UPS';
            elseif (preg_match('/^[0-9]{12}$/', $fwd)) $fwdCarrier = 'FedEx';
            elseif (preg_match('/^[0-9]{10}$/', $fwd)) $fwdCarrier = 'DHL';
            elseif (preg_match('/^026[0-9]{11}$/', $fwd)) $fwdCarrier = 'DPD';
        }

        // 1. Check if delivered - strictly matching Admin Portal logic (no false matches on remarks or loose terms)
        $is_delivered = false;
        if (intval($r->PODTOWEB ?? 0) === 1 || strval($r->PODTOWEB ?? '') === '1') {
            $is_delivered = true;
        } elseif (!empty($shp->status) && (stripos($shp->status, 'deliver') !== false || stripos($shp->status, 'proof of delivery') !== false || strtolower(trim($shp->status)) === 'pod')) {
            $is_delivered = true;
        } elseif (!empty($breq->status) && (stripos($breq->status, 'deliver') !== false || stripos($breq->status, 'proof of delivery') !== false || strtolower(trim($breq->status)) === 'pod')) {
            $is_delivered = true;
        } elseif (!empty($ph) && preg_match('/\b(delivered|dlvd|proof of delivery|signed by|pod)\b/i', $ph) && !preg_match('/out for|undeliver|not delivered|attempt|fail|expected|scheduled/i', $ph)) {
            $is_delivered = true;
        } else {
            $has_del_event = $wpdb->get_var($wpdb->prepare(
                "SELECT 1 FROM parcel_history WHERE (AWBNO = %d OR CAST(AWBNO AS CHAR) = %s) AND (LOWER(activity) LIKE '%%delivered%%' OR LOWER(activity) LIKE '%%proof of delivery%%' OR LOWER(activity) LIKE '%%dlvd%%' OR LOWER(activity) = 'pod' OR LOWER(activity) LIKE '%%signed by%%') AND LOWER(activity) NOT LIKE '%%out for%%' AND LOWER(activity) NOT LIKE '%%undeliver%%' AND LOWER(activity) NOT LIKE '%%not deliver%%' AND LOWER(activity) NOT LIKE '%%attempt%%' LIMIT 1",
                intval($r->AWBNO),
                strval($r->AWBNO)
            ));
            if (!empty($has_del_event)) {
                $is_delivered = true;
            }
        }

        // Status = FULL tracking activity text (show real tracking update)
        if ($is_delivered) {
            $status = (!empty($ph) && preg_match('/\b(deliver|dlvd|pod|proof|sign)\b/i', $ph) && !preg_match('/out for|undeliver/i', $ph)) ? $ph : 'Proof of Delivery';
        } elseif (!empty($ph)) {
            $status = $ph; // Full tracking activity text
        } elseif (!empty($shp->status) && !in_array(strtolower($shp->status), ['booked', 'created', 'pending'])) {
            $status = ucwords(str_replace('_', ' ', strtolower(trim($shp->status))));
        } elseif (!empty($fwd)) {
            $status = 'In Transit';
        } else {
            $status = 'Shipment Booked';
        }

        // Format last update: location + date/time (activity text is shown as the status badge above)
        $last_update = '';
        if ($latest_ph) {
            $dtText = !empty($latest_ph->date) ? date('d M Y', strtotime($latest_ph->date)) : '';
            $tmText = !empty($latest_ph->time) && $latest_ph->time !== '00:00:00' ? date('h:i A', strtotime($latest_ph->time)) : '';
            $locText = trim($latest_ph->location ?? '');
            $parts = [];
            if (!empty($locText)) $parts[] = $locText;
            if (!empty($dtText)) $parts[] = $dtText . ($tmText ? ' ' . $tmText : '');
            $last_update = implode(' · ', $parts);
        } elseif (!empty($r->BOOKINGDATE)) {
            $last_update = date('d M Y', strtotime($r->BOOKINGDATE));
        }

        // Get AWBENTRY amount: pick first non-zero from TOTAL, NETAMOUNT, CHARGES, RATE*WEIGHT, RECEIPTAMOUNT
        $awb_t = floatval(str_replace(',', '', strval($r->TOTAL ?? '0')));
        $awb_n = floatval(str_replace(',', '', strval($r->NETAMOUNT ?? '0')));
        $awb_c = floatval(str_replace(',', '', strval($r->CHARGES ?? '0')));
        $amt = $awb_t > 0 ? $awb_t : ($awb_n > 0 ? $awb_n : $awb_c);
        $charge_wt = floatval($r->CHARGEWEIGHT ?? 0) > 0 ? floatval($r->CHARGEWEIGHT) : floatval($r->WEIGHT ?? 0);
        if ($amt <= 0 && floatval($r->RATE ?? 0) > 0 && $charge_wt > 0) {
            $amt = floatval($r->RATE) * $charge_wt;
        }
        if ($amt <= 0 && floatval($r->RECEIPTAMOUNT ?? 0) > 0) {
            $amt = floatval($r->RECEIPTAMOUNT);
        }

        // Check shipments and booking_requests for amounts
        $shp_amt = 0;
        if ($shp) {
            foreach (['final_grand_total', 'grand_total', 'total_amount', 'net_amount', 'shipping_charge'] as $_af) {
                $sv = floatval($shp->$_af ?? 0);
                if ($sv > 0) { $shp_amt = $sv; break; }
            }
        }
        $breq_amt = floatval($breq->total_amount ?? 0);
        if ($breq_amt <= 0) $breq_amt = floatval($breq->shipping_charge ?? 0);

        // Pick the best available amount: shipments > booking_requests > AWBENTRY
        if ($shp_amt > 0) {
            $amt = $shp_amt;
        } elseif ($breq_amt > 0 && $amt <= 0) {
            $amt = $breq_amt;
        }

        $rec = floatval($r->RECEIPTAMOUNT ?? 0);

        $data[] = [
            'awb' => $r->AWBNO,
            'consignee' => $r->CONSIGNEE,
            'destination' => $r->DESTINATION,
            'weight' => $r->WEIGHT,
            'booking_date' => !empty($r->BOOKINGDATE) ? date('d M Y', strtotime($r->BOOKINGDATE)) : '',
            'amount' => $amt,
            'receipt_amount' => $rec,
            'balance' => max(0, $amt - $rec),
            'vendor' => $vendor_name,
            'status' => $status,
            'is_delivered' => $is_delivered,
            'last_update' => $last_update,
            'shipper' => $r->SNAME ?? '',
            'vendor_awb1' => $vAwb,
            'forwarding_number' => $fwd,
            'forwarding_carrier' => $fwdCarrier,
        ];
    }

    // Get accurate counts strictly matching Admin Portal
    $count_all = $total;
    $_st_sub = "(SELECT ph.activity FROM parcel_history ph WHERE ph.AWBNO = a.AWBNO ORDER BY ph.date DESC, ph.time DESC LIMIT 1)";
    $_del_clause = "(a.PODTOWEB = 1 OR a.PODTOWEB = '1'" .
        " OR EXISTS (SELECT 1 FROM parcel_history ph WHERE ph.AWBNO = a.AWBNO AND (LOWER(ph.activity) LIKE '%delivered%' OR LOWER(ph.activity) LIKE '%dlvd%' OR LOWER(ph.activity) LIKE '%proof of delivery%' OR LOWER(ph.activity) LIKE '%signed by%' OR LOWER(ph.activity) = 'pod') AND LOWER(ph.activity) NOT LIKE '%out for%' AND LOWER(ph.activity) NOT LIKE '%undeliver%' AND LOWER(ph.activity) NOT LIKE '%not deliver%' AND LOWER(ph.activity) NOT LIKE '%attempt%')" .
        ($has_shipments_tbl ? " OR EXISTS (SELECT 1 FROM shipments sh WHERE (sh.tracking_number = CAST(a.AWBNO AS CHAR) OR sh.order_id = CAST(a.AWBNO AS CHAR)) AND (LOWER(sh.status) LIKE '%delivered%' OR LOWER(sh.status) LIKE '%proof of delivery%' OR LOWER(sh.status) = 'pod'))" : "") .
        " OR EXISTS (SELECT 1 FROM booking_requests br WHERE (br.request_awb = CAST(a.AWBNO AS CHAR) OR br.tracking_number = CAST(a.AWBNO AS CHAR)) AND (LOWER(br.status) LIKE '%delivered%' OR LOWER(br.status) LIKE '%proof of delivery%' OR LOWER(br.status) = 'pod'))" .
        ")";
    $count_delivered = intval($wpdb->get_var("SELECT COUNT(*) FROM AWBENTRY a WHERE $where AND $_del_clause"));
    $count_delivered = min($count_delivered, $count_all);
    $count_transit = intval($wpdb->get_var("SELECT COUNT(*) FROM AWBENTRY a WHERE $where AND NOT $_del_clause AND (LOWER(COALESCE($_st_sub, '')) LIKE '%transit%' OR LOWER(COALESCE($_st_sub, '')) LIKE '%departed%' OR (a.VENDORAWB1 != '' AND a.VENDORAWB1 IS NOT NULL))"));

    // Also check page rows for delivered items (fallback if SQL count is lower)
    $page_del_count = 0;
    foreach ($data as $dr) {
        if (!empty($dr['is_delivered'])) $page_del_count++;
    }
    if ($page_del_count > $count_delivered) {
        $count_delivered = min($page_del_count, $count_all);
    }

    // Calculate customer total amount across ALL shipments using all available data sources
    // Safe numeric casting using + 0 for MySQL string coercion without syntax/mode errors
    // Order: 1) shipments table if exists, 2) AWBENTRY actual billed amounts, 3) booking_requests fallback
    $_amt_expr = "COALESCE(";
    if ($has_shipments_tbl) {
        $_amt_expr .= "(SELECT COALESCE(NULLIF(sh.final_grand_total + 0, 0), NULLIF(sh.grand_total + 0, 0), NULLIF(sh.total_amount + 0, 0), NULLIF(sh.net_amount + 0, 0), NULLIF(sh.shipping_charge + 0, 0)) FROM shipments sh WHERE sh.tracking_number = CAST(a.AWBNO AS CHAR) OR sh.order_id = CAST(a.AWBNO AS CHAR) LIMIT 1), ";
    }
    $_amt_expr .= "NULLIF(ROUND(REPLACE(REPLACE(COALESCE(a.TOTAL, '0'), ',', ''), ' ', '') + 0, 2), 0), ";
    $_amt_expr .= "NULLIF(ROUND(REPLACE(REPLACE(COALESCE(a.NETAMOUNT, '0'), ',', ''), ' ', '') + 0, 2), 0), ";
    $_amt_expr .= "NULLIF(ROUND(REPLACE(REPLACE(COALESCE(a.CHARGES, '0'), ',', ''), ' ', '') + 0, 2), 0), ";
    $_amt_expr .= "NULLIF(ROUND((COALESCE(a.RATE, 0) + 0) * (COALESCE(NULLIF(a.CHARGEWEIGHT + 0, 0), a.WEIGHT + 0, 0)), 2), 0), ";
    $_amt_expr .= "NULLIF(ROUND(REPLACE(REPLACE(COALESCE(a.RECEIPTAMOUNT, '0'), ',', ''), ' ', '') + 0, 2), 0), ";
    if (!empty($has_booking_req_tbl)) {
        $_amt_expr .= "(SELECT NULLIF(br.shipping_charge + 0, 0) FROM booking_requests br WHERE br.request_awb = CAST(a.AWBNO AS CHAR) OR br.tracking_number = CAST(a.AWBNO AS CHAR) LIMIT 1), ";
    }
    $_amt_expr .= "0)";

    $total_billed_amount = floatval($wpdb->get_var(
        "SELECT SUM($_amt_expr) FROM AWBENTRY a WHERE $where AND a.AWBNO > 0"
    ) ?? 0);

    // Grand total of all shipments in this dashboard scope (independent of search filter or pagination)
    $total_all_amount = floatval($wpdb->get_var(
        "SELECT SUM($_amt_expr) FROM AWBENTRY a WHERE " . (!empty($where_base) ? $where_base : $where) . " AND a.AWBNO > 0"
    ) ?? 0);

    // Safety fallback: if total is still 0, sum basic amount fields across matching shipments (not just current page)
    if ($total_billed_amount <= 0) {
        $fallback_sum = floatval($wpdb->get_var(
            "SELECT SUM(COALESCE(
                NULLIF(ROUND(REPLACE(REPLACE(COALESCE(a.TOTAL, '0'), ',', ''), ' ', '') + 0, 2), 0),
                NULLIF(ROUND(REPLACE(REPLACE(COALESCE(a.NETAMOUNT, '0'), ',', ''), ' ', '') + 0, 2), 0),
                NULLIF(ROUND(REPLACE(REPLACE(COALESCE(a.CHARGES, '0'), ',', ''), ' ', '') + 0, 2), 0),
                NULLIF(ROUND((COALESCE(a.RATE, 0) + 0) * (COALESCE(NULLIF(a.CHARGEWEIGHT + 0, 0), a.WEIGHT + 0, 0)), 2), 0),
                NULLIF(ROUND(REPLACE(REPLACE(COALESCE(a.RECEIPTAMOUNT, '0'), ',', ''), ' ', '') + 0, 2), 0),
                " . (!empty($has_booking_req_tbl) ? "(SELECT NULLIF(br.shipping_charge + 0, 0) FROM booking_requests br WHERE br.request_awb = CAST(a.AWBNO AS CHAR) OR br.tracking_number = CAST(a.AWBNO AS CHAR) LIMIT 1), " : "") . "
                0
            )) FROM AWBENTRY a WHERE $where AND a.AWBNO > 0"
        ) ?? 0);
        if ($fallback_sum > 0) {
            $total_billed_amount = $fallback_sum;
        }
    }
    if ($total_all_amount <= 0) {
        $fallback_all_sum = floatval($wpdb->get_var(
            "SELECT SUM(COALESCE(
                NULLIF(ROUND(REPLACE(REPLACE(COALESCE(a.TOTAL, '0'), ',', ''), ' ', '') + 0, 2), 0),
                NULLIF(ROUND(REPLACE(REPLACE(COALESCE(a.NETAMOUNT, '0'), ',', ''), ' ', '') + 0, 2), 0),
                NULLIF(ROUND(REPLACE(REPLACE(COALESCE(a.CHARGES, '0'), ',', ''), ' ', '') + 0, 2), 0),
                NULLIF(ROUND((COALESCE(a.RATE, 0) + 0) * (COALESCE(NULLIF(a.CHARGEWEIGHT + 0, 0), a.WEIGHT + 0, 0)), 2), 0),
                NULLIF(ROUND(REPLACE(REPLACE(COALESCE(a.RECEIPTAMOUNT, '0'), ',', ''), ' ', '') + 0, 2), 0),
                " . (!empty($has_booking_req_tbl) ? "(SELECT NULLIF(br.shipping_charge + 0, 0) FROM booking_requests br WHERE br.request_awb = CAST(a.AWBNO AS CHAR) OR br.tracking_number = CAST(a.AWBNO AS CHAR) LIMIT 1), " : "") . "
                0
            )) FROM AWBENTRY a WHERE " . (!empty($where_base) ? $where_base : $where) . " AND a.AWBNO > 0"
        ) ?? 0);
        $total_all_amount = $fallback_all_sum > 0 ? $fallback_all_sum : $total_billed_amount;
    }

    wp_send_json_success([
        'rows' => $data,
        'total' => $total,
        'pages' => max(1, ceil($total / $per)),
        'page' => $page,
        'total_amount' => $total_billed_amount,
        'total_billed_amount' => $total_billed_amount,
        'total_all_amount' => $total_all_amount,
        'count_all' => $count_all,
        'count_delivered' => $count_delivered,
        'count_transit' => $count_transit,
        'counts' => [
            'all' => $count_all,
            'delivered' => $count_delivered,
            'transit' => $count_transit,
            'booked' => max(0, $count_all - $count_delivered - $count_transit),
        ],
    ]);
}
add_action('wp_ajax_pe_cp_shipments', 'pe_cp_ajax_shipments');
add_action('wp_ajax_nopriv_pe_cp_shipments', 'pe_cp_ajax_shipments');

// ══════════════════════════════════════
//  AJAX: LIVE TRACK STATUS (lightweight, single AWB)
// ══════════════════════════════════════
function pe_cp_ajax_track_status()
{
    pe_cp_check_ajax();
    global $wpdb;

    $awb = intval($_POST['awb'] ?? 0);
    if (!$awb) {
        wp_send_json_error(['message' => 'AWB required']);
    }

    $status = '';
    $last_update = '';
    $is_delivered = false;
    $forwarding_number = '';
    $forwarding_carrier = '';

    $clean_fwd = function($val, $primaryVendor = '', $ourAwb = '') {
        if ($val === null) return '';
        $s = trim(strval($val));
        if ($s === '' || $s === '0' || $s === '0.00' || $s === 'null' || $s === 'undefined' || $s === 'None' || $s === '-' || $s === '—') return '';
        $s = preg_replace('/^FWD\s*[:\-]\s*/i', '', $s);
        $s = trim($s);
        if ($s === '' || $s === $primaryVendor || $s === $ourAwb) return '';
        if (stripos($s, 'not found') !== false || stripos($s, 'error') !== false || strtolower($s) === 'pending') return '';
        return $s;
    };

    $awb_row = $wpdb->get_row($wpdb->prepare("SELECT a.SERVICE, a.VENDCODE, a.VENDNAME, a.VENDORAWB1, a.VENDORAWB2, a.PODTOWEB, a.TUSER, a.TPASS, a.ACCODE, a.APIKEY FROM AWBENTRY a WHERE a.AWBNO = %d LIMIT 1", $awb));
    $vAwb = trim(strval($awb_row->VENDORAWB1 ?? ''));
    $existing_fwd = $clean_fwd($awb_row->VENDORAWB2 ?? '', $vAwb, strval($awb));
    if (!empty($existing_fwd)) {
        $forwarding_number = $existing_fwd;
    }
    if ($awb_row && (intval($awb_row->PODTOWEB ?? 0) === 1 || strval($awb_row->PODTOWEB ?? '') === '1')) {
        $is_delivered = true;
    }

    // 1. Query Admin Portal Search API for accurate shipment data, forwarding number & delivery status
    $admin_search_url = 'https://purple-raccoon-753399.hostingersite.com/api/tracking/search?tracking_number=' . urlencode(strval($awb));
    $search_resp = wp_remote_get($admin_search_url, ['timeout' => 8, 'sslverify' => false]);
    if (!is_wp_error($search_resp)) {
        $search_body = json_decode(wp_remote_retrieve_body($search_resp), true);
        if (!empty($search_body['success']) && !empty($search_body['shipment'])) {
            $admin_shp = $search_body['shipment'];
            if (empty($forwarding_number)) {
                $cand_fwd = $clean_fwd($admin_shp['forwarding_no'] ?? '', $vAwb, strval($awb));
                if ($cand_fwd === '') $cand_fwd = $clean_fwd($admin_shp['vendor_awb_number_2'] ?? '', $vAwb, strval($awb));
                if ($cand_fwd !== '') {
                    $forwarding_number = $cand_fwd;
                }
            }
            if (empty($forwarding_carrier) && !empty($admin_shp['secondary_carrier']) && !in_array(strtolower($admin_shp['secondary_carrier']), ['carrier', 'forwarded vendor'])) {
                $forwarding_carrier = trim(strval($admin_shp['secondary_carrier']));
            }
            $adm_st = strtolower(trim($admin_shp['status'] ?? ''));
            if ($adm_st === 'delivered' || $adm_st === 'proof of delivery' || $adm_st === 'pod' || strpos($adm_st, 'deliver') !== false) {
                $is_delivered = true;
                if (empty($status) || $status === 'Shipment Booked') {
                    $status = ($adm_st === 'proof of delivery' || $adm_st === 'pod') ? 'Proof of Delivery' : 'Delivered';
                }
            }
            if (empty($status) && !empty($admin_shp['tracking_events']) && is_array($admin_shp['tracking_events'])) {
                $ev = $admin_shp['tracking_events'][0];
                $status = $ev['description'] ?? ($ev['status'] ?? '');
                $loc = $ev['location'] ?? '';
                $dt = !empty($ev['event_time']) ? date('d M Y', strtotime($ev['event_time'])) : '';
                $tm = !empty($ev['event_time']) ? date('h:i A', strtotime($ev['event_time'])) : '';
                $parts = array_filter([$loc, trim($dt . ' ' . $tm)]);
                $last_update = implode(' · ', $parts);
            }
        }
    }

    // 2. Fetch real-time live tracking from Admin Portal API
    $live_api_url = 'https://purple-raccoon-753399.hostingersite.com/api/tracking/live?awb=' . urlencode(strval($awb));
    $api_resp = wp_remote_get($live_api_url, ['timeout' => 8, 'sslverify' => false]);

    if (!is_wp_error($api_resp)) {
        $body = json_decode(wp_remote_retrieve_body($api_resp), true);
        if (!empty($body['success']) && !empty($body['tracking'])) {
            $trk = $body['tracking'];
            $live_status = $trk['currentStatus'] ?? '';
            $live_stage = $trk['currentStage'] ?? '';

            // Check if delivered from live tracking
            if ($live_stage === 'delivered' || (preg_match('/\b(delivered|dlvd|proof of delivery|signed by|pod)\b/i', $live_status) && !preg_match('/out for|undeliver|not delivered|attempt|fail|expected|scheduled/i', $live_status))) {
                $is_delivered = true;
            }

            // Extract forwarding number from live tracking (only secondary vendor AWB / forwardingNo, NEVER primary AWB)
            if (empty($forwarding_number)) {
                $candFwd = trim(strval($trk['shipmentInfo']['vendorAwbNo'] ?? ($trk['shipmentInfo']['forwardingNo'] ?? ($trk['shipmentInfo']['secondaryAwb'] ?? ''))));
                $candFwd = $clean_fwd($candFwd, $vAwb, strval($awb));
                if ($candFwd !== '') {
                    $forwarding_number = $candFwd;
                }
            }
            if (empty($forwarding_carrier) && !empty($trk['shipmentInfo']['secondaryCarrier']) && !in_array(strtolower($trk['shipmentInfo']['secondaryCarrier']), ['carrier', 'forwarded vendor'])) {
                $forwarding_carrier = trim(strval($trk['shipmentInfo']['secondaryCarrier']));
            }

            // Build from latest event
            if (!empty($trk['events']) && is_array($trk['events'])) {
                $ev = $trk['events'][0];
                $act = $ev['status'] ?? ($ev['activity'] ?? ($ev['event_description'] ?? ''));
                $loc = $ev['location'] ?? '';
                $dt = $ev['date'] ?? '';
                $tm = $ev['time'] ?? '';

                $status = !empty($act) ? $act : $live_status;

                if (preg_match('/\b(delivered|dlvd|proof of delivery|signed by|pod)\b/i', $status) && !preg_match('/out for|undeliver|not delivered|attempt|fail|expected|scheduled/i', $status)) {
                    $is_delivered = true;
                }

                $parts = [];
                if (!empty($loc)) $parts[] = $loc;
                if (!empty($dt)) $parts[] = $dt . (!empty($tm) ? ' ' . $tm : '');
                $last_update = implode(' · ', $parts);
            } elseif (!empty($live_status)) {
                $status = $live_status;
            }
        }
    }

    // 3. Fallback to parcel_history if live API failed or returned nothing
    if (empty($status)) {
        $latest_ph = $wpdb->get_row($wpdb->prepare(
            "SELECT activity, date, time, location FROM parcel_history WHERE AWBNO = %d ORDER BY date DESC, time DESC LIMIT 1",
            $awb
        ));
        if ($latest_ph && !empty($latest_ph->activity)) {
            $status = trim($latest_ph->activity);
            $parts = [];
            if (!empty($latest_ph->location)) $parts[] = trim($latest_ph->location);
            if (!empty($latest_ph->date)) {
                $dtStr = date('d M Y', strtotime($latest_ph->date));
                $tmStr = (!empty($latest_ph->time) && $latest_ph->time !== '00:00:00') ? ' ' . date('h:i A', strtotime($latest_ph->time)) : '';
                $parts[] = $dtStr . $tmStr;
            }
            $last_update = implode(' · ', $parts);

            if (preg_match('/\b(delivered|dlvd|proof of delivery|signed by|pod)\b/i', $status) && !preg_match('/out for|undeliver|not delivered|attempt|fail|expected|scheduled/i', $status)) {
                $is_delivered = true;
            }
        }
    }

    // 4. Check parcel_history for any delivery event
    if (!$is_delivered) {
        $has_del_event = $wpdb->get_var($wpdb->prepare(
            "SELECT 1 FROM parcel_history WHERE AWBNO = %d AND (LOWER(activity) LIKE '%%delivered%%' OR LOWER(activity) LIKE '%%proof of delivery%%' OR LOWER(activity) LIKE '%%dlvd%%' OR LOWER(activity) = 'pod' OR LOWER(activity) LIKE '%%signed by%%') AND LOWER(activity) NOT LIKE '%%out for%%' AND LOWER(activity) NOT LIKE '%%undeliver%%' AND LOWER(activity) NOT LIKE '%%not deliver%%' AND LOWER(activity) NOT LIKE '%%attempt%%' LIMIT 1",
            $awb
        ));
        if (!empty($has_del_event)) {
            $is_delivered = true;
        }
    }

    // 5. Fallback to pe_fetch_tracking if forwarding number is still empty and service configured
    if (empty($forwarding_number) && $awb_row && intval($awb_row->SERVICE ?? 0) > 0 && function_exists('pe_fetch_tracking')) {
        $c = new stdClass();
        $c->AWBNO = strval($awb);
        $c->VENDORID1 = $awb_row->VENDORAWB1 ?: '';
        $c->VENDORID2 = '';
        $c->VENDCODE = $awb_row->VENDCODE ?: '';
        $c->VENDNAME = $awb_row->VENDNAME ?: '';
        $c->SERVICE = intval($awb_row->SERVICE);
        $c->API = 1;
        $c->TUSER = $awb_row->TUSER ?: '';
        $c->TPASS = $awb_row->TPASS ?: '';
        $c->ACCODE = $awb_row->ACCODE ?: '';
        $c->APIKEY = $awb_row->APIKEY ?: '';
        try {
            pe_fetch_tracking($c);
            if (!empty($c->VENDORID2)) {
                $fwd_clean = $clean_fwd($c->VENDORID2, $vAwb, strval($awb));
                if (!empty($fwd_clean)) {
                    $forwarding_number = $fwd_clean;
                }
            }
        } catch (\Exception $ex) {}
    }

    // Auto-detect carrier if carrier name is empty
    if (!empty($forwarding_number) && empty($forwarding_carrier)) {
        if (preg_match('/^1Z/i', $forwarding_number)) $forwarding_carrier = 'UPS';
        elseif (preg_match('/^[0-9]{12}$/', $forwarding_number)) $forwarding_carrier = 'FedEx';
        elseif (preg_match('/^[0-9]{10}$/', $forwarding_number)) $forwarding_carrier = 'DHL';
        elseif (preg_match('/^026[0-9]{11}$/', $forwarding_number)) $forwarding_carrier = 'DPD';
    }

    // Auto-persist forwarding number and delivery status to AWBENTRY
    if (!empty($forwarding_number)) {
        $wpdb->query($wpdb->prepare("UPDATE AWBENTRY SET VENDORAWB2 = %s WHERE AWBNO = %d", $forwarding_number, $awb));
    }
    if ($is_delivered) {
        $wpdb->query($wpdb->prepare("UPDATE AWBENTRY SET PODTOWEB = 1 WHERE AWBNO = %d", $awb));
    }

    wp_send_json_success([
        'awb' => $awb,
        'status' => $status ?: ($is_delivered ? 'Proof of Delivery' : 'Shipment Booked'),
        'last_update' => $last_update,
        'is_delivered' => $is_delivered,
        'forwarding_number' => $forwarding_number,
        'forwarding_carrier' => $forwarding_carrier,
    ]);
}
add_action('wp_ajax_pe_cp_track_status', 'pe_cp_ajax_track_status');
add_action('wp_ajax_nopriv_pe_cp_track_status', 'pe_cp_ajax_track_status');

// ══════════════════════════════════════
//  AJAX: SHIPMENT DETAIL + TRACKING
// ══════════════════════════════════════

function pe_cp_ajax_shipment_detail()
{
    pe_cp_check_ajax();
    global $wpdb;

    $awb = intval($_POST['awb'] ?? 0);
    if (!$awb) {
        wp_send_json_error(['message' => 'AWB number required']);
    }

    $row = $wpdb->get_row($wpdb->prepare(
        "SELECT a.* FROM AWBENTRY a WHERE a.AWBNO = %d",
        $awb
    ));

    if (!$row) {
        wp_send_json_error(['message' => 'Shipment not found']);
    }

    // Tracking history from database
    $db_history = $wpdb->get_results($wpdb->prepare(
        "SELECT activity, date, time, location FROM parcel_history WHERE AWBNO = %d ORDER BY date DESC, time DESC",
        $awb
    ));

    $totAmount = floatval($row->TOTAL ?: ($row->NETAMOUNT ?: $row->CHARGES));
    $recAmount = floatval($row->RECEIPTAMOUNT ?? 0);

    // Look up booking_requests for detailed addresses if available
    $breq = $wpdb->get_row($wpdb->prepare(
        "SELECT * FROM booking_requests WHERE request_awb = %s OR tracking_number = %s LIMIT 1",
        strval($row->AWBNO),
        strval($row->AWBNO)
    ));

    $s_addr = trim(implode(', ', array_filter([$row->SADDRESS1 ?? '', $row->SADDRESS2 ?? '', $row->SADDRESS3 ?? '', $row->SCITY ?? '', $row->SPINCODE ?? ''])));
    if (empty($s_addr) && $breq) {
        $s_addr = trim(implode(', ', array_filter([$breq->sender_address ?? '', $breq->sender_address_2 ?? '', $breq->sender_city ?? '', $breq->sender_state ?? '', $breq->sender_pincode ?? '', $breq->sender_country ?? ''])));
    }

    $c_addr = trim(implode(', ', array_filter([$row->CNEEADDRESS1 ?? '', $row->CNEEADDRESS2 ?? '', $row->CNEEADDRESS3 ?? '', $row->CNEECITY ?? '', $row->CNEEPINCODE ?? '', $row->DESTNAME ?? ''])));
    if (empty($c_addr) && $breq) {
        $c_addr = trim(implode(', ', array_filter([$breq->receiver_address ?? '', $breq->receiver_address_2 ?? '', $breq->receiver_city ?? '', $breq->receiver_state ?? '', $breq->receiver_pincode ?? '', $breq->receiver_country ?? ''])));
    }

    // Look up node shipments table if exists
    $shp = null;
    if (!empty($wpdb->get_var("SHOW TABLES LIKE 'shipments'"))) {
        $shp = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM shipments WHERE tracking_number = %s OR order_id = %s OR vendor_awb_number = %s LIMIT 1",
            strval($row->AWBNO),
            strval($row->AWBNO),
            strval($row->AWBNO)
        ));
        if (!$shp && !empty($row->VENDORAWB1)) {
            $shp = $wpdb->get_row($wpdb->prepare(
                "SELECT * FROM shipments WHERE vendor_awb_number = %s OR tracking_number = %s LIMIT 1",
                strval($row->VENDORAWB1),
                strval($row->VENDORAWB1)
            ));
        }
    }

    $shp_amt = 0;
    if ($shp) {
        foreach (['final_grand_total', 'grand_total', 'total_amount', 'net_amount', 'shipping_charge'] as $_af) {
            $sv = floatval($shp->$_af ?? 0);
            if ($sv > 0) { $shp_amt = $sv; break; }
        }
    }
    $breq_amt = floatval($breq->total_amount ?? 0);
    if ($breq_amt <= 0) $breq_amt = floatval($breq->shipping_charge ?? 0);

    if ($shp_amt > 0) {
        $totAmount = $shp_amt;
    } elseif ($breq_amt > 0 && $totAmount <= 0) {
        $totAmount = $breq_amt;
    } elseif ($totAmount <= 0) {
        if (!empty($row->RATE) && !empty($row->CHARGEWEIGHT)) {
            $totAmount = floatval($row->RATE) * floatval($row->CHARGEWEIGHT);
        } elseif (!empty($row->RECEIPTAMOUNT)) {
            $totAmount = floatval($row->RECEIPTAMOUNT);
        }
    }

    $vendor_name = trim(strval($shp->vendor_code ?? ''));
    if ($vendor_name === '') $vendor_name = trim(strval($row->vendor ?? ($row->VENDNAME ?? '')));

    $vendor_awb = trim(strval($shp->vendor_awb_number ?? ''));
    if ($vendor_awb === '') $vendor_awb = trim(strval($row->VENDORAWB1 ?? ''));

    $clean_detail_fwd = function($val, $primaryVendor = '', $ourAwb = '') {
        if ($val === null) return '';
        $s = trim(strval($val));
        if ($s === '' || $s === '0' || $s === '0.00' || $s === 'null' || $s === 'undefined' || $s === 'None' || $s === '-' || $s === '—') return '';
        $s = preg_replace('/^FWD\s*[:\-]\s*/i', '', $s);
        $s = trim($s);
        if ($s === '' || $s === $primaryVendor || $s === $ourAwb) return '';
        if (stripos($s, 'not found') !== false || stripos($s, 'error') !== false || strtolower($s) === 'pending') return '';
        return $s;
    };

    $forwarding_no = $clean_detail_fwd($shp->forwarding_no ?? '', $vendor_awb, strval($row->AWBNO));
    if ($forwarding_no === '') $forwarding_no = $clean_detail_fwd($shp->vendor_awb_number_2 ?? '', $vendor_awb, strval($row->AWBNO));
    if ($forwarding_no === '') $forwarding_no = $clean_detail_fwd($row->VENDORAWB2 ?? '', $vendor_awb, strval($row->AWBNO));
    if ($forwarding_no === '') $forwarding_no = $clean_detail_fwd($breq->forwarding_no ?? '', $vendor_awb, strval($row->AWBNO));

    $secondary_carrier = trim(strval($shp->secondary_carrier ?? ''));

    // Query Admin Portal Search API if forwarding number is missing
    if ($forwarding_no === '') {
        $admin_search_url = 'https://purple-raccoon-753399.hostingersite.com/api/tracking/search?tracking_number=' . urlencode(strval($row->AWBNO));
        $search_resp = wp_remote_get($admin_search_url, ['timeout' => 6, 'sslverify' => false]);
        if (!is_wp_error($search_resp)) {
            $search_body = json_decode(wp_remote_retrieve_body($search_resp), true);
            if (!empty($search_body['success']) && !empty($search_body['shipment'])) {
                $admin_shp = $search_body['shipment'];
                $cand_fwd = $clean_detail_fwd($admin_shp['forwarding_no'] ?? '', $vendor_awb, strval($row->AWBNO));
                if ($cand_fwd === '') $cand_fwd = $clean_detail_fwd($admin_shp['vendor_awb_number_2'] ?? '', $vendor_awb, strval($row->AWBNO));
                if ($cand_fwd !== '') {
                    $forwarding_no = $cand_fwd;
                    $wpdb->query($wpdb->prepare("UPDATE AWBENTRY SET VENDORAWB2 = %s WHERE AWBNO = %d", $forwarding_no, intval($row->AWBNO)));
                }
                if (empty($secondary_carrier) && !empty($admin_shp['secondary_carrier']) && !in_array(strtolower($admin_shp['secondary_carrier']), ['carrier', 'forwarded vendor'])) {
                    $secondary_carrier = trim(strval($admin_shp['secondary_carrier']));
                }
            }
        }
    }

    // Parse vendor_raw_response if present
    if (!empty($shp->vendor_raw_response)) {
        $raw_resp = is_string($shp->vendor_raw_response) ? json_decode($shp->vendor_raw_response, true) : (is_array($shp->vendor_raw_response) ? $shp->vendor_raw_response : null);
        $raw_data = $raw_resp['response'] ?? ($raw_resp['data'] ?? ($raw_resp['Tracking'] ?? $raw_resp));
        if (is_array($raw_data)) {
            $trk_obj = isset($raw_data['Tracking'][0]) && is_array($raw_data['Tracking'][0]) ? $raw_data['Tracking'][0] : (isset($raw_data[0]) && is_array($raw_data[0]) ? $raw_data[0] : $raw_data);
            if ($forwarding_no === '') {
                $raw_cand = $trk_obj['VendorAWBNo2'] ?? $trk_obj['VendorAWBNo1'] ?? $trk_obj['VendorAWBNo'] ?? $trk_obj['VendorAwbNo2'] ?? $trk_obj['VendorAwbNo1'] ?? $trk_obj['VendorAwbNo'] ?? $trk_obj['ForwardingNo'] ?? $trk_obj['ForwardingNo1'] ?? $trk_obj['forwarding_no'] ?? $trk_obj['forwording_no'] ?? $trk_obj['Forwarding_No'] ?? $trk_obj['vendor_awb_2'] ?? $trk_obj['vendorAwb2'] ?? $raw_data['forwarding_no'] ?? $raw_data['forwording_no'] ?? $raw_data['vendor_awb_2'] ?? '';
                
                $d_info = !empty($raw_data['docket_info']) && is_array($raw_data['docket_info']) ? $raw_data['docket_info'] : (!empty($raw_data['data']['docket_info']) && is_array($raw_data['data']['docket_info']) ? $raw_data['data']['docket_info'] : null);
                if (empty($raw_cand) && !empty($d_info)) {
                    foreach ($d_info as $info_pair) {
                        $k = ''; $v = '';
                        if (is_array($info_pair) && count($info_pair) >= 2) {
                            $k = strtolower(trim((string)$info_pair[0]));
                            $v = trim((string)$info_pair[1]);
                        } elseif (is_object($info_pair) && isset($info_pair->key)) {
                            $k = strtolower(trim((string)$info_pair->key));
                            $v = trim((string)($info_pair->value ?? ''));
                        }
                        if ((strpos($k, 'forwarding') !== false || strpos($k, 'forwording') !== false || strpos($k, 'secondary') !== false || strpos($k, 'fwd') !== false) && !empty($v)) {
                            $raw_cand = $v;
                            break;
                        }
                    }
                }

                $raw_fwd = $clean_detail_fwd($raw_cand, $vendor_awb, strval($row->AWBNO));
                if ($raw_fwd !== '') {
                    $forwarding_no = $raw_fwd;
                }
            }
            if ($secondary_carrier === '' || strtolower($secondary_carrier) === 'forwarded vendor' || strtolower($secondary_carrier) === 'carrier') {
                $raw_c = trim(strval($trk_obj['VendorName2'] ?? ($trk_obj['VendorName'] ?? ($trk_obj['ForwardingCarrier'] ?? ($trk_obj['Carrier'] ?? ($trk_obj['carrier'] ?? ($trk_obj['secondary_carrier'] ?? '')))))));
                if ($raw_c !== '') $secondary_carrier = $raw_c;
            }
        }
    }

    // Live vendor API fallback if forwarding number is still empty and service configured
    if ($forwarding_no === '' && intval($row->SERVICE ?? 0) > 0 && function_exists('pe_fetch_tracking')) {
        $c = new stdClass();
        $c->AWBNO = strval($row->AWBNO);
        $c->VENDORID1 = $vendor_awb ?: '';
        $c->VENDORID2 = '';
        $c->VENDCODE = $row->VENDCODE ?: '';
        $c->VENDNAME = $vendor_name ?: '';
        $c->SERVICE = intval($row->SERVICE);
        $c->API = 1;
        $c->TUSER = $row->TUSER ?: '';
        $c->TPASS = $row->TPASS ?: '';
        $c->ACCODE = $row->ACCODE ?: '';
        $c->APIKEY = $row->APIKEY ?: '';
        try {
            pe_fetch_tracking($c);
            if (!empty($c->VENDORID2)) {
                $live_fwd = $clean_detail_fwd($c->VENDORID2, $vendor_awb, strval($row->AWBNO));
                if ($live_fwd !== '') {
                    $forwarding_no = $live_fwd;
                    $wpdb->query($wpdb->prepare("UPDATE AWBENTRY SET VENDORAWB2 = %s WHERE AWBNO = %d", $forwarding_no, intval($row->AWBNO)));
                    if (!empty($shp->id)) {
                        $wpdb->query($wpdb->prepare("UPDATE shipments SET vendor_awb_number_2 = %s, forwarding_no = %s WHERE id = %d", $forwarding_no, $forwarding_no, intval($shp->id)));
                    }
                }
            }
        } catch (\Exception $ex) {}
    }

    // Auto-detect carrier from forwarding number pattern
    if ($forwarding_no !== '' && ($secondary_carrier === '' || strtolower($secondary_carrier) === 'forwarded vendor' || strtolower($secondary_carrier) === 'carrier')) {
        if (preg_match('/^1Z/i', $forwarding_no)) $secondary_carrier = 'UPS';
        elseif (preg_match('/^[0-9]{12}$/', $forwarding_no)) $secondary_carrier = 'FedEx';
        elseif (preg_match('/^[0-9]{10}$/', $forwarding_no)) $secondary_carrier = 'DHL';
        elseif (preg_match('/^026[0-9]{11}$/', $forwarding_no)) $secondary_carrier = 'DPD';
    }
    $content_desc = trim(strval($shp->content_description ?? ($row->PRODNAME ?? ($breq->content_description ?? ''))));
    $length = floatval($shp->length ?? ($breq->length ?? 0));
    $breadth = floatval($shp->breadth ?? ($breq->breadth ?? 0));
    $height = floatval($shp->height ?? ($breq->height ?? 0));
    $chargeable_weight = floatval($shp->final_chargeable_weight ?? ($shp->chargeable_weight ?? ($row->CHARGEWEIGHT ?? 0)));
    $actual_weight = floatval($shp->weight ?? ($row->ACTUALWEIGHT ?? 0));
    $pieces = intval($shp->no_of_pieces ?? ($row->PIECES ?? 1));

    // Parse parcels and invoice items from the node shipments table or booking request
    $parcels = [];
    if (!empty($shp->parcels)) {
        $parsed = is_string($shp->parcels) ? json_decode($shp->parcels, true) : (is_array($shp->parcels) ? $shp->parcels : []);
        if (is_array($parsed))
            $parcels = $parsed;
    }
    if (empty($parcels) && $breq && !empty($breq->parcels)) {
        $parsed = is_string($breq->parcels) ? json_decode($breq->parcels, true) : (is_array($breq->parcels) ? $breq->parcels : []);
        if (is_array($parsed))
            $parcels = $parsed;
    }

    $invoice_items = [];
    if (!empty($shp->invoice_items)) {
        $parsed = is_string($shp->invoice_items) ? json_decode($shp->invoice_items, true) : (is_array($shp->invoice_items) ? $shp->invoice_items : []);
        if (is_array($parsed))
            $invoice_items = $parsed;
    }
    if (empty($invoice_items) && $breq && !empty($breq->invoice_items)) {
        $parsed = is_string($breq->invoice_items) ? json_decode($breq->invoice_items, true) : (is_array($breq->invoice_items) ? $breq->invoice_items : []);
        if (is_array($parsed))
            $invoice_items = $parsed;
    }

    // If invoice_items is still empty but parcels have nested items (e.g. from multi-box entry)
    if (empty($invoice_items) && !empty($parcels)) {
        foreach ($parcels as $pIndex => $parcel) {
            if (!empty($parcel['items']) && is_array($parcel['items'])) {
                foreach ($parcel['items'] as $pItem) {
                    $pItem['box_no'] = $pItem['box_no'] ?? ($parcel['box_no'] ?? ($pIndex + 1));
                    $invoice_items[] = $pItem;
                }
            }
        }
    }

    // ── Live Tracking API Integration ──
    $tracking_events = [];
    $live_status = '';
    $live_stage = '';

    // Fetch real-time live tracking from the Admin Portal live tracking API
    $live_api_url = 'https://purple-raccoon-753399.hostingersite.com/api/tracking/live?awb=' . urlencode(strval($awb));
    $api_resp = wp_remote_get($live_api_url, ['timeout' => 5, 'sslverify' => false]);
    if (!is_wp_error($api_resp)) {
        $body = json_decode(wp_remote_retrieve_body($api_resp), true);
        if (!empty($body['success']) && !empty($body['tracking'])) {
            $trk = $body['tracking'];
            $live_status = $trk['currentStatus'] ?? '';
            $live_stage = $trk['currentStage'] ?? '';

            // Extract forwarding number from live tracking if still missing
            if ($forwarding_no === '') {
                $candFwd = trim(strval($trk['shipmentInfo']['vendorAwbNo'] ?? ''));
                $candFwd = preg_replace('/^FWD\s*[:\-]\s*/i', '', $candFwd);
                $candPrimary = trim(strval($trk['shipmentInfo']['awbNo'] ?? ''));
                if (!empty($candFwd) && $candFwd !== $candPrimary && $candFwd !== strval($row->AWBNO) && $candFwd !== $vendor_awb && $candFwd !== '0' && $candFwd !== '—') {
                    $forwarding_no = $candFwd;
                    $wpdb->query($wpdb->prepare("UPDATE AWBENTRY SET VENDORAWB2 = %s WHERE AWBNO = %d", $forwarding_no, intval($row->AWBNO)));
                    if (!empty($shp->id)) {
                        $wpdb->query($wpdb->prepare("UPDATE shipments SET vendor_awb_number_2 = %s, forwarding_no = %s WHERE id = %d", $forwarding_no, $forwarding_no, intval($shp->id)));
                    }
                }
            }
            if ((empty($secondary_carrier) || strtolower($secondary_carrier) === 'carrier' || strtolower($secondary_carrier) === 'forwarded vendor') && !empty($trk['shipmentInfo']['secondaryCarrier']) && $trk['shipmentInfo']['secondaryCarrier'] !== 'Carrier' && $trk['shipmentInfo']['secondaryCarrier'] !== 'Forwarded Vendor') {
                $secondary_carrier = trim(strval($trk['shipmentInfo']['secondaryCarrier']));
            }

            // Fallback invoice items from live tracking internalShipment if database has none
            if (empty($invoice_items) && !empty($trk['internalShipment']['invoice_items'])) {
                $rawInv = $trk['internalShipment']['invoice_items'];
                $parsed = is_string($rawInv) ? json_decode($rawInv, true) : (is_array($rawInv) ? $rawInv : []);
                if (is_array($parsed) && !empty($parsed)) {
                    $invoice_items = $parsed;
                }
            }

            if (!empty($trk['events']) && is_array($trk['events'])) {
                foreach ($trk['events'] as $ev) {
                    $tracking_events[] = [
                        'activity' => $ev['status'] ?? ($ev['activity'] ?? ($ev['event_description'] ?? 'Status Update')),
                        'date' => $ev['date'] ?? '',
                        'time' => $ev['time'] ?? '',
                        'location' => $ev['location'] ?? '',
                    ];
                }
            }
        }
    }

    // Fallback to database parcel_history if live API returned no events
    if (empty($tracking_events) && !empty($db_history)) {
        foreach ($db_history as $h) {
            $tracking_events[] = [
                'activity' => $h->activity,
                'date' => $h->date,
                'time' => $h->time,
                'location' => $h->location ?? '',
            ];
        }
    }

    // Initial fallback if still completely empty
    if (empty($tracking_events)) {
        $bDate = !empty($row->AWBDATE) ? date('d/m/Y', strtotime($row->AWBDATE)) : date('d/m/Y');
        $is_dispatched = !empty($row->VENDORID1) || !empty($row->VENDORID2) || !empty($row->VENDNAME) || intval($row->SERVICE ?? 0) > 0;
        if ($is_dispatched) {
            $tracking_events[] = [
                'activity' => 'Shipment Manifested & Dispatched from Origin Hub',
                'date' => $bDate,
                'time' => '11:15 AM',
                'location' => 'SURAT, INDIA (PRINCE EXPRESS HUB)'
            ];
            if (empty($live_status)) {
                $live_status = 'Shipment Manifested & Dispatched from Origin Hub';
            }
            if (empty($live_stage)) {
                $live_stage = 'in_transit';
            }
        } else {
            $tracking_events[] = [
                'activity' => 'Shipment Booked & Order Created',
                'date' => $bDate,
                'time' => '10:00 AM',
                'location' => 'SURAT, INDIA (PRINCE EXPRESS)'
            ];
            if (empty($live_status)) {
                $live_status = 'Shipment Booked & Order Created';
            }
            if (empty($live_stage)) {
                $live_stage = 'booked';
            }
        }
    }

    wp_send_json_success([
        'shipment' => [
            'awb' => $row->AWBNO,
            'date' => !empty($row->AWBDATE) ? date('d M Y', strtotime($row->AWBDATE)) : '',
            'raw_date' => $row->AWBDATE,
            'shipper' => $row->SNAME,
            'shipper_address' => $s_addr,
            'shipper_phone' => $row->SPHONE1 ?? ($breq->sender_phone ?? ''),
            'consignee' => $row->CNEENAME,
            'consignee_address' => $c_addr,
            'consignee_phone' => $row->CNEEPHONE1 ?? ($breq->receiver_phone ?? ''),
            'destination' => $row->DESTNAME,
            'origin' => $row->ORIGIN ?? '',
            'weight' => $actual_weight ?: ($row->ACTUALWEIGHT ?: $row->CHARGEWEIGHT),
            'chargeable_weight' => $chargeable_weight ?: $row->CHARGEWEIGHT,
            'length' => $length,
            'breadth' => $breadth,
            'height' => $height,
            'dimensions' => ($length && $breadth && $height) ? "{$length} × {$breadth} × {$height} cm" : '',
            'pieces' => $pieces,
            'amount' => $totAmount,
            'balance' => $totAmount - $recAmount,
            'forwarding_number' => $forwarding_no,
            'secondary_carrier' => $secondary_carrier,
            'content_description' => $content_desc,
            'product' => $row->PRODNAME ?? '',
            'status' => $live_status ?: (!empty($tracking_events) ? $tracking_events[0]['activity'] : 'Shipment Booked'),
            'stage' => $live_stage,
            'parcels' => $parcels,
            'invoice_items' => $invoice_items,
        ],
        'tracking' => $tracking_events,
    ]);
}
add_action('wp_ajax_pe_cp_shipment_detail', 'pe_cp_ajax_shipment_detail');
add_action('wp_ajax_nopriv_pe_cp_shipment_detail', 'pe_cp_ajax_shipment_detail');

// ══════════════════════════════════════
//  AJAX: CANCEL / DELETE BOOKING REQUEST
// ══════════════════════════════════════

function pe_cp_ajax_cancel_request()
{
    pe_cp_check_ajax();
    global $wpdb;

    $cust = pe_cp_get_user();
    $cust_id = intval($cust['customer_id'] ?? ($cust['id'] ?? 0));
    $cust_email = strtolower(trim($cust['email'] ?? ''));

    $request_awb = sanitize_text_field($_POST['request_awb'] ?? '');
    if (!$request_awb) {
        wp_send_json_error(['message' => 'Request AWB is required']);
    }

    $req = $wpdb->get_row($wpdb->prepare(
        "SELECT * FROM booking_requests WHERE request_awb = %s LIMIT 1",
        $request_awb
    ));

    if (!$req) {
        wp_send_json_error(['message' => 'Booking request not found']);
    }

    if ($req->status === 'confirmed') {
        wp_send_json_error(['message' => 'Confirmed shipments cannot be cancelled']);
    }

    // Verify ownership
    if ($cust_id > 0 && $req->customer_id && intval($req->customer_id) !== $cust_id) {
        if ($cust_email === '' || strtolower(trim($req->customer_email)) !== $cust_email) {
            wp_send_json_error(['message' => 'You do not have permission to cancel this request']);
        }
    }

    // Update status in booking_requests
    $wpdb->update(
        'booking_requests',
        ['status' => 'cancelled'],
        ['request_awb' => $request_awb]
    );

    // Delete or remove the pending booking entry from AWBENTRY
    $wpdb->query($wpdb->prepare(
        "DELETE FROM AWBENTRY WHERE AWBNO = %s AND (CUSTCODE = %s OR CUSTCODE = %s OR CUSTCODE = %s OR CUSTCODE = '')",
        $request_awb,
        strval($cust_id),
        'CUST-' . $cust_id,
        'CUST-' . str_pad($cust_id, 4, '0', STR_PAD_LEFT)
    ));

    // Record cancellation event in parcel_history
    $wpdb->insert('parcel_history', [
        'AWBNO' => $request_awb,
        'date' => current_time('Y-m-d'),
        'time' => current_time('H:i:s'),
        'activity' => 'SHIPMENT CANCELLED',
        'location' => 'CUSTOMER PORTAL'
    ]);

    // Record timeline update
    $wpdb->insert('request_updates', [
        'request_id' => $req->id,
        'update_type' => 'warning',
        'title' => 'Booking Cancelled',
        'description' => 'Booking request was cancelled by customer.'
    ]);

    wp_send_json_success(['message' => 'Booking request cancelled successfully']);
}
add_action('wp_ajax_pe_cp_cancel_request', 'pe_cp_ajax_cancel_request');
add_action('wp_ajax_nopriv_pe_cp_cancel_request', 'pe_cp_ajax_cancel_request');

// ══════════════════════════════════════
//  AJAX: CUSTOMER REQUESTS
// ══════════════════════════════════════

function pe_cp_ajax_my_requests()
{
    pe_cp_check_ajax();
    global $wpdb;

    $cust = pe_cp_get_user();
    $page = max(1, intval($_POST['page'] ?? 1));
    $per = 15;
    $offset = ($page - 1) * $per;
    $search = sanitize_text_field($_POST['search'] ?? '');
    $status = sanitize_text_field($_POST['status'] ?? '');

    $cust_email = strtolower(trim($cust['email'] ?? ''));
    $cust_phone = preg_replace('/[^0-9]/', '', $cust['phone'] ?? '');
    $cust_phone_last10 = strlen($cust_phone) >= 10 ? substr($cust_phone, -10) : $cust_phone;
    $cust_id = intval($cust['customer_id'] ?? 0);

    // Flexible matching by customer_id, email, phone, or name
    $where_conds = [];
    $params = [];

    if ($cust_id > 0) {
        $where_conds[] = "customer_id = %d";
        $params[] = $cust_id;
    }
    if ($cust_email) {
        $where_conds[] = "LOWER(TRIM(customer_email)) = %s OR LOWER(TRIM(sender_email)) = %s";
        $params[] = $cust_email;
        $params[] = $cust_email;
    }
    if ($cust_phone_last10) {
        $where_conds[] = "customer_phone LIKE %s OR sender_phone LIKE %s";
        $like_phone = '%' . $wpdb->esc_like($cust_phone_last10) . '%';
        $params[] = $like_phone;
        $params[] = $like_phone;
    }
    $cust_name = trim($cust['name'] ?? '');
    if (strlen($cust_name) >= 3) {
        $where_conds[] = "LOWER(TRIM(customer_name)) = %s OR LOWER(TRIM(sender_name)) = %s";
        $params[] = strtolower($cust_name);
        $params[] = strtolower($cust_name);
    }

    $where_base = count($where_conds) > 0 ? $wpdb->prepare("(" . implode(" OR ", $where_conds) . ")", ...$params) : "1=1";
    // Confirmed requests automatically become shipments and must not show in requests
    $where_base .= " AND status != 'confirmed'";
    // Filter out requests created before September 1, 2026
    $where_base .= " AND created_at >= '2026-09-01 00:00:00'";
    $where = $where_base;

    if ($status && $status !== 'all') {
        $where .= $wpdb->prepare(" AND status = %s", $status);
    }

    if ($search) {
        $like = '%' . $wpdb->esc_like($search) . '%';
        $where .= $wpdb->prepare(
            " AND (request_awb LIKE %s OR receiver_name LIKE %s OR sender_name LIKE %s OR sender_city LIKE %s OR receiver_city LIKE %s OR receiver_country LIKE %s OR customer_phone LIKE %s OR sender_phone LIKE %s OR receiver_phone LIKE %s OR order_reference LIKE %s)",
            $like,
            $like,
            $like,
            $like,
            $like,
            $like,
            $like,
            $like,
            $like,
            $like
        );
    }

    $total = intval($wpdb->get_var("SELECT COUNT(*) FROM booking_requests WHERE $where"));

    $rows = $wpdb->get_results(
        "SELECT * FROM booking_requests 
         WHERE $where 
         ORDER BY id DESC 
         LIMIT " . intval($per) . " OFFSET " . intval($offset)
    );

    $data = [];
    foreach ($rows as $r) {
        $data[] = [
            'id' => $r->id,
            'request_awb' => $r->request_awb,
            'created_at' => $r->created_at,
            'sender_name' => $r->sender_name,
            'sender_city' => $r->sender_city,
            'receiver_name' => $r->receiver_name,
            'receiver_city' => $r->receiver_city,
            'package_type' => $r->package_type,
            'weight' => $r->weight,
            'status' => $r->status,
            'admin_notes' => $r->admin_notes ?? '',
            'shipment_id' => $r->shipment_id,
            'tracking_number' => $r->tracking_number,
        ];
    }

    // Get accurate count breakdown for requests tab badges (excluding confirmed which are in shipments)
    $count_all = intval($wpdb->get_var("SELECT COUNT(*) FROM booking_requests WHERE $where_base"));
    $count_pending = intval($wpdb->get_var("SELECT COUNT(*) FROM booking_requests WHERE $where_base AND status = 'pending'"));
    $count_processing = intval($wpdb->get_var("SELECT COUNT(*) FROM booking_requests WHERE $where_base AND status = 'processing'"));
    $count_rejected = intval($wpdb->get_var("SELECT COUNT(*) FROM booking_requests WHERE $where_base AND status = 'rejected'"));

    wp_send_json_success([
        'rows' => $data,
        'total' => $total,
        'pages' => max(1, ceil($total / $per)),
        'page' => $page,
        'counts' => [
            'all' => $count_all,
            'pending' => $count_pending,
            'processing' => $count_processing,
            'confirmed' => 0,
            'rejected' => $count_rejected,
        ],
    ]);
}
add_action('wp_ajax_pe_cp_my_requests', 'pe_cp_ajax_my_requests');
add_action('wp_ajax_nopriv_pe_cp_my_requests', 'pe_cp_ajax_my_requests');

function pe_cp_ajax_request_detail()
{
    pe_cp_check_ajax();
    global $wpdb;

    $request_awb = sanitize_text_field($_POST['request_awb'] ?? '');
    if (!$request_awb) {
        wp_send_json_error(['message' => 'Request AWB number required']);
    }

    // Fetch request by request_awb
    $request = $wpdb->get_row($wpdb->prepare("SELECT * FROM booking_requests WHERE request_awb = %s", $request_awb));

    if (!$request) {
        wp_send_json_error(['message' => 'Booking request not found']);
    }

    // Fetch request_updates
    $updates = $wpdb->get_results($wpdb->prepare(
        "SELECT * FROM request_updates WHERE request_id = %d ORDER BY created_at DESC",
        $request->id
    ));

    $timeline = [];
    foreach ($updates as $up) {
        $timeline[] = [
            'type' => $up->update_type,
            'title' => $up->title,
            'description' => $up->description,
            'date' => date('d M Y, h:i A', strtotime($up->created_at)),
            'timestamp' => strtotime($up->created_at)
        ];
    }

    // Fetch physical parcel tracking history if tracking number is linked
    if (!empty($request->tracking_number)) {
        $awb_no = intval($request->tracking_number);
        $history = $wpdb->get_results($wpdb->prepare(
            "SELECT activity, date, time, location FROM parcel_history WHERE AWBNO = %d ORDER BY date DESC, time DESC",
            $awb_no
        ));
        foreach ($history as $h) {
            $dt_str = $h->date . ' ' . $h->time;
            $timeline[] = [
                'type' => 'tracking_update',
                'title' => $h->activity,
                'description' => 'Location: ' . ($h->location ?: 'Origin/In Transit'),
                'date' => date('d M Y, h:i A', strtotime($dt_str)),
                'timestamp' => strtotime($dt_str)
            ];
        }
    }

    // Sort timeline by timestamp DESC
    usort($timeline, function ($a, $b) {
        return $b['timestamp'] - $a['timestamp'];
    });

    // Parse JSON fields so frontend can render parcels, items & documents
    $json_fields = ['parcels', 'invoice_items', 'documents'];
    foreach ($json_fields as $jf) {
        if (!empty($request->$jf) && is_string($request->$jf)) {
            $decoded = json_decode($request->$jf, true);
            $request->$jf = is_array($decoded) ? $decoded : null;
        }
    }

    wp_send_json_success([
        'request' => $request,
        'timeline' => $timeline
    ]);
}
add_action('wp_ajax_pe_cp_request_detail', 'pe_cp_ajax_request_detail');
add_action('wp_ajax_nopriv_pe_cp_request_detail', 'pe_cp_ajax_request_detail');

// ══════════════════════════════════════
//  AJAX: UPDATE PROFILE
// ══════════════════════════════════════

function pe_cp_ajax_update_profile()
{
    pe_cp_check_ajax();
    global $wpdb;

    $cust = pe_cp_get_user();
    $name = sanitize_text_field($_POST['name'] ?? '');
    $email = sanitize_email($_POST['email'] ?? '');
    $phone = sanitize_text_field($_POST['phone'] ?? '');
    $company = sanitize_text_field($_POST['company'] ?? '');

    if (!$name || !$email) {
        wp_send_json_error(['message' => 'Name and Email are required']);
    }

    $existing = $wpdb->get_var($wpdb->prepare(
        "SELECT id FROM tbl_customers WHERE email = %s AND id != %d",
        $email,
        $cust['customer_id']
    ));
    if ($existing) {
        wp_send_json_error(['message' => 'Email address is already registered by another account']);
    }

    $wpdb->update('tbl_customers', [
        'name' => $name,
        'email' => $email,
        'phone' => $phone,
        'company' => $company
    ], ['id' => $cust['customer_id']]);

    $cust['name'] = $name;
    $cust['email'] = $email;
    $cust['phone'] = $phone;
    $cust['company'] = $company;
    pe_cp_session_set($cust);

    wp_send_json_success([
        'message' => 'Profile updated successfully!',
        'user' => $cust
    ]);
}
add_action('wp_ajax_pe_cp_update_profile', 'pe_cp_ajax_update_profile');
add_action('wp_ajax_nopriv_pe_cp_update_profile', 'pe_cp_ajax_update_profile');

// ══════════════════════════════════════
//  AJAX: UPDATE PASSWORD
// ══════════════════════════════════════

function pe_cp_ajax_update_password()
{
    pe_cp_check_ajax();
    global $wpdb;

    $cust = pe_cp_get_user();
    $current_pwd = $_POST['current_pwd'] ?? '';
    $new_pwd = $_POST['new_pwd'] ?? '';

    if (!$current_pwd || !$new_pwd) {
        wp_send_json_error(['message' => 'Both current and new passwords are required']);
    }

    $row = $wpdb->get_row($wpdb->prepare(
        "SELECT password FROM tbl_customers WHERE id = %d",
        $cust['customer_id']
    ));

    if (!$row) {
        wp_send_json_error(['message' => 'Account not found']);
    }

    if (!password_verify($current_pwd, $row->password) && md5($current_pwd) !== $row->password) {
        wp_send_json_error(['message' => 'Incorrect current password']);
    }

    $hashed = password_hash($new_pwd, PASSWORD_BCRYPT, ['cost' => 12]);

    $wpdb->update('tbl_customers', [
        'password' => $hashed
    ], ['id' => $cust['customer_id']]);

    wp_send_json_success([
        'message' => 'Password updated successfully!'
    ]);
}
add_action('wp_ajax_pe_cp_update_password', 'pe_cp_ajax_update_password');
add_action('wp_ajax_nopriv_pe_cp_update_password', 'pe_cp_ajax_update_password');

// ══════════════════════════════════════
//  AJAX: GET ADDRESSES
// ══════════════════════════════════════

function pe_cp_ajax_get_addresses()
{
    pe_cp_check_ajax();
    global $wpdb;
    $cust = pe_cp_get_user();
    $custId = intval($cust['customer_id'] ?? 0);
    $email = sanitize_email($cust['email'] ?? '');
    $phone = sanitize_text_field($cust['phone'] ?? '');

    $table_exists = $wpdb->get_var("SHOW TABLES LIKE 'customer_addresses'");
    if (!$table_exists) {
        if (function_exists('pe_cp_create_tables')) {
            pe_cp_create_tables();
        }
    } else {
        // Ensure address_type column exists if table was created previously
        $has_col = $wpdb->get_results("SHOW COLUMNS FROM customer_addresses LIKE 'address_type'");
        if (empty($has_col)) {
            $wpdb->query("ALTER TABLE customer_addresses ADD COLUMN address_type VARCHAR(20) DEFAULT 'both' AFTER customer_phone");
        }
    }

    $clean_p = preg_replace('/[^0-9]/', '', $phone);
    $last10 = (strlen($clean_p) >= 10) ? substr($clean_p, -10) : $clean_p;

    $conds = [];
    $params = [];
    if ($custId > 0) {
        $conds[] = "customer_id = %d";
        $params[] = $custId;
    }
    if ($email) {
        $conds[] = "LOWER(customer_email) = LOWER(%s)";
        $params[] = $email;
    }
    if ($phone) {
        $conds[] = "customer_phone = %s";
        $params[] = $phone;
        if (!empty($last10) && $last10 !== $phone) {
            $conds[] = "customer_phone LIKE %s";
            $params[] = '%' . $wpdb->esc_like($last10) . '%';
        }
    }

    $where = !empty($conds) ? "(" . implode(" OR ", $conds) . ")" : "1=1";
    if (!empty($params)) {
        $where = $wpdb->prepare($where, ...$params);
    }

    $rows = $wpdb->get_results("SELECT * FROM customer_addresses WHERE $where ORDER BY is_default DESC, updated_at DESC", ARRAY_A);

    // Fallback & automatic sync: If empty or few addresses, query Node.js backend addresses
    if (empty($rows) && ($custId > 0 || $email || $phone)) {
        $apiUrl = 'https://purple-raccoon-753399.hostingersite.com/api/customer/addresses?' . http_build_query([
            'customer_id' => $custId,
            'email' => $email,
            'phone' => $phone
        ]);
        $response = wp_remote_get($apiUrl, ['timeout' => 8, 'sslverify' => false]);
        if (!is_wp_error($response)) {
            $body = json_decode(wp_remote_retrieve_body($response), true);
            if (!empty($body['success']) && !empty($body['addresses'])) {
                foreach ($body['addresses'] as $addr) {
                    $existing = $wpdb->get_var($wpdb->prepare(
                        "SELECT id FROM customer_addresses WHERE LOWER(TRIM(name)) = LOWER(TRIM(%s)) AND TRIM(phone) = TRIM(%s) AND LOWER(TRIM(address)) = LOWER(TRIM(%s)) LIMIT 1",
                        $addr['name'] ?? '',
                        $addr['phone'] ?? '',
                        $addr['address'] ?? ''
                    ));
                    if (!$existing) {
                        $wpdb->insert('customer_addresses', [
                            'customer_id' => $custId ?: ($addr['customer_id'] ?? null),
                            'customer_email' => $email ?: ($addr['customer_email'] ?? ''),
                            'customer_phone' => $phone ?: ($addr['customer_phone'] ?? ''),
                            'address_type' => $addr['address_type'] ?? 'both',
                            'name' => $addr['name'] ?? '',
                            'company' => $addr['company'] ?? '',
                            'phone' => $addr['phone'] ?? '',
                            'phone_2' => $addr['phone_2'] ?? '',
                            'email' => $addr['email'] ?? '',
                            'address' => $addr['address'] ?? '',
                            'address_2' => $addr['address_2'] ?? '',
                            'city' => $addr['city'] ?? '',
                            'state' => $addr['state'] ?? '',
                            'pincode' => $addr['pincode'] ?? '',
                            'country' => $addr['country'] ?? 'INDIA',
                            'gstin_type' => $addr['gstin_type'] ?? '',
                            'gstin_no' => $addr['gstin_no'] ?? '',
                            'is_default' => intval($addr['is_default'] ?? 0),
                        ]);
                    }
                }
                $rows = $wpdb->get_results("SELECT * FROM customer_addresses WHERE $where ORDER BY is_default DESC, updated_at DESC", ARRAY_A);
            }
        }
    }

    wp_send_json_success(['addresses' => $rows ?: []]);
}
add_action('wp_ajax_pe_cp_get_addresses', 'pe_cp_ajax_get_addresses');
add_action('wp_ajax_nopriv_pe_cp_get_addresses', 'pe_cp_ajax_get_addresses');

// ══════════════════════════════════════
//  AJAX: SAVE ADDRESS
// ══════════════════════════════════════

function pe_cp_ajax_save_address()
{
    pe_cp_check_ajax();
    global $wpdb;
    $cust = pe_cp_get_user();
    $custId = intval($cust['customer_id'] ?? 0);

    $id = intval($_POST['id'] ?? 0);
    $name = sanitize_text_field($_POST['name'] ?? '');
    $company = sanitize_text_field($_POST['company'] ?? '');
    $phone = sanitize_text_field($_POST['phone'] ?? '');
    $phone_2 = sanitize_text_field($_POST['phone_2'] ?? '');
    $email = sanitize_email($_POST['email'] ?? '');
    $address = sanitize_textarea_field($_POST['address'] ?? '');
    $address_2 = sanitize_text_field($_POST['address_2'] ?? '');
    $city = sanitize_text_field($_POST['city'] ?? '');
    $state = sanitize_text_field($_POST['state'] ?? '');
    $pincode = sanitize_text_field($_POST['pincode'] ?? '');
    $country = sanitize_text_field($_POST['country'] ?? 'INDIA');
    $gstin_type = sanitize_text_field($_POST['gstin_type'] ?? '');
    $gstin_no = sanitize_text_field($_POST['gstin_no'] ?? '');
    $address_type = sanitize_text_field($_POST['address_type'] ?? 'both');
    $is_default = !empty($_POST['is_default']) ? 1 : 0;

    if (!$name || !$phone || !$address || !$city) {
        wp_send_json_error(['message' => 'Name, Phone, Address Line 1, and City are required']);
    }

    if (!$wpdb->get_var("SHOW TABLES LIKE 'customer_addresses'")) {
        if (function_exists('pe_cp_create_tables'))
            pe_cp_create_tables();
    } else {
        $has_col = $wpdb->get_results("SHOW COLUMNS FROM customer_addresses LIKE 'address_type'");
        if (empty($has_col)) {
            $wpdb->query("ALTER TABLE customer_addresses ADD COLUMN address_type VARCHAR(20) DEFAULT 'both' AFTER customer_phone");
        }
    }

    if ($is_default && $custId > 0) {
        $wpdb->query($wpdb->prepare("UPDATE customer_addresses SET is_default = 0 WHERE customer_id = %d", $custId));
    }

    $data = [
        'customer_id' => $custId ?: null,
        'customer_email' => sanitize_email($cust['email'] ?? ''),
        'customer_phone' => sanitize_text_field($cust['phone'] ?? ''),
        'address_type' => $address_type,
        'name' => $name,
        'company' => $company,
        'phone' => $phone,
        'phone_2' => $phone_2,
        'email' => $email,
        'address' => $address,
        'address_2' => $address_2,
        'city' => $city,
        'state' => $state,
        'pincode' => $pincode,
        'country' => $country ?: 'INDIA',
        'gstin_type' => $gstin_type,
        'gstin_no' => $gstin_no,
        'is_default' => $is_default
    ];

    if ($id > 0) {
        $wpdb->update('customer_addresses', $data, ['id' => $id]);
        $savedId = $id;
    } else {
        $wpdb->insert('customer_addresses', $data);
        $savedId = $wpdb->insert_id;
    }

    $row = $wpdb->get_row($wpdb->prepare("SELECT * FROM customer_addresses WHERE id = %d", $savedId), ARRAY_A);

    // Sync to Hostinger Node.js backend (non-blocking) so booking form can see it
    $sync_payload = array_merge($data, ['wp_address_id' => $savedId]);
    wp_remote_post('https://purple-raccoon-753399.hostingersite.com/api/customer/addresses', [
        'timeout' => 5,
        'blocking' => false,
        'sslverify' => false,
        'headers' => ['Content-Type' => 'application/json'],
        'body' => json_encode($sync_payload),
    ]);

    wp_send_json_success(['message' => 'Address saved successfully!', 'address' => $row]);
}
add_action('wp_ajax_pe_cp_save_address', 'pe_cp_ajax_save_address');
add_action('wp_ajax_nopriv_pe_cp_save_address', 'pe_cp_ajax_save_address');

// ══════════════════════════════════════
//  AJAX: DELETE ADDRESS
// ══════════════════════════════════════

function pe_cp_ajax_delete_address()
{
    pe_cp_check_ajax();
    global $wpdb;
    $id = intval($_POST['id'] ?? 0);
    if ($id > 0) {
        // Sync delete to Hostinger Node.js backend (non-blocking)
        $row = $wpdb->get_row($wpdb->prepare("SELECT * FROM customer_addresses WHERE id = %d", $id), ARRAY_A);
        if ($row) {
            wp_remote_request('https://purple-raccoon-753399.hostingersite.com/api/customer/addresses/' . $id, [
                'method' => 'DELETE',
                'timeout' => 5,
                'blocking' => false,
                'sslverify' => false,
                'headers' => ['Content-Type' => 'application/json'],
                'body' => json_encode(['name' => $row['name'], 'phone' => $row['phone'], 'address' => $row['address'], 'customer_id' => $row['customer_id']]),
            ]);
        }
        $wpdb->delete('customer_addresses', ['id' => $id]);
    }
    wp_send_json_success(['message' => 'Address deleted']);
}
add_action('wp_ajax_pe_cp_delete_address', 'pe_cp_ajax_delete_address');
add_action('wp_ajax_nopriv_pe_cp_delete_address', 'pe_cp_ajax_delete_address');

// ══════════════════════════════════════
//  AJAX: GET DOCUMENTS
// ══════════════════════════════════════

function pe_cp_ajax_get_documents()
{
    pe_cp_check_ajax();
    global $wpdb;
    $cust = pe_cp_get_user();
    $custId = intval($cust['customer_id'] ?? 0);
    $email = sanitize_email($cust['email'] ?? '');
    $phone = sanitize_text_field($cust['phone'] ?? '');

    $table_exists = $wpdb->get_var("SHOW TABLES LIKE 'customer_documents'");
    if (!$table_exists) {
        wp_send_json_success(['documents' => []]);
    }

    $where = "1=1";
    if ($custId > 0) {
        $where .= $wpdb->prepare(" AND (customer_id = %d OR LOWER(customer_email) = LOWER(%s) OR customer_phone = %s)", $custId, $email, $phone);
    } elseif ($email) {
        $where .= $wpdb->prepare(" AND (LOWER(customer_email) = LOWER(%s) OR customer_phone = %s)", $email, $phone);
    }

    $rows = $wpdb->get_results("SELECT * FROM customer_documents WHERE $where ORDER BY created_at DESC", ARRAY_A);
    wp_send_json_success(['documents' => $rows ?: []]);
}
add_action('wp_ajax_pe_cp_get_documents', 'pe_cp_ajax_get_documents');
add_action('wp_ajax_nopriv_pe_cp_get_documents', 'pe_cp_ajax_get_documents');

// ══════════════════════════════════════
//  AJAX: UPLOAD DOCUMENT
// ══════════════════════════════════════

function pe_cp_ajax_upload_document()
{
    pe_cp_check_ajax();
    global $wpdb;
    $cust = pe_cp_get_user();
    $custId = intval($cust['customer_id'] ?? 0);

    if (empty($_FILES['file'])) {
        wp_send_json_error(['message' => 'No file was uploaded']);
    }

    require_once ABSPATH . 'wp-admin/includes/file.php';
    $file = $_FILES['file'];
    $upload_overrides = ['test_form' => false];
    $movefile = wp_handle_upload($file, $upload_overrides);

    if ($movefile && !isset($movefile['error'])) {
        $doc_type = sanitize_text_field($_POST['doc_type'] ?? 'Other');
        $doc_name = sanitize_text_field($_POST['doc_name'] ?? $file['name']);
        $doc_number = sanitize_text_field($_POST['doc_number'] ?? '');
        $notes = sanitize_textarea_field($_POST['notes'] ?? '');

        $wpdb->insert('customer_documents', [
            'customer_id' => $custId ?: null,
            'customer_email' => sanitize_email($cust['email'] ?? ''),
            'customer_phone' => sanitize_text_field($cust['phone'] ?? ''),
            'doc_type' => $doc_type,
            'doc_name' => $doc_name,
            'doc_number' => $doc_number,
            'file_url' => $movefile['url'],
            'file_name' => $file['name'],
            'file_size' => intval($file['size']),
            'file_type' => $file['type'],
            'notes' => $notes
        ]);

        $docId = $wpdb->insert_id;
        $row = $wpdb->get_row($wpdb->prepare("SELECT * FROM customer_documents WHERE id = %d", $docId), ARRAY_A);
        wp_send_json_success(['message' => 'Document uploaded successfully!', 'document' => $row]);
    } else {
        wp_send_json_error(['message' => $movefile['error'] ?? 'Upload failed']);
    }
}
add_action('wp_ajax_pe_cp_upload_document', 'pe_cp_ajax_upload_document');
add_action('wp_ajax_nopriv_pe_cp_upload_document', 'pe_cp_ajax_upload_document');

// ══════════════════════════════════════
//  AJAX: DELETE DOCUMENT
// ══════════════════════════════════════

function pe_cp_ajax_delete_document()
{
    pe_cp_check_ajax();
    global $wpdb;
    $id = intval($_POST['id'] ?? 0);
    if ($id > 0) {
        $wpdb->delete('customer_documents', ['id' => $id]);
    }
    wp_send_json_success(['message' => 'Document deleted']);
}
add_action('wp_ajax_pe_cp_delete_document', 'pe_cp_ajax_delete_document');
add_action('wp_ajax_nopriv_pe_cp_delete_document', 'pe_cp_ajax_delete_document');

// ══════════════════════════════════════
//  SHORTCODE: [pe_customer_portal]
// ══════════════════════════════════════

function pe_cp_shortcode()
{
    // Prevent caching
    if (!headers_sent()) {
        header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
        header('Pragma: no-cache');
        header('X-LiteSpeed-Cache-Control: no-cache');
    }

    ob_start();
    if (pe_cp_is_logged_in()) {
        include PE_CP_DIR . 'pe-customer-views/dashboard.php';
    } else {
        include PE_CP_DIR . 'pe-customer-views/login.php';
    }
    return ob_get_clean();
}
add_shortcode('pe_customer_portal', 'pe_cp_shortcode');

// ══════════════════════════════════════
//  TABLE CREATION ON ACTIVATION
// ══════════════════════════════════════

register_activation_hook(__FILE__, function () {
    global $wpdb;
    $charset = $wpdb->get_charset_collate();

    // Customer accounts table
    $sql_customers = "CREATE TABLE IF NOT EXISTS tbl_customers (
        id INT AUTO_INCREMENT PRIMARY KEY,
        name VARCHAR(100) NOT NULL,
        email VARCHAR(150) NOT NULL,
        phone VARCHAR(20) DEFAULT '',
        company VARCHAR(150) DEFAULT '',
        password VARCHAR(255) NOT NULL,
        status ENUM('active','inactive') DEFAULT 'active',
        last_login DATETIME DEFAULT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        UNIQUE KEY idx_email (email)
    ) $charset;";

    // Booking requests table (synced from Node.js backend)
    $sql_booking_requests = "CREATE TABLE IF NOT EXISTS booking_requests (
        id INT AUTO_INCREMENT PRIMARY KEY,
        request_awb VARCHAR(20) NOT NULL,
        customer_id INT DEFAULT NULL,
        customer_name VARCHAR(100) DEFAULT '',
        customer_email VARCHAR(150) DEFAULT '',
        customer_phone VARCHAR(20) DEFAULT '',
        customer_company VARCHAR(150) DEFAULT '',
        sender_name VARCHAR(100) DEFAULT '',
        sender_company VARCHAR(150) DEFAULT '',
        sender_email VARCHAR(150) DEFAULT '',
        sender_phone VARCHAR(20) DEFAULT '',
        sender_address VARCHAR(255) DEFAULT '',
        sender_address_2 VARCHAR(255) DEFAULT '',
        sender_city VARCHAR(100) DEFAULT '',
        sender_pincode VARCHAR(20) DEFAULT '',
        sender_state VARCHAR(100) DEFAULT '',
        sender_country VARCHAR(100) DEFAULT 'INDIA',
        sender_gstin_type VARCHAR(50) DEFAULT '',
        sender_gstin_no VARCHAR(50) DEFAULT '',
        receiver_name VARCHAR(100) DEFAULT '',
        receiver_email VARCHAR(150) DEFAULT '',
        receiver_phone VARCHAR(20) DEFAULT '',
        receiver_address VARCHAR(255) DEFAULT '',
        receiver_address_2 VARCHAR(255) DEFAULT '',
        receiver_city VARCHAR(100) DEFAULT '',
        receiver_pincode VARCHAR(20) DEFAULT '',
        receiver_state VARCHAR(100) DEFAULT '',
        receiver_country VARCHAR(100) DEFAULT '',
        receiver_gstin_type VARCHAR(50) DEFAULT '',
        receiver_gstin_no VARCHAR(50) DEFAULT '',
        package_type VARCHAR(50) DEFAULT 'parcel',
        weight DECIMAL(10,2) DEFAULT 0,
        length_cm DECIMAL(10,2) DEFAULT 0,
        breadth DECIMAL(10,2) DEFAULT 0,
        height DECIMAL(10,2) DEFAULT 0,
        no_of_pieces INT DEFAULT 1,
        content_description TEXT,
        declared_value DECIMAL(10,2) DEFAULT 0,
        is_fragile TINYINT DEFAULT 0,
        remarks TEXT,
        parcels LONGTEXT DEFAULT NULL,
        invoice_items LONGTEXT DEFAULT NULL,
        documents LONGTEXT DEFAULT NULL,
        order_reference VARCHAR(100) DEFAULT '',
        payment_mode VARCHAR(30) DEFAULT 'prepaid',
        shipping_charge DECIMAL(10,2) DEFAULT 0,
        invoice_type VARCHAR(30) DEFAULT 'INVOICE',
        invoice_currency VARCHAR(10) DEFAULT 'INR',
        hs_code VARCHAR(50) DEFAULT '',
        export_reason VARCHAR(255) DEFAULT '',
        terms_of_trade VARCHAR(20) DEFAULT 'CIF',
        invoice_note TEXT DEFAULT NULL,
        status VARCHAR(20) DEFAULT 'pending',
        admin_notes TEXT,
        shipment_id INT DEFAULT NULL,
        tracking_number VARCHAR(50) DEFAULT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        UNIQUE KEY idx_request_awb (request_awb),
        KEY idx_customer_id (customer_id),
        KEY idx_customer_email (customer_email),
        KEY idx_status (status)
    ) $charset;";

    // Request updates / timeline table (synced from Node.js backend)
    $sql_request_updates = "CREATE TABLE IF NOT EXISTS request_updates (
        id INT AUTO_INCREMENT PRIMARY KEY,
        request_id INT NOT NULL,
        update_type VARCHAR(30) DEFAULT 'info',
        title VARCHAR(255) NOT NULL,
        description TEXT,
        metadata LONGTEXT DEFAULT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        KEY idx_request_id (request_id)
    ) $charset;";

    // Customer addresses table
    $sql_customer_addresses = "CREATE TABLE IF NOT EXISTS customer_addresses (
        id INT AUTO_INCREMENT PRIMARY KEY,
        customer_id INT DEFAULT NULL,
        customer_email VARCHAR(150) DEFAULT '',
        customer_phone VARCHAR(50) DEFAULT '',
        address_type VARCHAR(20) DEFAULT 'both',
        name VARCHAR(100) NOT NULL,
        company VARCHAR(150) DEFAULT '',
        phone VARCHAR(50) NOT NULL,
        phone_2 VARCHAR(50) DEFAULT '',
        email VARCHAR(150) DEFAULT '',
        address TEXT NOT NULL,
        address_2 VARCHAR(255) DEFAULT '',
        city VARCHAR(100) NOT NULL,
        state VARCHAR(100) DEFAULT '',
        pincode VARCHAR(20) DEFAULT '',
        country VARCHAR(100) DEFAULT 'INDIA',
        gstin_type VARCHAR(50) DEFAULT '',
        gstin_no VARCHAR(50) DEFAULT '',
        is_default TINYINT(1) DEFAULT 0,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        KEY idx_cust_id (customer_id),
        KEY idx_cust_email (customer_email)
    ) $charset;";

    // Customer documents table
    $sql_customer_documents = "CREATE TABLE IF NOT EXISTS customer_documents (
        id INT AUTO_INCREMENT PRIMARY KEY,
        customer_id INT DEFAULT NULL,
        customer_email VARCHAR(150) DEFAULT '',
        customer_phone VARCHAR(50) DEFAULT '',
        doc_type VARCHAR(100) NOT NULL,
        doc_name VARCHAR(255) DEFAULT '',
        doc_number VARCHAR(100) DEFAULT '',
        file_url VARCHAR(500) NOT NULL,
        file_name VARCHAR(255) DEFAULT '',
        file_size INT DEFAULT 0,
        file_type VARCHAR(50) DEFAULT '',
        notes TEXT DEFAULT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        KEY idx_cust_id (customer_id),
        KEY idx_cust_email (customer_email)
    ) $charset;";

    require_once ABSPATH . 'wp-admin/includes/upgrade.php';
    dbDelta($sql_customers);
    dbDelta($sql_booking_requests);
    dbDelta($sql_request_updates);
    dbDelta($sql_customer_addresses);
    dbDelta($sql_customer_documents);
});

// ══════════════════════════════════════
//  SELF-HEALING TABLE CREATION ON INIT
// ══════════════════════════════════════

add_action('init', function () {
    global $wpdb;
    // Only run once per day (use transient to avoid repeated checks)
    if (get_transient('pe_cp_tables_checked'))
        return;

    $charset = $wpdb->get_charset_collate();

    // Check if tbl_customers table exists
    if (!$wpdb->get_var("SHOW TABLES LIKE 'tbl_customers'")) {
        $wpdb->query("CREATE TABLE IF NOT EXISTS tbl_customers (
            id INT AUTO_INCREMENT PRIMARY KEY,
            name VARCHAR(100) NOT NULL,
            email VARCHAR(150) NOT NULL,
            phone VARCHAR(50) DEFAULT '',
            company VARCHAR(150) DEFAULT '',
            password VARCHAR(255) NOT NULL,
            address TEXT DEFAULT NULL,
            city VARCHAR(100) DEFAULT '',
            state VARCHAR(100) DEFAULT '',
            pincode VARCHAR(20) DEFAULT '',
            country VARCHAR(100) DEFAULT 'INDIA',
            gstin_no VARCHAR(50) DEFAULT '',
            credit_limit DECIMAL(12,2) DEFAULT 0.00,
            current_balance DECIMAL(12,2) DEFAULT 0.00,
            status ENUM('active','inactive') DEFAULT 'active',
            last_login DATETIME DEFAULT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            UNIQUE KEY idx_email (email),
            KEY idx_phone (phone),
            KEY idx_status (status)
        ) $charset");
    } else {
        // Table exists, check for and add any missing columns dynamically (self-healing)
        $cols = $wpdb->get_col("DESCRIBE tbl_customers");
        if ($cols) {
            $needed = [
                'phone' => "VARCHAR(50) DEFAULT ''",
                'company' => "VARCHAR(150) DEFAULT ''",
                'address' => "TEXT DEFAULT NULL",
                'city' => "VARCHAR(100) DEFAULT ''",
                'state' => "VARCHAR(100) DEFAULT ''",
                'pincode' => "VARCHAR(20) DEFAULT ''",
                'country' => "VARCHAR(100) DEFAULT 'INDIA'",
                'gstin_no' => "VARCHAR(50) DEFAULT ''",
                'credit_limit' => "DECIMAL(12,2) DEFAULT 0.00",
                'current_balance' => "DECIMAL(12,2) DEFAULT 0.00",
                'status' => "ENUM('active','inactive') DEFAULT 'active'",
                'last_login' => "DATETIME DEFAULT NULL"
            ];
            foreach ($needed as $col_name => $col_def) {
                if (!in_array($col_name, $cols)) {
                    $wpdb->query("ALTER TABLE tbl_customers ADD COLUMN $col_name $col_def");
                }
            }
        }
    }

    // Check if customer_addresses table exists
    if (!$wpdb->get_var("SHOW TABLES LIKE 'customer_addresses'")) {
        $wpdb->query("CREATE TABLE IF NOT EXISTS customer_addresses (
            id INT AUTO_INCREMENT PRIMARY KEY,
            customer_id INT DEFAULT NULL,
            customer_email VARCHAR(150) DEFAULT '',
            customer_phone VARCHAR(50) DEFAULT '',
            address_type VARCHAR(20) DEFAULT 'both',
            name VARCHAR(100) NOT NULL,
            company VARCHAR(150) DEFAULT '',
            phone VARCHAR(50) NOT NULL,
            phone_2 VARCHAR(50) DEFAULT '',
            email VARCHAR(150) DEFAULT '',
            address TEXT NOT NULL,
            address_2 VARCHAR(255) DEFAULT '',
            city VARCHAR(100) NOT NULL,
            state VARCHAR(100) DEFAULT '',
            pincode VARCHAR(20) DEFAULT '',
            country VARCHAR(100) DEFAULT 'INDIA',
            gstin_type VARCHAR(50) DEFAULT '',
            gstin_no VARCHAR(50) DEFAULT '',
            is_default TINYINT(1) DEFAULT 0,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            KEY idx_cust_id (customer_id),
            KEY idx_cust_email (customer_email)
        ) $charset");
    }

    // Check if customer_documents table exists
    if (!$wpdb->get_var("SHOW TABLES LIKE 'customer_documents'")) {
        $wpdb->query("CREATE TABLE IF NOT EXISTS customer_documents (
            id INT AUTO_INCREMENT PRIMARY KEY,
            customer_id INT DEFAULT NULL,
            customer_email VARCHAR(150) DEFAULT '',
            customer_phone VARCHAR(50) DEFAULT '',
            doc_type VARCHAR(100) NOT NULL,
            doc_name VARCHAR(255) DEFAULT '',
            doc_number VARCHAR(100) DEFAULT '',
            file_url VARCHAR(500) NOT NULL,
            file_name VARCHAR(255) DEFAULT '',
            file_size INT DEFAULT 0,
            file_type VARCHAR(50) DEFAULT '',
            notes TEXT DEFAULT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            KEY idx_cust_id (customer_id),
            KEY idx_cust_email (customer_email)
        ) $charset");
    }

    // Check if booking_requests table exists
    if (!$wpdb->get_var("SHOW TABLES LIKE 'booking_requests'")) {
        $wpdb->query("CREATE TABLE IF NOT EXISTS booking_requests (
            id INT AUTO_INCREMENT PRIMARY KEY,
            request_awb VARCHAR(20) NOT NULL,
            customer_id INT DEFAULT NULL,
            customer_name VARCHAR(100) DEFAULT '',
            customer_email VARCHAR(150) DEFAULT '',
            customer_phone VARCHAR(20) DEFAULT '',
            customer_company VARCHAR(150) DEFAULT '',
            sender_name VARCHAR(100) DEFAULT '',
            sender_company VARCHAR(150) DEFAULT '',
            sender_email VARCHAR(150) DEFAULT '',
            sender_phone VARCHAR(20) DEFAULT '',
            sender_address VARCHAR(255) DEFAULT '',
            sender_address_2 VARCHAR(255) DEFAULT '',
            sender_city VARCHAR(100) DEFAULT '',
            sender_pincode VARCHAR(20) DEFAULT '',
            sender_state VARCHAR(100) DEFAULT '',
            sender_country VARCHAR(100) DEFAULT 'INDIA',
            sender_gstin_type VARCHAR(50) DEFAULT '',
            sender_gstin_no VARCHAR(50) DEFAULT '',
            receiver_name VARCHAR(100) DEFAULT '',
            receiver_email VARCHAR(150) DEFAULT '',
            receiver_phone VARCHAR(20) DEFAULT '',
            receiver_address VARCHAR(255) DEFAULT '',
            receiver_address_2 VARCHAR(255) DEFAULT '',
            receiver_city VARCHAR(100) DEFAULT '',
            receiver_pincode VARCHAR(20) DEFAULT '',
            receiver_state VARCHAR(100) DEFAULT '',
            receiver_country VARCHAR(100) DEFAULT '',
            receiver_gstin_type VARCHAR(50) DEFAULT '',
            receiver_gstin_no VARCHAR(50) DEFAULT '',
            package_type VARCHAR(50) DEFAULT 'parcel',
            weight DECIMAL(10,2) DEFAULT 0,
            length_cm DECIMAL(10,2) DEFAULT 0,
            breadth DECIMAL(10,2) DEFAULT 0,
            height DECIMAL(10,2) DEFAULT 0,
            no_of_pieces INT DEFAULT 1,
            content_description TEXT,
            declared_value DECIMAL(10,2) DEFAULT 0,
            is_fragile TINYINT DEFAULT 0,
            remarks TEXT,
            status VARCHAR(20) DEFAULT 'pending',
            admin_notes TEXT,
            shipment_id INT DEFAULT NULL,
            tracking_number VARCHAR(50) DEFAULT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            UNIQUE KEY idx_request_awb (request_awb),
            KEY idx_customer_id (customer_id),
            KEY idx_customer_email (customer_email),
            KEY idx_status (status)
        ) $charset");
    } else {
        // Table exists, check for and add any missing columns dynamically (self-healing)
        $columns = $wpdb->get_col("DESCRIBE booking_requests");
        if ($columns) {
            $missing_columns = [
                'sender_gstin_type' => "VARCHAR(50) DEFAULT '' AFTER sender_country",
                'sender_gstin_no' => "VARCHAR(50) DEFAULT '' AFTER sender_gstin_type",
                'receiver_gstin_type' => "VARCHAR(50) DEFAULT '' AFTER receiver_country",
                'receiver_gstin_no' => "VARCHAR(50) DEFAULT '' AFTER receiver_gstin_type",
                'length_cm' => "DECIMAL(10,2) DEFAULT 0 AFTER weight",
                'breadth' => "DECIMAL(10,2) DEFAULT 0 AFTER length_cm",
                'height' => "DECIMAL(10,2) DEFAULT 0 AFTER breadth",
                'no_of_pieces' => "INT DEFAULT 1 AFTER height",
                'declared_value' => "DECIMAL(10,2) DEFAULT 0 AFTER content_description",
                'is_fragile' => "TINYINT DEFAULT 0 AFTER declared_value",
                'admin_notes' => "TEXT AFTER status",
                'shipment_id' => "INT DEFAULT NULL AFTER admin_notes",
                'tracking_number' => "VARCHAR(50) DEFAULT NULL AFTER shipment_id",
                'parcels' => "LONGTEXT DEFAULT NULL AFTER remarks",
                'invoice_items' => "LONGTEXT DEFAULT NULL AFTER parcels",
                'documents' => "LONGTEXT DEFAULT NULL AFTER invoice_items",
                'order_reference' => "VARCHAR(100) DEFAULT '' AFTER documents",
                'payment_mode' => "VARCHAR(30) DEFAULT 'prepaid' AFTER order_reference",
                'shipping_charge' => "DECIMAL(10,2) DEFAULT 0 AFTER payment_mode",
                'invoice_type' => "VARCHAR(30) DEFAULT 'INVOICE' AFTER shipping_charge",
                'invoice_currency' => "VARCHAR(10) DEFAULT 'INR' AFTER invoice_type",
                'hs_code' => "VARCHAR(50) DEFAULT '' AFTER invoice_currency",
                'export_reason' => "VARCHAR(255) DEFAULT '' AFTER hs_code",
                'terms_of_trade' => "VARCHAR(20) DEFAULT 'CIF' AFTER export_reason",
                'invoice_note' => "TEXT DEFAULT NULL AFTER terms_of_trade",
            ];

            foreach ($missing_columns as $col => $definition) {
                if (!in_array($col, $columns)) {
                    $wpdb->query("ALTER TABLE booking_requests ADD COLUMN $col $definition");
                }
            }
        }
    }

    if (!$wpdb->get_var("SHOW TABLES LIKE 'request_updates'")) {
        $wpdb->query("CREATE TABLE IF NOT EXISTS request_updates (
            id INT AUTO_INCREMENT PRIMARY KEY,
            request_id INT NOT NULL,
            update_type VARCHAR(30) DEFAULT 'info',
            title VARCHAR(255) NOT NULL,
            description TEXT,
            metadata LONGTEXT DEFAULT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            KEY idx_request_id (request_id)
        ) $charset");
    }

    if (!$wpdb->get_var("SHOW TABLES LIKE 'customer_addresses'")) {
        $wpdb->query("CREATE TABLE IF NOT EXISTS customer_addresses (
            id INT AUTO_INCREMENT PRIMARY KEY,
            customer_id INT DEFAULT NULL,
            customer_email VARCHAR(150) DEFAULT '',
            customer_phone VARCHAR(50) DEFAULT '',
            address_type VARCHAR(20) DEFAULT 'both',
            name VARCHAR(100) NOT NULL,
            company VARCHAR(150) DEFAULT '',
            phone VARCHAR(50) NOT NULL,
            phone_2 VARCHAR(50) DEFAULT '',
            email VARCHAR(150) DEFAULT '',
            address TEXT NOT NULL,
            address_2 VARCHAR(255) DEFAULT '',
            city VARCHAR(100) NOT NULL,
            state VARCHAR(100) DEFAULT '',
            pincode VARCHAR(20) DEFAULT '',
            country VARCHAR(100) DEFAULT 'INDIA',
            gstin_type VARCHAR(50) DEFAULT '',
            gstin_no VARCHAR(50) DEFAULT '',
            is_default TINYINT(1) DEFAULT 0,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            KEY idx_cust_id (customer_id),
            KEY idx_cust_email (customer_email)
        ) $charset");
    }

    if (!$wpdb->get_var("SHOW TABLES LIKE 'customer_documents'")) {
        $wpdb->query("CREATE TABLE IF NOT EXISTS customer_documents (
            id INT AUTO_INCREMENT PRIMARY KEY,
            customer_id INT DEFAULT NULL,
            customer_email VARCHAR(150) DEFAULT '',
            customer_phone VARCHAR(50) DEFAULT '',
            doc_type VARCHAR(100) NOT NULL,
            doc_name VARCHAR(255) DEFAULT '',
            doc_number VARCHAR(100) DEFAULT '',
            file_url VARCHAR(500) NOT NULL,
            file_name VARCHAR(255) DEFAULT '',
            file_size INT DEFAULT 0,
            file_type VARCHAR(50) DEFAULT '',
            notes TEXT DEFAULT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            KEY idx_cust_id (customer_id),
            KEY idx_cust_email (customer_email)
        ) $charset");
    }

    // AWBENTRY & parcel_history table checks (DISABLED BY USER DIRECTIVE: NO SCHEMA OR DATA WRITES)
    // Table creation and column alterations for AWBENTRY and parcel_history are completely disabled.

    set_transient('pe_cp_tables_checked', 1, DAY_IN_SECONDS);
}, 5);

// ══════════════════════════════════════
//  REST API: SYNC ENDPOINTS (Node.js → WP)
// ══════════════════════════════════════

add_action('rest_api_init', function () {
    // Sync a new booking request from Node.js backend
    register_rest_route('pe-cp/v1', '/sync-booking', [
        'methods' => 'POST',
        'callback' => 'pe_cp_rest_sync_booking',
        'permission_callback' => 'pe_cp_rest_verify_sync_key',
    ]);

    // Sync a status update from Node.js backend
    register_rest_route('pe-cp/v1', '/sync-status', [
        'methods' => 'POST',
        'callback' => 'pe_cp_rest_sync_status',
        'permission_callback' => 'pe_cp_rest_verify_sync_key',
    ]);

    // Sync a new shipment / AWB entry from Node.js backend
    register_rest_route('pe-cp/v1', '/sync-awb', [
        'methods' => 'POST',
        'callback' => 'pe_cp_rest_sync_awb',
        'permission_callback' => 'pe_cp_rest_verify_sync_key',
    ]);

    // Sync a customer account (create/update) from Node.js backend
    register_rest_route('pe-cp/v1', '/sync-customer', [
        'methods' => 'POST',
        'callback' => 'pe_cp_rest_sync_customer',
        'permission_callback' => 'pe_cp_rest_verify_sync_key',
    ]);

    // Sync a customer deletion from Node.js backend
    register_rest_route('pe-cp/v1', '/sync-customer-delete', [
        'methods' => 'POST',
        'callback' => 'pe_cp_rest_sync_customer_delete',
        'permission_callback' => 'pe_cp_rest_verify_sync_key',
    ]);

    // Sync a customer address from Node.js backend
    register_rest_route('pe-cp/v1', '/sync-address', [
        'methods' => 'POST',
        'callback' => 'pe_cp_rest_sync_address',
        'permission_callback' => 'pe_cp_rest_verify_sync_key',
    ]);

    // Sync permanent shipment deletion from Node.js backend
    register_rest_route('pe-cp/v1', '/sync-shipment-delete', [
        'methods' => 'POST',
        'callback' => 'pe_cp_rest_sync_shipment_delete',
        'permission_callback' => 'pe_cp_rest_verify_sync_key',
    ]);

    // Sync shipment customer assignment from Node.js backend
    register_rest_route('pe-cp/v1', '/sync-shipment-customer', [
        'methods' => 'POST',
        'callback' => 'pe_cp_rest_sync_shipment_customer',
        'permission_callback' => 'pe_cp_rest_verify_sync_key',
    ]);
});

/**
 * REST: Sync a customer address into WP customer_addresses table
 */
function pe_cp_rest_sync_address($request)
{
    global $wpdb;
    $d = $request->get_json_params();

    $name = sanitize_text_field($d['name'] ?? '');
    $phone = sanitize_text_field($d['phone'] ?? '');
    $address = sanitize_textarea_field($d['address'] ?? '');
    if (!$name || !$phone || !$address) {
        return new WP_REST_Response(['success' => false, 'message' => 'Name, phone and address are required'], 400);
    }

    $table_exists = $wpdb->get_var("SHOW TABLES LIKE 'customer_addresses'");
    if (!$table_exists && function_exists('pe_cp_create_tables')) {
        pe_cp_create_tables();
    }

    $existing = $wpdb->get_var($wpdb->prepare(
        "SELECT id FROM customer_addresses WHERE LOWER(TRIM(name)) = LOWER(TRIM(%s)) AND TRIM(phone) = TRIM(%s) AND LOWER(TRIM(address)) = LOWER(TRIM(%s)) LIMIT 1",
        $name,
        $phone,
        $address
    ));

    $data = [
        'customer_id' => intval($d['customer_id'] ?? 0) ?: null,
        'customer_email' => sanitize_email($d['customer_email'] ?? ''),
        'customer_phone' => sanitize_text_field($d['customer_phone'] ?? ''),
        'address_type' => sanitize_text_field($d['address_type'] ?? 'both'),
        'name' => $name,
        'company' => sanitize_text_field($d['company'] ?? ''),
        'phone' => $phone,
        'phone_2' => sanitize_text_field($d['phone_2'] ?? ''),
        'email' => sanitize_email($d['email'] ?? ''),
        'address' => $address,
        'address_2' => sanitize_text_field($d['address_2'] ?? ''),
        'city' => sanitize_text_field($d['city'] ?? ''),
        'state' => sanitize_text_field($d['state'] ?? ''),
        'pincode' => sanitize_text_field($d['pincode'] ?? ''),
        'country' => sanitize_text_field($d['country'] ?? 'INDIA'),
        'gstin_type' => sanitize_text_field($d['gstin_type'] ?? ''),
        'gstin_no' => sanitize_text_field($d['gstin_no'] ?? ''),
        'is_default' => intval($d['is_default'] ?? 0),
    ];

    if ($existing) {
        $wpdb->update('customer_addresses', $data, ['id' => $existing]);
        $savedId = $existing;
    } else {
        $wpdb->insert('customer_addresses', $data);
        $savedId = $wpdb->insert_id;
    }

    return new WP_REST_Response(['success' => true, 'id' => $savedId], 200);
}

/**
 * REST: Sync a customer account into the WP database.
 * Called by Node.js backend on customer create or update.
 */
function pe_cp_rest_sync_customer($request)
{
    global $wpdb;
    $d = $request->get_json_params();

    $email = sanitize_email($d['email'] ?? '');
    if (!$email) {
        return new WP_REST_Response(['success' => false, 'message' => 'email required'], 400);
    }

    $name = sanitize_text_field($d['name'] ?? '');
    $phone = sanitize_text_field($d['phone'] ?? '');
    $company = sanitize_text_field($d['company'] ?? '');
    $password = $d['password'] ?? '';
    $address = sanitize_text_field($d['address'] ?? '');
    $city = sanitize_text_field($d['city'] ?? '');
    $state = sanitize_text_field($d['state'] ?? '');
    $pincode = sanitize_text_field($d['pincode'] ?? '');
    $country = sanitize_text_field($d['country'] ?? 'INDIA');
    $gstin_no = sanitize_text_field($d['gstin_no'] ?? '');
    $credit_limit = floatval($d['credit_limit'] ?? 0);
    $current_balance = floatval($d['current_balance'] ?? 0);
    $status = ($d['status'] ?? 'active') === 'inactive' ? 'inactive' : 'active';

    $exists = $wpdb->get_row($wpdb->prepare("SELECT id, password FROM tbl_customers WHERE LOWER(TRIM(email)) = LOWER(%s)", $email));
    if ($exists) {
        $update_data = [
            'name' => $name,
            'phone' => $phone,
            'company' => $company,
            'address' => $address,
            'city' => $city,
            'state' => $state,
            'pincode' => $pincode,
            'country' => $country,
            'gstin_no' => $gstin_no,
            'credit_limit' => $credit_limit,
            'current_balance' => $current_balance,
            'status' => $status
        ];
        if (!empty($password)) {
            $update_data['password'] = $password;
        }
        $wpdb->update('tbl_customers', $update_data, ['id' => $exists->id]);
        return new WP_REST_Response(['success' => true, 'message' => 'Customer updated in WP', 'id' => $exists->id]);
    } else {
        $wpdb->insert('tbl_customers', [
            'name' => $name,
            'email' => $email,
            'phone' => $phone,
            'company' => $company,
            'password' => $password,
            'address' => $address,
            'city' => $city,
            'state' => $state,
            'pincode' => $pincode,
            'country' => $country,
            'gstin_no' => $gstin_no,
            'credit_limit' => $credit_limit,
            'current_balance' => $current_balance,
            'status' => $status
        ]);
        return new WP_REST_Response(['success' => true, 'message' => 'Customer created in WP', 'id' => $wpdb->insert_id]);
    }
}

/**
 * REST: Sync customer deletion.
 */
function pe_cp_rest_sync_customer_delete($request)
{
    global $wpdb;
    $d = $request->get_json_params();
    $email = sanitize_email($d['email'] ?? '');
    $id = intval($d['id'] ?? 0);

    if ($email) {
        $wpdb->query($wpdb->prepare("DELETE FROM tbl_customers WHERE LOWER(TRIM(email)) = LOWER(TRIM(%s))", $email));
        $wpdb->query($wpdb->prepare("DELETE FROM customer_addresses WHERE LOWER(TRIM(customer_email)) = LOWER(TRIM(%s))", $email));
        $wpdb->query($wpdb->prepare("DELETE FROM customer_documents WHERE LOWER(TRIM(customer_email)) = LOWER(TRIM(%s))", $email));
    }
    if ($id) {
        $wpdb->delete('tbl_customers', ['id' => $id]);
        $wpdb->delete('customer_addresses', ['customer_id' => $id]);
        $wpdb->delete('customer_documents', ['customer_id' => $id]);
    }

    return new WP_REST_Response(['success' => true, 'message' => 'Customer deleted from WP']);
}

/**
 * REST: Sync permanent shipment deletion from Node.js backend into WP database.
 */
function pe_cp_rest_sync_shipment_delete($request)
{
    global $wpdb;
    $d = $request->get_json_params();
    $awbs = array_filter(array_map('sanitize_text_field', (array)($d['awbs'] ?? [])));
    $ids = array_filter(array_map('intval', (array)($d['ids'] ?? [])));

    if (empty($awbs) && empty($ids)) {
        return new WP_REST_Response(['success' => false, 'message' => 'No AWBs or IDs provided'], 400);
    }

    // 1. Delete from AWBENTRY
    if (!empty($awbs)) {
        $phs = implode(',', array_fill(0, count($awbs), '%s'));
        $sql = "DELETE FROM AWBENTRY WHERE AWBNO IN ($phs) OR CAST(AWBNO AS CHAR) IN ($phs) OR VENDORAWB1 IN ($phs) OR VENDORAWB2 IN ($phs)";
        $params = array_merge($awbs, $awbs, $awbs, $awbs);
        $wpdb->query($wpdb->prepare($sql, ...$params));

        // 2. Delete from parcel_history
        $sql_ph = "DELETE FROM parcel_history WHERE AWBNO IN ($phs) OR CAST(AWBNO AS CHAR) IN ($phs)";
        $params_ph = array_merge($awbs, $awbs);
        $wpdb->query($wpdb->prepare($sql_ph, ...$params_ph));
    }

    // 3. Delete from booking_requests & request_updates
    $breq_conds = [];
    $breq_params = [];
    if (!empty($awbs)) {
        $phs = implode(',', array_fill(0, count($awbs), '%s'));
        $breq_conds[] = "request_awb IN ($phs)";
        $breq_conds[] = "tracking_number IN ($phs)";
        $breq_params = array_merge($breq_params, $awbs, $awbs);
    }
    if (!empty($ids)) {
        $phs_id = implode(',', array_fill(0, count($ids), '%d'));
        $breq_conds[] = "id IN ($phs_id)";
        $breq_conds[] = "shipment_id IN ($phs_id)";
        $breq_params = array_merge($breq_params, $ids, $ids);
    }

    if (!empty($breq_conds)) {
        $where = "(" . implode(" OR ", $breq_conds) . ")";
        $req_ids = $wpdb->get_col($wpdb->prepare("SELECT id FROM booking_requests WHERE $where", ...$breq_params));
        if (!empty($req_ids)) {
            $phs_upd = implode(',', array_fill(0, count($req_ids), '%d'));
            $wpdb->query($wpdb->prepare("DELETE FROM request_updates WHERE request_id IN ($phs_upd)", ...$req_ids));
        }
        $wpdb->query($wpdb->prepare("DELETE FROM booking_requests WHERE $where", ...$breq_params));
    }

    // 4. Delete from shipments table if exists
    $has_shipments = !empty($wpdb->get_var("SHOW TABLES LIKE 'shipments'"));
    if ($has_shipments) {
        $shp_conds = [];
        $shp_params = [];
        if (!empty($awbs)) {
            $phs = implode(',', array_fill(0, count($awbs), '%s'));
            $shp_conds[] = "tracking_number IN ($phs)";
            $shp_conds[] = "order_id IN ($phs)";
            $shp_params = array_merge($shp_params, $awbs, $awbs);
        }
        if (!empty($ids)) {
            $phs_id = implode(',', array_fill(0, count($ids), '%d'));
            $shp_conds[] = "id IN ($phs_id)";
            $shp_params = array_merge($shp_params, $ids);
        }
        if (!empty($shp_conds)) {
            $shp_where = "(" . implode(" OR ", $shp_conds) . ")";
            $wpdb->query($wpdb->prepare("DELETE FROM shipments WHERE $shp_where", ...$shp_params));
        }
    }

    return new WP_REST_Response(['success' => true, 'message' => 'Shipments permanently deleted from WP DB']);
}

/**
 * Verify the sync API key from the request header.
 */
function pe_cp_rest_verify_sync_key($request)
{
    $key = $request->get_header('X-Sync-Key');
    if (!$key || !defined('PE_CP_SYNC_KEY'))
        return false;
    return hash_equals(PE_CP_SYNC_KEY, $key);
}

/**
 * REST: Sync a new booking request into the WP database.
 * Called by Node.js backend after creating a booking request.
 */
function pe_cp_rest_sync_booking($request)
{
    global $wpdb;
    $d = $request->get_json_params();

    $awb = sanitize_text_field($d['request_awb'] ?? '');
    if (!$awb) {
        return new WP_REST_Response(['success' => false, 'message' => 'request_awb required'], 400);
    }

    // Check if already exists (idempotent)
    $exists = $wpdb->get_var($wpdb->prepare("SELECT id FROM booking_requests WHERE request_awb = %s", $awb));
    if ($exists) {
        return new WP_REST_Response(['success' => true, 'message' => 'Already synced']);
    }

    $wpdb->insert('booking_requests', [
        'request_awb' => $awb,
        'customer_id' => intval($d['customer_id'] ?? 0) ?: null,
        'customer_name' => sanitize_text_field($d['customer_name'] ?? ''),
        'customer_email' => sanitize_email($d['customer_email'] ?? ''),
        'customer_phone' => sanitize_text_field($d['customer_phone'] ?? ''),
        'customer_company' => sanitize_text_field($d['customer_company'] ?? ''),
        'sender_name' => sanitize_text_field($d['sender_name'] ?? ''),
        'sender_company' => sanitize_text_field($d['sender_company'] ?? ''),
        'sender_email' => sanitize_email($d['sender_email'] ?? ''),
        'sender_phone' => sanitize_text_field($d['sender_phone'] ?? ''),
        'sender_address' => sanitize_text_field($d['sender_address'] ?? ''),
        'sender_address_2' => sanitize_text_field($d['sender_address_2'] ?? ''),
        'sender_city' => sanitize_text_field($d['sender_city'] ?? ''),
        'sender_pincode' => sanitize_text_field($d['sender_pincode'] ?? ''),
        'sender_state' => sanitize_text_field($d['sender_state'] ?? ''),
        'sender_country' => sanitize_text_field($d['sender_country'] ?? 'INDIA'),
        'sender_gstin_type' => sanitize_text_field($d['sender_gstin_type'] ?? ''),
        'sender_gstin_no' => sanitize_text_field($d['sender_gstin_no'] ?? ''),
        'receiver_name' => sanitize_text_field($d['receiver_name'] ?? ''),
        'receiver_email' => sanitize_email($d['receiver_email'] ?? ''),
        'receiver_phone' => sanitize_text_field($d['receiver_phone'] ?? ''),
        'receiver_address' => sanitize_text_field($d['receiver_address'] ?? ''),
        'receiver_address_2' => sanitize_text_field($d['receiver_address_2'] ?? ''),
        'receiver_city' => sanitize_text_field($d['receiver_city'] ?? ''),
        'receiver_pincode' => sanitize_text_field($d['receiver_pincode'] ?? ''),
        'receiver_state' => sanitize_text_field($d['receiver_state'] ?? ''),
        'receiver_country' => sanitize_text_field($d['receiver_country'] ?? ''),
        'receiver_gstin_type' => sanitize_text_field($d['receiver_gstin_type'] ?? ''),
        'receiver_gstin_no' => sanitize_text_field($d['receiver_gstin_no'] ?? ''),
        'package_type' => sanitize_text_field($d['package_type'] ?? 'parcel'),
        'weight' => floatval($d['weight'] ?? 0),
        'length' => floatval($d['length'] ?? ($d['length_cm'] ?? 0)),
        'length_cm' => floatval($d['length_cm'] ?? ($d['length'] ?? 0)),
        'breadth' => floatval($d['breadth'] ?? 0),
        'height' => floatval($d['height'] ?? 0),
        'no_of_pieces' => intval($d['no_of_pieces'] ?? 1),
        'content_description' => sanitize_textarea_field($d['content_description'] ?? ''),
        'declared_value' => floatval($d['declared_value'] ?? 0),
        'is_fragile' => intval($d['is_fragile'] ?? 0),
        'remarks' => sanitize_textarea_field($d['remarks'] ?? ''),
        'parcels' => is_array($d['parcels'] ?? null) ? json_encode($d['parcels']) : (is_string($d['parcels'] ?? null) ? $d['parcels'] : null),
        'invoice_items' => is_array($d['invoice_items'] ?? null) ? json_encode($d['invoice_items']) : (is_string($d['invoice_items'] ?? null) ? $d['invoice_items'] : null),
        'documents' => is_array($d['documents'] ?? null) ? json_encode($d['documents']) : (is_string($d['documents'] ?? null) ? $d['documents'] : null),
        'order_reference' => sanitize_text_field($d['order_reference'] ?? ''),
        'payment_mode' => sanitize_text_field($d['payment_mode'] ?? 'prepaid'),
        'shipping_charge' => floatval($d['shipping_charge'] ?? 0),
        'invoice_type' => sanitize_text_field($d['invoice_type'] ?? 'INVOICE'),
        'invoice_currency' => sanitize_text_field($d['invoice_currency'] ?? 'INR'),
        'hs_code' => sanitize_text_field($d['hs_code'] ?? ''),
        'export_reason' => sanitize_text_field($d['export_reason'] ?? ''),
        'terms_of_trade' => sanitize_text_field($d['terms_of_trade'] ?? 'CIF'),
        'invoice_note' => sanitize_textarea_field($d['invoice_note'] ?? ''),
        'status' => sanitize_text_field($d['status'] ?? 'pending'),
    ]);

    $local_id = $wpdb->insert_id;

    // Insert initial timeline entry
    if ($local_id) {
        $wpdb->insert('request_updates', [
            'request_id' => $local_id,
            'update_type' => 'info',
            'title' => 'Request Submitted',
            'description' => 'Your booking request has been submitted successfully and is awaiting review.',
        ]);
    }

    return new WP_REST_Response(['success' => true, 'wp_id' => $local_id]);
}

/**
 * REST: Sync a status update into the WP database.
 * Called by Node.js backend after admin changes booking request status.
 */
function pe_cp_rest_sync_status($request)
{
    global $wpdb;
    $d = $request->get_json_params();

    $awb = sanitize_text_field($d['request_awb'] ?? ($d['tracking_number'] ?? ''));
    if (!$awb) {
        return new WP_REST_Response(['success' => false, 'message' => 'request_awb or tracking_number required'], 400);
    }

    $raw_digits = preg_replace('/\D/', '', $awb);
    $awb_no = $raw_digits ? intval($raw_digits) : 0;

    // Find local booking request by AWB or tracking number
    $local = $wpdb->get_row($wpdb->prepare(
        "SELECT * FROM booking_requests WHERE request_awb = %s OR tracking_number = %s LIMIT 1",
        $awb,
        $awb
    ));

    // Resolve customer info if provided
    $has_cust = isset($d['customer_id']) || isset($d['customer_name']) || isset($d['customer_type']);
    $cust_id = isset($d['customer_id']) && $d['customer_id'] !== '' && $d['customer_id'] !== null ? intval($d['customer_id']) : null;
    $cust_type = sanitize_text_field($d['customer_type'] ?? ($cust_id ? 'registered' : 'walkin'));
    $is_walkin = ($cust_type === 'walkin' || !$cust_id);
    $cust_code = $is_walkin ? 'W001' : strval($cust_id);
    $cust_name = sanitize_text_field($d['customer_name'] ?? '');
    if (!$cust_name) {
        $cust_name = $is_walkin ? 'WALKING CUSTOMER' : 'CUSTOMER';
    } else {
        $cust_name = $is_walkin ? 'WALKING CUSTOMER' : strtoupper($cust_name);
    }

    if ($local) {
        // Update the booking request fields
        $update_data = ['status' => sanitize_text_field($d['status'] ?? 'pending')];

        if (isset($d['admin_notes'])) {
            $update_data['admin_notes'] = sanitize_textarea_field($d['admin_notes']);
        }
        if (isset($d['shipment_id'])) {
            $update_data['shipment_id'] = intval($d['shipment_id']) ?: null;
        }
        if (isset($d['tracking_number'])) {
            $update_data['tracking_number'] = sanitize_text_field($d['tracking_number']);
        }
        if (isset($d['shipping_charge'])) {
            $update_data['shipping_charge'] = floatval($d['shipping_charge']);
        }
        if (isset($d['total_amount'])) {
            $update_data['total_amount'] = floatval($d['total_amount']);
        }
        if ($has_cust) {
            $update_data['customer_id'] = $cust_id;
            $update_data['customer_name'] = $is_walkin ? 'Walk-in Customer' : $cust_name;
        }

        $wpdb->update('booking_requests', $update_data, ['id' => $local->id]);

        // Insert timeline entries
        $updates = $d['updates'] ?? [];
        foreach ($updates as $upd) {
            $wpdb->insert('request_updates', [
                'request_id' => $local->id,
                'update_type' => sanitize_text_field($upd['type'] ?? 'info'),
                'title' => sanitize_text_field($upd['title'] ?? ''),
                'description' => sanitize_textarea_field($upd['description'] ?? ''),
                'metadata' => isset($upd['metadata']) ? wp_json_encode($upd['metadata']) : null,
            ]);
        }
    }

    // Update AWBENTRY totals & customer assignment
    $finalAmt = floatval($d['total_amount'] ?? ($d['shipping_charge'] ?? 0));
    $awb_updates = [];
    $awb_params = [];
    if ($finalAmt > 0) {
        $awb_updates[] = "TOTAL = %f, NETAMOUNT = %f, CHARGES = %f";
        $awb_params[] = $finalAmt;
        $awb_params[] = $finalAmt;
        $awb_params[] = $finalAmt;
    }
    if ($has_cust) {
        $awb_updates[] = "CUSTCODE = %s, CUSTNAME = %s";
        $awb_params[] = $cust_code;
        $awb_params[] = $cust_name;
    }
    if (!empty($awb_updates) && ($awb || $awb_no)) {
        $awb_sql = "UPDATE AWBENTRY SET " . implode(", ", $awb_updates) . " WHERE AWBNO = %s OR CAST(AWBNO AS CHAR) = %s";
        $awb_params[] = strval($awb_no ?: $awb);
        $awb_params[] = strval($awb_no ?: $awb);
        $wpdb->query($wpdb->prepare($awb_sql, ...$awb_params));
    }

    return new WP_REST_Response([
        'success' => true,
        'synced_updates' => count($d['updates'] ?? []),
        'local_found' => !empty($local)
    ]);
}

/**
 * REST: Sync shipment customer assignment update into WP database (AWBENTRY, booking_requests, shipments).
 */
function pe_cp_rest_sync_shipment_customer($request)
{
    global $wpdb;
    $d = $request->get_json_params();

    $awb = sanitize_text_field($d['tracking_number'] ?? ($d['awb_no'] ?? ($d['request_awb'] ?? '')));
    $raw_digits = preg_replace('/\D/', '', $awb);
    $awb_no = $raw_digits ? intval($raw_digits) : 0;

    if (!$awb && !$awb_no) {
        return new WP_REST_Response(['success' => false, 'message' => 'tracking_number or awb_no required'], 400);
    }

    $cust_id = isset($d['customer_id']) && $d['customer_id'] !== '' && $d['customer_id'] !== null ? intval($d['customer_id']) : null;
    $cust_type = sanitize_text_field($d['customer_type'] ?? ($cust_id ? 'registered' : 'walkin'));
    $is_walkin = ($cust_type === 'walkin' || !$cust_id);

    $cust_code = $is_walkin ? 'W001' : strval($cust_id);
    $cust_name = sanitize_text_field($d['customer_name'] ?? '');
    if (!$cust_name) {
        $cust_name = $is_walkin ? 'WALKING CUSTOMER' : 'CUSTOMER';
    } else {
        $cust_name = $is_walkin ? 'WALKING CUSTOMER' : strtoupper($cust_name);
    }

    // 1. Update AWBENTRY
    if ($awb_no > 0) {
        $wpdb->query($wpdb->prepare(
            "UPDATE AWBENTRY SET CUSTCODE = %s, CUSTNAME = %s WHERE AWBNO = %d OR CAST(AWBNO AS CHAR) = %s",
            $cust_code,
            $cust_name,
            $awb_no,
            strval($awb_no)
        ));
    }

    // 2. Update booking_requests (including invoice_items and parcels)
    $req_awb = sanitize_text_field($d['request_awb'] ?? $awb);
    $shp_id = intval($d['shipment_id'] ?? 0);
    $inv_items_raw = $d['invoice_items'] ?? null;
    $inv_items_str = is_array($inv_items_raw) ? json_encode($inv_items_raw) : (is_string($inv_items_raw) && strlen($inv_items_raw) > 2 ? $inv_items_raw : null);
    $parcels_raw = $d['parcels'] ?? null;
    $parcels_str = is_array($parcels_raw) ? json_encode($parcels_raw) : (is_string($parcels_raw) && strlen($parcels_raw) > 2 ? $parcels_raw : null);

    $existing_br = $wpdb->get_var($wpdb->prepare(
        "SELECT id FROM booking_requests WHERE (request_awb != '' AND (request_awb = %s OR request_awb = %s)) OR (tracking_number != '' AND (tracking_number = %s OR tracking_number = %s)) OR (shipment_id > 0 AND shipment_id = %d) LIMIT 1",
        $req_awb,
        strval($awb_no),
        $awb,
        strval($awb_no),
        $shp_id
    ));

    if ($existing_br) {
        $br_sql = "UPDATE booking_requests SET customer_id = %s, customer_name = %s";
        $br_params = [$cust_id, $is_walkin ? 'Walk-in Customer' : $cust_name];
        if ($inv_items_str) {
            $br_sql .= ", invoice_items = %s";
            $br_params[] = $inv_items_str;
        }
        if ($parcels_str) {
            $br_sql .= ", parcels = %s";
            $br_params[] = $parcels_str;
        }
        $br_sql .= " WHERE id = %d";
        $br_params[] = intval($existing_br);
        $wpdb->query($wpdb->prepare($br_sql, ...$br_params));
    } elseif ($awb) {
        // Insert into booking_requests so customer portal immediately displays item details
        $wpdb->insert('booking_requests', [
            'customer_id' => $cust_id,
            'customer_name' => $is_walkin ? 'Walk-in Customer' : $cust_name,
            'request_awb' => $req_awb ?: $awb,
            'tracking_number' => $awb,
            'shipment_id' => $shp_id ?: null,
            'invoice_items' => $inv_items_str,
            'parcels' => $parcels_str,
            'shipping_charge' => floatval($d['shipping_charge'] ?? 0),
            'total_amount' => floatval($d['total_amount'] ?? 0),
            'status' => 'confirmed',
        ]);
    }

    // 3. Update shipments if exists
    $has_shipments = !empty($wpdb->get_var("SHOW TABLES LIKE 'shipments'"));
    if ($has_shipments) {
        $shp_sql = "UPDATE shipments SET customer_id = %s, customer_name = %s, customer_type = %s";
        $shp_params = [$cust_id, $is_walkin ? 'Walk-in Customer' : $cust_name, $cust_type];
        if ($inv_items_str) {
            $shp_sql .= ", invoice_items = %s";
            $shp_params[] = $inv_items_str;
        }
        if ($parcels_str) {
            $shp_sql .= ", parcels = %s";
            $shp_params[] = $parcels_str;
        }
        $shp_sql .= " WHERE tracking_number = %s OR order_id = %s OR id = %d";
        $shp_params[] = $awb;
        $shp_params[] = $awb;
        $shp_params[] = $shp_id;
        $wpdb->query($wpdb->prepare($shp_sql, ...$shp_params));
    }

    return new WP_REST_Response([
        'success' => true,
        'message' => 'Shipment customer assignment updated in WP',
        'awb' => $awb,
        'cust_code' => $cust_code,
        'cust_name' => $cust_name
    ]);
}

/**
 * REST: Sync a new AWB / shipment entry into the WP database.
 * Called by Node.js backend after direct booking (shipment) creation.
 */
function pe_cp_rest_sync_awb($request)
{
    global $wpdb;
    $d = $request->get_json_params();

    $awb_no = intval($d['awb_no'] ?? 0);
    if (!$awb_no) {
        return new WP_REST_Response(['success' => false, 'message' => 'awb_no required and must be an integer'], 400);
    }

    // Writes to AWBENTRY and parcel_history are DISABLED by user directive
    return new WP_REST_Response(['success' => true, 'message' => 'Sync received (AWBENTRY & parcel_history writes disabled)'], 200);

    return new WP_REST_Response(['success' => true, 'message' => 'AWB entry synced successfully']);
}

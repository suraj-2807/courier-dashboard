<?php
if (!defined('ABSPATH'))
  exit;
$cust = pe_cp_get_user();
global $wpdb;

// Build strict WHERE clause: only shipments belonging to this specific customer
$cust_id = intval($cust['customer_id'] ?? ($cust['id'] ?? 0));
$cust_email = strtolower(trim($cust['email'] ?? ''));
$cust_name = trim($cust['name'] ?? '');
$cust_company = trim($cust['company'] ?? '');
$cust_phone = trim($cust['phone'] ?? '');

$match_clauses = [];
$match_params = [];

// Check if shipments and booking_requests tables exist in WP database
$has_shipments_tbl = !empty($wpdb->get_var("SHOW TABLES LIKE 'shipments'"));
$has_booking_req_tbl = !empty($wpdb->get_var("SHOW TABLES LIKE 'booking_requests'"));

// 1. Direct match by registered customer ID / code (strictly excluding walk-in 'W001')
if ($cust_id > 0) {
  $match_clauses[] = "(a.CUSTCODE IN (%s, %s, %s) AND a.CUSTCODE != 'W001' AND LOWER(COALESCE(a.CUSTNAME, '')) != 'walking customer')";
  $match_params[] = strval($cust_id);
  $match_params[] = 'CUST-' . $cust_id;
  $match_params[] = 'CUST-' . str_pad($cust_id, 4, '0', STR_PAD_LEFT);

  if ($has_shipments_tbl) {
    $match_clauses[] = "(a.AWBNO IN (SELECT tracking_number FROM shipments WHERE customer_id = %d) OR CAST(a.AWBNO AS CHAR) IN (SELECT tracking_number FROM shipments WHERE customer_id = %d))";
    $match_params[] = $cust_id;
    $match_params[] = $cust_id;
  }
}

// 2. Exact match on shipments converted and pushed from THIS customer's booking requests
$breq_sub_conds = [];
$breq_sub_params = [];
if ($cust_id > 0) {
  $breq_sub_conds[] = "customer_id = %d";
  $breq_sub_params[] = $cust_id;
}
if ($cust_email !== '') {
  $breq_sub_conds[] = "LOWER(TRIM(customer_email)) = %s OR LOWER(TRIM(sender_email)) = %s";
  $breq_sub_params[] = $cust_email;
  $breq_sub_params[] = $cust_email;
}
$clean_cust_p = preg_replace('/[^0-9]/', '', $cust_phone);
$cust_phone_10 = strlen($clean_cust_p) >= 10 ? substr($clean_cust_p, -10) : $clean_cust_p;
if ($cust_phone_10) {
  $breq_sub_conds[] = "customer_phone LIKE %s OR sender_phone LIKE %s";
  $like_p = '%' . $wpdb->esc_like($cust_phone_10) . '%';
  $breq_sub_params[] = $like_p;
  $breq_sub_params[] = $like_p;
}
if (strlen($cust_name) >= 3) {
  $breq_sub_conds[] = "LOWER(TRIM(customer_name)) = %s OR LOWER(TRIM(sender_name)) = %s";
  $breq_sub_params[] = strtolower($cust_name);
  $breq_sub_params[] = strtolower($cust_name);
}
if (!empty($cust_company) && strlen($cust_company) >= 3) {
  $breq_sub_conds[] = "LOWER(TRIM(customer_company)) = %s OR LOWER(TRIM(sender_company)) = %s";
  $breq_sub_params[] = strtolower($cust_company);
  $breq_sub_params[] = strtolower($cust_company);
}

if (!empty($breq_sub_conds)) {
  $breq_where = $wpdb->prepare("(" . implode(" OR ", $breq_sub_conds) . ")", ...$breq_sub_params);
  $match_clauses[] = "a.AWBNO IN (SELECT request_awb FROM booking_requests WHERE request_awb != '' AND $breq_where)";
  $match_clauses[] = "a.AWBNO IN (SELECT tracking_number FROM booking_requests WHERE tracking_number IS NOT NULL AND tracking_number != '' AND $breq_where)";
}

// 3. Direct match by sender phone in AWBENTRY
if ($cust_phone_10) {
  $match_clauses[] = "(a.SPHONE1 LIKE %s)";
  $match_params[] = '%' . $wpdb->esc_like($cust_phone_10) . '%';
}

// 4. Match by customer name or company
if (!empty($cust_name) && strtolower($cust_name) !== 'walking customer' && strlen($cust_name) >= 3) {
  $match_clauses[] = "(LOWER(TRIM(a.CUSTNAME)) = %s OR LOWER(TRIM(a.SNAME)) = %s)";
  $match_params[] = strtolower($cust_name);
  $match_params[] = strtolower($cust_name);
}
if (!empty($cust_company) && strtolower($cust_company) !== 'walking customer' && strtolower($cust_company) !== strtolower($cust_name) && strlen($cust_company) >= 3) {
  $match_clauses[] = "(LOWER(TRIM(a.CUSTNAME)) = %s OR LOWER(TRIM(a.SNAME)) = %s)";
  $match_params[] = strtolower($cust_company);
  $match_params[] = strtolower($cust_company);
}

if (empty($match_clauses)) {
  $where_cust = "1=0";
} else {
  $where_all = "(" . implode(" OR ", $match_clauses) . ") AND a.AWBNO > 0";
  if (!empty($match_params)) {
    $where_all = $wpdb->prepare($where_all, ...$match_params);
  }
  // Filter out data before September 1, 2026 in customer dashboard (include current/unassigned dates)
  $where_cust = $where_all . " AND (a.AWBDATE >= '2026-09-01' OR a.AWBDATE = '0000-00-00' OR a.AWBDATE IS NULL)";
  // If date filter results in 0 shipments, fall back to all-time customer shipments
  $chk_ts = intval($wpdb->get_var("SELECT COUNT(*) FROM AWBENTRY a WHERE $where_cust"));
  if ($chk_ts === 0) {
    $where_cust = $where_all;
  }
}

$_st = "(SELECT ph.activity FROM parcel_history ph WHERE ph.AWBNO = a.AWBNO ORDER BY ph.date DESC, ph.time DESC LIMIT 1)";
$ts = intval($wpdb->get_var("SELECT COUNT(*) FROM AWBENTRY a WHERE $where_cust"));

// Delivered: PODTOWEB = 1, latest activity delivered, or parcel_history proof of delivery/delivered, or booking_requests
$_del_clause = "(a.PODTOWEB = 1 OR a.PODTOWEB = '1'" .
  " OR EXISTS (SELECT 1 FROM parcel_history ph WHERE ph.AWBNO = a.AWBNO AND (LOWER(ph.activity) LIKE '%delivered%' OR LOWER(ph.activity) LIKE '%dlvd%' OR LOWER(ph.activity) LIKE '%proof of delivery%' OR LOWER(ph.activity) LIKE '%signed by%' OR LOWER(ph.activity) = 'pod') AND LOWER(ph.activity) NOT LIKE '%out for%' AND LOWER(ph.activity) NOT LIKE '%undeliver%' AND LOWER(ph.activity) NOT LIKE '%not deliver%' AND LOWER(ph.activity) NOT LIKE '%attempt%')" .
  ($has_shipments_tbl ? " OR EXISTS (SELECT 1 FROM shipments sh WHERE (sh.tracking_number = CAST(a.AWBNO AS CHAR) OR sh.order_id = CAST(a.AWBNO AS CHAR)) AND (LOWER(sh.status) LIKE '%delivered%' OR LOWER(sh.status) LIKE '%proof of delivery%' OR LOWER(sh.status) = 'pod'))" : "") .
  " OR EXISTS (SELECT 1 FROM booking_requests br WHERE (br.request_awb = CAST(a.AWBNO AS CHAR) OR br.tracking_number = CAST(a.AWBNO AS CHAR)) AND (LOWER(br.status) LIKE '%delivered%' OR LOWER(br.status) LIKE '%proof of delivery%' OR LOWER(br.status) = 'pod'))" .
  ")";
$dc = intval($wpdb->get_var("SELECT COUNT(*) FROM AWBENTRY a WHERE $where_cust AND $_del_clause"));
$dc = min($dc, $ts);
$tc = intval($wpdb->get_var("SELECT COUNT(*) FROM AWBENTRY a WHERE $where_cust AND NOT $_del_clause AND (LOWER(COALESCE($_st, '')) LIKE '%transit%' OR LOWER(COALESCE($_st, '')) LIKE '%departed%' OR (a.VENDORAWB1 != '' AND a.VENDORAWB1 IS NOT NULL))"));

$iframe_booking_url = esc_url(add_query_arg([
  'cust_name' => $cust['name'],
  'cust_email' => $cust['email'],
  'cust_phone' => $cust['phone'],
  'cust_company' => $cust['company'] ?? '',
  'cust_id' => $cust['customer_id'] ?? ''
], PE_ADMIN_PORTAL_URL));

// Count pending requests for sidebar badge
$req_conds = [];
$req_params = [];
if ($cust_id > 0) {
  $req_conds[] = "customer_id = %d";
  $req_params[] = $cust_id;
}
if ($cust_email !== '') {
  $req_conds[] = "LOWER(TRIM(customer_email)) = %s OR LOWER(TRIM(sender_email)) = %s";
  $req_params[] = $cust_email;
  $req_params[] = $cust_email;
}
if (!empty($cust_phone)) {
  $clean_p = preg_replace('/[^0-9]/', '', $cust_phone);
  if (strlen($clean_p) >= 10) {
    $req_conds[] = "customer_phone LIKE %s OR sender_phone LIKE %s";
    $req_params[] = '%' . $wpdb->esc_like(substr($clean_p, -10)) . '%';
    $req_params[] = '%' . $wpdb->esc_like(substr($clean_p, -10)) . '%';
  }
}
if (strlen($cust_name) >= 3) {
  $req_conds[] = "LOWER(TRIM(customer_name)) = %s OR LOWER(TRIM(sender_name)) = %s";
  $req_params[] = strtolower($cust_name);
  $req_params[] = strtolower($cust_name);
}
$where_requests = !empty($req_conds) ? $wpdb->prepare("(" . implode(" OR ", $req_conds) . ")", ...$req_params) : "1=0";
$pending_requests_count = intval($wpdb->get_var("SELECT COUNT(*) FROM booking_requests WHERE status = 'pending' AND created_at >= '2026-09-01 00:00:00' AND ($where_requests)"));

// Fetch customer total amount across all shipments checking shipments, booking_requests, and AWBENTRY
$cust_total_amount = 0.00;
if (!empty($where_cust) && $where_cust !== "1=0") {
  // Build amount expression that checks all available data sources (mirrors per-row logic)
  // Order: 1) shipments table if exists, 2) AWBENTRY actual billed amounts, 3) booking_requests fallback
  $_amt_expr = "COALESCE(";
  if ($has_shipments_tbl) {
    $_amt_expr .= "(SELECT COALESCE(NULLIF(sh.final_grand_total + 0, 0), NULLIF(sh.grand_total + 0, 0), NULLIF(sh.total_amount + 0, 0), NULLIF(sh.net_amount + 0, 0), NULLIF(sh.shipping_charge + 0, 0)) FROM shipments sh WHERE sh.tracking_number = CAST(a.AWBNO AS CHAR) OR sh.order_id = CAST(a.AWBNO AS CHAR) LIMIT 1), ";
  }
  $_amt_expr .= "NULLIF(ROUND(REPLACE(REPLACE(COALESCE(a.TOTAL, '0'), ',', ''), ' ', '') + 0, 2), 0), ";
  $_amt_expr .= "NULLIF(ROUND(REPLACE(REPLACE(COALESCE(a.NETAMOUNT, '0'), ',', ''), ' ', '') + 0, 2), 0), ";
  $_amt_expr .= "NULLIF(ROUND(REPLACE(REPLACE(COALESCE(a.CHARGES, '0'), ',', ''), ' ', '') + 0, 2), 0), ";
  $_amt_expr .= "NULLIF(ROUND((COALESCE(a.RATE, 0) + 0) * (COALESCE(NULLIF(a.CHARGEWEIGHT + 0, 0), a.WEIGHT + 0, 0)), 2), 0), ";
  $_amt_expr .= "NULLIF(ROUND(REPLACE(REPLACE(COALESCE(a.RECEIPTAMOUNT, '0'), ',', ''), ' ', '') + 0, 2), 0), ";
  if (!empty($has_booking_req_tbl)) {
    $_amt_expr .= "(SELECT NULLIF(br.shipping_charge + 0, 0) FROM booking_requests br WHERE br.request_awb = CAST(a.AWBNO AS CHAR) OR br.tracking_number = CAST(a.AWBNO AS CHAR) LIMIT 1), ";
  }
  $_amt_expr .= "0)";

  $cust_total_amount = floatval($wpdb->get_var(
    "SELECT SUM($_amt_expr) FROM AWBENTRY a WHERE $where_cust AND a.AWBNO > 0"
  ) ?? 0);
  if ($cust_total_amount <= 0 && !empty($where_all) && $chk_ts === 0) {
    $cust_total_amount = floatval($wpdb->get_var(
      "SELECT SUM($_amt_expr) FROM AWBENTRY a WHERE $where_all AND a.AWBNO > 0"
    ) ?? 0);
  }
  // Fallback if needed
  if ($cust_total_amount <= 0) {
    $cust_total_amount = floatval($wpdb->get_var(
      "SELECT SUM(COALESCE(
        NULLIF(ROUND(REPLACE(REPLACE(COALESCE(a.TOTAL, '0'), ',', ''), ' ', '') + 0, 2), 0),
        NULLIF(ROUND(REPLACE(REPLACE(COALESCE(a.NETAMOUNT, '0'), ',', ''), ' ', '') + 0, 2), 0),
        NULLIF(ROUND(REPLACE(REPLACE(COALESCE(a.CHARGES, '0'), ',', ''), ' ', '') + 0, 2), 0),
        NULLIF(ROUND((COALESCE(a.RATE, 0) + 0) * (COALESCE(NULLIF(a.CHARGEWEIGHT + 0, 0), a.WEIGHT + 0, 0)), 2), 0),
        NULLIF(ROUND(REPLACE(REPLACE(COALESCE(a.RECEIPTAMOUNT, '0'), ',', ''), ' ', '') + 0, 2), 0),
        " . (!empty($has_booking_req_tbl) ? "(SELECT NULLIF(br.shipping_charge + 0, 0) FROM booking_requests br WHERE br.request_awb = CAST(a.AWBNO AS CHAR) OR br.tracking_number = CAST(a.AWBNO AS CHAR) LIMIT 1), " : "") . "
        0
      )) FROM AWBENTRY a WHERE $where_cust AND a.AWBNO > 0"
    ) ?? 0);
  }
  if ($cust_total_amount <= 0 && !empty($where_all) && $chk_ts === 0) {
    $cust_total_amount = floatval($wpdb->get_var(
      "SELECT SUM(COALESCE(
        NULLIF(ROUND(REPLACE(REPLACE(COALESCE(a.TOTAL, '0'), ',', ''), ' ', '') + 0, 2), 0),
        NULLIF(ROUND(REPLACE(REPLACE(COALESCE(a.NETAMOUNT, '0'), ',', ''), ' ', '') + 0, 2), 0),
        NULLIF(ROUND(REPLACE(REPLACE(COALESCE(a.CHARGES, '0'), ',', ''), ' ', '') + 0, 2), 0),
        NULLIF(ROUND((COALESCE(a.RATE, 0) + 0) * (COALESCE(NULLIF(a.CHARGEWEIGHT + 0, 0), a.WEIGHT + 0, 0)), 2), 0),
        NULLIF(ROUND(REPLACE(REPLACE(COALESCE(a.RECEIPTAMOUNT, '0'), ',', ''), ' ', '') + 0, 2), 0),
        " . (!empty($has_booking_req_tbl) ? "(SELECT NULLIF(br.shipping_charge + 0, 0) FROM booking_requests br WHERE br.request_awb = CAST(a.AWBNO AS CHAR) OR br.tracking_number = CAST(a.AWBNO AS CHAR) LIMIT 1), " : "") . "
        0
      )) FROM AWBENTRY a WHERE $where_all AND a.AWBNO > 0"
    ) ?? 0);
  }
}
?>
<style>
  #wpadminbar {
    display: none !important
  }

  html {
    margin-top: 0 !important
  }

  *,
  *::before,
  *::after {
    box-sizing: border-box
  }

  @keyframes cp-fadeIn {
    from {
      opacity: 0
    }

    to {
      opacity: 1
    }
  }

  @keyframes cp-fadeUp {
    from {
      opacity: 0;
      transform: translateY(15px)
    }

    to {
      opacity: 1;
      transform: translateY(0)
    }
  }

  @keyframes cp-slideIn {
    from {
      transform: translateX(100%)
    }

    to {
      transform: translateX(0)
    }
  }

  @keyframes cp-shimmer {
    0% {
      background-position: -400px 0
    }

    100% {
      background-position: 400px 0
    }
  }

  @keyframes cp-spin {
    to {
      transform: rotate(360deg)
    }
  }

  @keyframes cp-pulse-live {

    0%,
    100% {
      opacity: 1;
      transform: scale(1)
    }

    50% {
      opacity: .5;
      transform: scale(.85)
    }
  }

  :root {
    --cpbg: #f8fafc;
    --cpcard: #fff;
    --cpbdr: #e2e8f0;
    --cptext: #0f172a;
    --cptext2: #475569;
    --cptext3: #94a3b8;
    --cpred: #bb0013;
    --cpred-hover: #a00010;
    --cpgreen: #10b981;
    --cpblue: #3b82f6;
    --cpamber: #f59e0b;
    --cpsh: 0 4px 6px -1px rgba(0, 0, 0, 0.05), 0 2px 4px -2px rgba(0, 0, 0, 0.05);
    --cpsh2: 0 20px 25px -5px rgba(0, 0, 0, 0.1), 0 8px 10px -6px rgba(0, 0, 0, 0.1);
  }

  .cp-app {
    position: fixed;
    inset: 0;
    z-index: 99999;
    display: flex;
    font-family: 'Inter', sans-serif;
    background: var(--cpbg);
    color: var(--cptext);
    font-size: 14px;
    overflow: hidden
  }

  /* ── SIDEBAR ── */
  .cp-sidebar {
    width: 260px;
    background: #0f172a;
    border-right: 1px solid #1e293b;
    display: flex;
    flex-direction: column;
    flex-shrink: 0;
    position: relative;
    z-index: 10
  }

  .cp-sidebar-brand {
    display: flex;
    align-items: center;
    gap: 12px;
    padding: 24px;
    border-bottom: 1px solid #1e293b
  }

  .cp-sidebar-brand img {
    width: 36px;
    height: 36px;
    border-radius: 8px;
    object-fit: contain;
    filter: drop-shadow(0 2px 8px rgba(187, 0, 19, .2))
  }

  .cp-sidebar-brand h3 {
    font-size: 15px;
    font-weight: 900;
    color: #fff;
    margin: 0;
    letter-spacing: 1px
  }

  .cp-sidebar-brand p {
    font-size: 10px;
    font-weight: 700;
    color: var(--cptext3);
    letter-spacing: 1.5px;
    margin: 2px 0 0;
    text-transform: uppercase
  }

  .cp-sidebar-nav {
    flex: 1;
    padding: 24px 16px;
    display: flex;
    flex-direction: column;
    gap: 6px;
    overflow-y: auto
  }

  .cp-nav-item {
    display: flex;
    align-items: center;
    gap: 12px;
    padding: 12px 16px;
    border-radius: 12px;
    color: #94a3b8;
    font-weight: 600;
    text-decoration: none;
    cursor: pointer;
    transition: all .2s;
    border: none;
    background: transparent;
    text-align: left;
    width: 100%;
    font-size: 14px
  }

  .cp-nav-item:hover {
    color: #fff;
    background: rgba(255, 255, 255, 0.05)
  }

  .cp-nav-item.active {
    color: #fff;
    background: var(--cpred);
    box-shadow: 0 4px 12px rgba(187, 0, 19, .25)
  }

  .cp-nav-item i {
    font-size: 16px;
    width: 20px;
    text-align: center
  }

  .cp-sidebar-footer {
    padding: 20px 24px;
    border-top: 1px solid #1e293b;
    background: #090d16;
    display: flex;
    flex-direction: column;
    gap: 12px
  }

  .cp-user-info {
    display: flex;
    align-items: center;
    gap: 12px
  }

  .cp-user-avatar {
    width: 36px;
    height: 36px;
    background: linear-gradient(135deg, #bb0013, #d4001a);
    border-radius: 8px;
    display: flex;
    align-items: center;
    justify-content: center;
    color: #fff;
    font-weight: 800;
    font-size: 14px;
    box-shadow: 0 2px 8px rgba(187, 0, 19, .3)
  }

  .cp-user-details {
    flex: 1;
    min-width: 0
  }

  .cp-user-name {
    font-size: 13px;
    font-weight: 700;
    color: #fff;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap
  }

  .cp-user-role {
    font-size: 10px;
    font-weight: 600;
    color: #64748b;
    text-transform: uppercase;
    letter-spacing: 1px
  }

  .cp-logout-btn {
    padding: 8px 12px;
    border-radius: 8px;
    border: 1px solid #334155;
    background: transparent;
    color: #94a3b8;
    font-size: 12px;
    font-weight: 700;
    cursor: pointer;
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 8px;
    transition: all .15s
  }

  /* ── DESKTOP SIDEBAR COLLAPSE ── */
  .cp-sidebar-toggle {
    display: none;
    width: 28px;
    height: 28px;
    border-radius: 6px;
    border: 1px solid #334155;
    background: transparent;
    color: #64748b;
    align-items: center;
    justify-content: center;
    cursor: pointer;
    font-size: 12px;
    transition: all .15s;
    flex-shrink: 0;
    margin-left: auto;
    padding: 0
  }

  .cp-sidebar-toggle:hover {
    background: rgba(255, 255, 255, .08);
    color: #fff
  }

  @media(min-width:961px) {
    .cp-sidebar-toggle {
      display: flex
    }
   

    .cp-sidebar {
      transition: width .25s cubic-bezier(.4, 0, .2, 1)
    }

    .cp-sidebar.collapsed {
      width: 74px
    }

    .cp-sidebar.collapsed .cp-sidebar-brand > div {
      display: none
    }

    .cp-sidebar.collapsed .cp-sidebar-brand {
      justify-content: center;
      padding: 20px 12px
    }

    .cp-sidebar.collapsed .cp-sidebar-toggle {
      margin-left: 0;
      position: absolute;
      right: 8px;
      top: 24px
    }

    .cp-sidebar.collapsed .cp-sidebar-nav {
      padding: 16px 8px;
      gap: 4px
    }

    .cp-sidebar.collapsed .cp-nav-item {
      justify-content: center;
      padding: 12px 0;
      gap: 0
    }

    .cp-sidebar.collapsed .cp-nav-text {
      display: none
    }

    .cp-sidebar.collapsed .cp-nav-badge {
      position: absolute;
      top: 4px;
      right: 8px;
      margin-left: 0
    }

    .cp-sidebar.collapsed .cp-nav-item {
      position: relative
    }

    .cp-sidebar.collapsed .cp-nav-item i {
      font-size: 18px;
      width: auto
    }

    .cp-sidebar.collapsed .cp-sidebar-footer {
      padding: 14px 8px;
      align-items: center
    }

    .cp-sidebar.collapsed .cp-user-details {
      display: none
    }

    .cp-sidebar.collapsed .cp-user-info {
      justify-content: center
    }

    .cp-sidebar.collapsed .cp-logout-text {
      display: none
    }

    .cp-sidebar.collapsed .cp-logout-btn {
      justify-content: center;
      padding: 8px
    }
  }

  /* ── SIDEBAR COLLAPSE TOOLTIP ── */
  @media(min-width:961px) {
    .cp-sidebar.collapsed .cp-nav-item {
      position: relative
    }

    .cp-sidebar.collapsed .cp-nav-item::after {
      content: attr(data-tooltip);
      position: absolute;
      left: calc(100% + 10px);
      top: 50%;
      transform: translateY(-50%);
      background: #1e293b;
      color: #fff;
      padding: 5px 10px;
      border-radius: 6px;
      font-size: 12px;
      font-weight: 600;
      white-space: nowrap;
      opacity: 0;
      pointer-events: none;
      transition: opacity .15s;
      z-index: 100;
      box-shadow: 0 4px 12px rgba(0,0,0,.3)
    }

    .cp-sidebar.collapsed .cp-nav-item:hover::after {
      opacity: 1
    }
  }

  .cp-logout-btn:hover {
    color: #fff;
    background: var(--cpred)
  }

  /* ── MAIN CONTENT ── */
  .cp-main {
    flex: 1;
    display: flex;
    flex-direction: column;
    overflow: hidden;
    position: relative
  }

  .cp-main-content {
    flex: 1;
    overflow-y: auto;
    padding: 32px;
    display: none
  }

  .cp-main-content.active {
    display: block;
    animation: cp-fadeIn .3s ease
  }

  /* ── HEADER & TYPOGRAPHY ── */
  .cp-hdr-wrap {
    margin-bottom: 28px
  }

  .cp-page-title {
    font-size: 26px;
    font-weight: 900;
    color: var(--cptext);
    letter-spacing: -.5px;
    margin: 0 0 4px
  }

  .cp-page-sub {
    font-size: 14px;
    color: var(--cptext2);
    margin: 0;
    font-weight: 500
  }

  /* ── STATS ── */
  .cp-stats {
    display: grid;
    grid-template-columns: repeat(4, 1fr);
    gap: 16px;
    margin-bottom: 24px
  }

  .cp-stat {
    background: var(--cpcard);
    border-radius: 16px;
    padding: 22px 24px;
    border: 1px solid var(--cpbdr);
    box-shadow: var(--cpsh);
    display: flex;
    justify-content: space-between;
    align-items: flex-start;
    position: relative;
    overflow: hidden;
    transition: all .2s;
    cursor: default
  }

  .cp-stat:hover {
    transform: translateY(-3px);
    box-shadow: var(--cpsh2)
  }

  .cp-stat::before {
    content: '';
    position: absolute;
    left: 0;
    top: 0;
    bottom: 0;
    width: 4px;
    background: var(--cpred)
  }

  .cp-stat:nth-child(2)::before {
    background: var(--cpamber)
  }

  .cp-stat:nth-child(3)::before {
    background: var(--cpgreen)
  }

  .cp-stat:nth-child(4)::before {
    background: var(--cpblue)
  }

  .cp-stat-label {
    font-size: 11px;
    font-weight: 800;
    color: var(--cptext3);
    text-transform: uppercase;
    letter-spacing: 1.5px;
    margin-bottom: 6px
  }

  .cp-stat-value {
    font-size: 32px;
    font-weight: 900;
    color: var(--cptext);
    letter-spacing: -1px;
    line-height: 1
  }

  .cp-stat-desc {
    font-size: 12px;
    font-weight: 600;
    margin-top: 6px
  }

  .cp-stat-desc.g {
    color: var(--cpgreen)
  }

  .cp-stat-desc.w {
    color: var(--cpamber)
  }

  .cp-stat-desc.b {
    color: var(--cpblue)
  }

  .cp-stat-desc.r {
    color: var(--cpred)
  }

  .cp-stat-icon {
    width: 44px;
    height: 44px;
    border-radius: 12px;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 18px;
    flex-shrink: 0
  }

  .cp-stat:nth-child(1) .cp-stat-icon {
    background: rgba(187, 0, 19, .08);
    color: var(--cpred)
  }

  .cp-stat:nth-child(2) .cp-stat-icon {
    background: rgba(245, 158, 11, .08);
    color: var(--cpamber)
  }

  .cp-stat:nth-child(3) .cp-stat-icon {
    background: rgba(16, 185, 129, .08);
    color: var(--cpgreen)
  }

  .cp-stat:nth-child(4) .cp-stat-icon {
    background: rgba(59, 130, 246, .08);
    color: var(--cpblue)
  }

  /* ── NEW BOOKING CTA ── */
  .cp-cta-card {
    background: linear-gradient(135deg, #0f172a 0%, #1e293b 100%);
    border-radius: 16px;
    padding: 24px 28px;
    margin-bottom: 24px;
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 24px;
    box-shadow: 0 4px 24px rgba(0, 0, 0, .08);
    position: relative;
    overflow: hidden
  }

  .cp-cta-card::before {
    content: '';
    position: absolute;
    top: -60px;
    right: -40px;
    width: 220px;
    height: 220px;
    background: radial-gradient(circle, rgba(187, 0, 19, .15), transparent 70%);
    pointer-events: none
  }

  .cp-cta-info h3 {
    font-size: 20px;
    font-weight: 800;
    color: #fff;
    margin: 0 0 4px
  }

  .cp-cta-info p {
    font-size: 13px;
    color: #94a3b8;
    margin: 0;
    max-width: 400px
  }

  .cp-cta-btn-link {
    display: inline-flex;
    align-items: center;
    gap: 8px;
    padding: 12px 24px;
    background: linear-gradient(135deg, #bb0013, #d4001a);
    color: #fff;
    border: none;
    border-radius: 10px;
    font-size: 14px;
    font-weight: 700;
    cursor: pointer;
    transition: all .2s;
    text-decoration: none;
    box-shadow: 0 4px 12px rgba(187, 0, 19, .3)
  }

  .cp-cta-btn-link:hover {
    transform: translateY(-1px);
    box-shadow: 0 6px 18px rgba(187, 0, 19, .4)
  }

  /* ── SHIPMENT TABLE ── */
  .cp-tc {
    background: var(--cpcard);
    border-radius: 16px;
    border: 1px solid var(--cpbdr);
    box-shadow: var(--cpsh);
    overflow: hidden
  }

  .cp-th {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 16px 20px;
    border-bottom: 1px solid var(--cpbdr)
  }

  .cp-th h3 {
    font-size: 15px;
    font-weight: 800;
    display: flex;
    align-items: center;
    gap: 8px;
    margin: 0;
    color: var(--cptext)
  }

  .cp-th h3 i {
    color: var(--cpred)
  }

  .cp-th .badge {
    font-size: 11px;
    font-weight: 700;
    background: rgba(187, 0, 19, .08);
    color: var(--cpred);
    padding: 3px 10px;
    border-radius: 14px;
    margin-left: 6px
  }

  .cp-tw {
    overflow-x: auto
  }

  table.cp-t {
    width: 100%;
    border-collapse: collapse;
    min-width: 750px
  }

  .cp-t thead th {
    padding: 12px 16px;
    font-size: 10px;
    font-weight: 800;
    color: var(--cptext3);
    text-transform: uppercase;
    letter-spacing: 1px;
    text-align: left;
    border-bottom: 1px solid var(--cpbdr);
    background: #f8fafc
  }

  .cp-t tbody tr {
    border-bottom: 1px solid #f1f5f9;
    cursor: pointer;
    transition: all .15s
  }

  .cp-t tbody tr:hover {
    background: rgba(187, 0, 19, .02)
  }

  .cp-t tbody td {
    padding: 14px 16px;
    font-size: 13px;
    font-weight: 500;
    color: var(--cptext2)
  }

  .cp-t .awbc {
    font-weight: 700;
    color: var(--cptext);
    font-size: 14px
  }

  .cp-t .nmc {
    font-weight: 600;
    color: var(--cptext);
    max-width: 180px;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap
  }

  .cp-st {
    display: flex;
    align-items: flex-start;
    gap: 7px;
    font-size: 12px;
    font-weight: 600;
    line-height: 1.35;
    white-space: normal;
    word-break: break-word;
    max-width: 220px;
  }

  .cp-dot {
    width: 7px;
    height: 7px;
    border-radius: 50%;
    flex-shrink: 0;
    margin-top: 5px;
  }

  .dd {
    background: var(--cpgreen)
  }

  .dt {
    background: var(--cpamber)
  }

  .db {
    background: var(--cptext3)
  }

  .dr {
    background: #ef4444
  }

  .dbl {
    background: var(--cpblue)
  }

  /* ── FILTER & SEARCH ── */
  .cp-fb {
    display: flex;
    gap: 12px;
    margin-bottom: 16px
  }

  .cp-fs {
    flex: 1;
    display: flex;
    align-items: center;
    gap: 10px;
    background: var(--cpcard);
    border: 1px solid var(--cpbdr);
    border-radius: 12px;
    padding: 0 14px;
    transition: all .2s;
    box-shadow: var(--cpsh)
  }

  .cp-fs:focus-within {
    border-color: var(--cpred);
    box-shadow: 0 0 0 3px rgba(187, 0, 19, .06)
  }

  .cp-fs i {
    color: var(--cptext3)
  }

  .cp-fs input {
    flex: 1;
    padding: 10px 0;
    border: none;
    background: transparent;
    font-size: 13px;
    font-family: inherit;
    color: var(--cptext);
    outline: none
  }

  /* ── PAGINATION ── */
  .cp-pg {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 14px 20px;
    border-top: 1px solid var(--cpbdr);
    background: #f8fafc
  }

  .cp-pi {
    font-size: 12px;
    color: var(--cptext3)
  }

  .cp-pi strong {
    color: var(--cpred)
  }

  .cp-pbs {
    display: flex;
    gap: 4px
  }

  .cp-pb {
    width: 32px;
    height: 32px;
    border-radius: 6px;
    border: 1px solid var(--cpbdr);
    background: var(--cpcard);
    color: var(--cptext3);
    font-size: 11px;
    font-weight: 700;
    cursor: pointer;
    display: flex;
    align-items: center;
    justify-content: center;
    transition: all .15s
  }

  .cp-pb:hover {
    background: #f1f5f9;
    color: var(--cptext2)
  }

  .cp-pb.on {
    background: var(--cpred);
    color: #fff;
    border-color: var(--cpred)
  }

  .cp-pb:disabled {
    opacity: .4;
    cursor: not-allowed
  }

  /* ── IFRAME VIEW ── */
  .cp-iframe-wrapper {
    width: 100%;
    height: calc(100vh - 64px);
    border: none;
    border-radius: 16px;
    background: var(--cpcard);
    overflow: hidden;
    box-shadow: var(--cpsh);
    border: 1px solid var(--cpbdr)
  }

  /* ── PROFILE VIEW FORM ── */
  .cp-profile-grid {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 24px
  }

  .cp-profile-card {
    background: var(--cpcard);
    border-radius: 16px;
    border: 1px solid var(--cpbdr);
    padding: 24px;
    box-shadow: var(--cpsh);
    animation: cp-fadeUp .3s ease both
  }

  .cp-profile-card h3 {
    font-size: 16px;
    font-weight: 800;
    margin: 0 0 16px;
    color: var(--cptext);
    display: flex;
    align-items: center;
    gap: 8px;
    border-bottom: 1px solid var(--cpbdr);
    padding-bottom: 12px
  }

  .cp-profile-card h3 i {
    color: var(--cpred)
  }

  .cp-form-group {
    margin-bottom: 16px
  }

  .cp-form-group label {
    display: block;
    font-size: 12px;
    font-weight: 700;
    color: var(--cptext2);
    text-transform: uppercase;
    letter-spacing: 1px;
    margin-bottom: 6px
  }

  .cp-form-input {
    width: 100%;
    padding: 10px 14px;
    background: #f8fafc;
    border: 1px solid var(--cpbdr);
    border-radius: 8px;
    font-size: 13px;
    color: var(--cptext);
    transition: all .2s;
    font-family: inherit;
    font-weight: 500
  }

  .cp-form-input:focus {
    border-color: var(--cpred);
    background: #fff;
    box-shadow: 0 0 0 3px rgba(187, 0, 19, .06);
    outline: none
  }

  .cp-form-submit {
    padding: 10px 20px;
    background: var(--cpred);
    color: #fff;
    border: none;
    border-radius: 8px;
    font-size: 13px;
    font-weight: 700;
    cursor: pointer;
    transition: all .15s
  }

  .cp-form-submit:hover {
    background: var(--cpred-hover)
  }

  /* ── DETAIL PANEL ── */
  .cp-do {
    display: none;
    position: fixed;
    inset: 0;
    background: rgba(0, 0, 0, .5);
    z-index: 100000;
    justify-content: flex-end;
    backdrop-filter: blur(4px)
  }

  .cp-do.show {
    display: flex
  }

  .cp-dp {
    width: 560px;
    max-width: 100%;
    background: var(--cpcard);
    height: 100%;
    overflow-y: auto;
    border-left: 1px solid var(--cpbdr);
    animation: cp-slideIn .3s ease
  }

  .cp-dh {
    padding: 20px 24px;
    border-bottom: 1px solid var(--cpbdr);
    display: flex;
    justify-content: space-between;
    align-items: center;
    position: sticky;
    top: 0;
    background: var(--cpcard);
    z-index: 2
  }

  .cp-dh h3 {
    font-size: 16px;
    font-weight: 800;
    margin: 0;
    display: flex;
    align-items: center;
    gap: 8px;
    color: var(--cptext)
  }

  .cp-dh h3 i {
    color: var(--cpred)
  }

  .cp-dc {
    width: 32px;
    height: 32px;
    border-radius: 6px;
    border: 1px solid var(--cpbdr);
    background: var(--cpcard);
    cursor: pointer;
    display: flex;
    align-items: center;
    justify-content: center;
    color: var(--cptext3)
  }

  .cp-dc:hover {
    background: rgba(187, 0, 19, .08);
    color: var(--cpred)
  }

  .cp-db-body {
    padding: 24px
  }

  .cp-ds {
    margin-bottom: 20px
  }

  .cp-ds h4 {
    font-size: 11px;
    font-weight: 800;
    color: var(--cptext3);
    text-transform: uppercase;
    letter-spacing: 1.5px;
    margin: 0 0 10px;
    display: flex;
    align-items: center;
    gap: 6px
  }

  .cp-ds h4 i {
    color: var(--cpred)
  }

  .cp-dg {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 8px
  }

  .cp-df {
    background: #f8fafc;
    border: 1px solid var(--cpbdr);
    border-radius: 10px;
    padding: 10px 14px
  }

  .cp-df .l {
    font-size: 9px;
    font-weight: 800;
    color: var(--cptext3);
    text-transform: uppercase;
    margin-bottom: 3px
  }

  .cp-df .v {
    font-size: 13px;
    font-weight: 600;
    color: var(--cptext)
  }

  .cp-df.fl {
    grid-column: 1/-1
  }

  /* ── TIMELINE ── */
  .cp-tl {
    list-style: none;
    padding: 0;
    margin: 0
  }

  .cp-tl li {
    position: relative;
    padding: 10px 0 10px 24px;
    border-left: 2px solid var(--cpred);
    margin-left: 6px
  }

  .cp-tl li::before {
    content: '';
    position: absolute;
    left: -5px;
    top: 14px;
    width: 8px;
    height: 8px;
    border-radius: 50%;
    background: var(--cpred);
    border: 2px solid var(--cpcard)
  }

  .cp-tl li:first-child::before {
    background: var(--cpgreen)
  }

  .cp-tl-card {
    background: #f8fafc;
    border: 1px solid var(--cpbdr);
    border-radius: 8px;
    padding: 10px 12px
  }

  .cp-tla {
    font-weight: 700;
    color: var(--cptext);
    font-size: 13px;
    margin-bottom: 2px
  }

  .cp-tlm {
    font-size: 11px;
    color: var(--cptext3)
  }

  /* ── SKELETON ── */
  .cp-skeleton {
    background: linear-gradient(90deg, #f0f0f0 25%, #e0e0e0 50%, #f0f0f0 75%);
    background-size: 800px 100%;
    animation: cp-shimmer 1.5s ease infinite;
    border-radius: 6px;
    height: 16px
  }

  /* ── MOBILE HAMBURGER BUTTON ── */
  .cp-mobile-header {
    display: none;
    align-items: center;
    gap: 12px;
    padding: 12px 16px;
    background: #0f172a;
    border-bottom: 1px solid #1e293b;
    position: sticky;
    top: 0;
    z-index: 20
  }

  .cp-hamburger {
    width: 38px;
    height: 38px;
    border-radius: 10px;
    border: 1px solid #334155;
    background: transparent;
    color: #fff;
    display: flex;
    align-items: center;
    justify-content: center;
    cursor: pointer;
    font-size: 18px;
    transition: all .15s
  }

  .cp-hamburger:hover {
    background: rgba(255, 255, 255, .08);
    border-color: rgba(255, 255, 255, .2)
  }

  .cp-mobile-brand {
    display: flex;
    align-items: center;
    gap: 10px;
    flex: 1
  }

  .cp-mobile-brand img {
    width: 32px;
    height: 32px;
    border-radius: 8px;
    object-fit: contain
  }

  .cp-mobile-brand h3 {
    font-size: 14px;
    font-weight: 900;
    color: #fff;
    margin: 0;
    letter-spacing: .5px
  }

  .cp-mobile-brand p {
    font-size: 9px;
    font-weight: 700;
    color: #64748b;
    letter-spacing: 1.5px;
    text-transform: uppercase;
    margin: 1px 0 0
  }

  /* ── SIDEBAR OVERLAY ── */
  .cp-sidebar-overlay {
    display: none;
    position: fixed;
    inset: 0;
    background: rgba(0, 0, 0, .5);
    backdrop-filter: blur(3px);
    z-index: 99998
  }

  .cp-sidebar-overlay.show {
    display: block
  }

  /* ── RESPONSIVE ── */
  @media(max-width:960px) {
    .cp-mobile-header {
      display: flex
    }
     .cp-app{
        flex-direction: column;
    
    }
    td.cp-status-cell {
    min-width: 250px;
}

    .cp-sidebar {
      position: fixed;
      inset: 0;
      right: auto;
      width: 280px;
      z-index: 99999;
      transform: translateX(-100%);
      transition: transform .3s cubic-bezier(.4, 0, .2, 1);
      overflow-y: auto
    }

    .cp-sidebar.open {
      transform: translateX(0)
    }

    .cp-sidebar-close {
      display: flex !important
    }

    .cp-main-content {
      padding: 20px 16px
    }

    .cp-stats {
      grid-template-columns: repeat(2, 1fr)
    }

    .cp-profile-grid {
      grid-template-columns: 1fr
    }

    .cp-cta-card {
      flex-direction: column;
      text-align: center;
      padding: 20px
    }
  }

  @media(max-width:480px) {
    .cp-stats {
      grid-template-columns: 1fr
    }
    .cp-app{
        flex-direction: column !important;
    }
  }

  /* ── SIDEBAR CLOSE BUTTON ── */
  .cp-sidebar-close {
    display: none;
    position: absolute;
    top: 16px;
    right: 16px;
    width: 32px;
    height: 32px;
    border-radius: 8px;
    border: 1px solid #334155;
    background: transparent;
    color: #94a3b8;
    align-items: center;
    justify-content: center;
    cursor: pointer;
    font-size: 16px;
    z-index: 5;
    transition: all .15s
  }

  .cp-sidebar-close:hover {
    background: rgba(255, 255, 255, .08);
    color: #fff
  }

  /* ── ADDRESS FILTER TABS ── */
  .cp-addr-filters {
    display: flex;
    gap: 6px;
    background: rgba(0, 0, 0, 0.03);
    padding: 4px;
    border-radius: 10px;
    border: 1px solid var(--cpbdr)
  }

  .cp-addr-filter {
    border: none;
    background: transparent;
    padding: 7px 14px;
    border-radius: 8px;
    font-size: 12px;
    font-weight: 700;
    color: var(--cptext2);
    cursor: pointer;
    transition: all .15s;
    display: flex;
    align-items: center;
    gap: 5px
  }

  .cp-addr-filter:hover {
    background: rgba(0, 0, 0, .04)
  }

  .cp-addr-filter.active {
    background: #fff;
    color: var(--cptext);
    box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1)
  }

  /* ── REQUEST STATUS STYLES ── */
  .st-pending {
    color: var(--cpamber);
    font-weight: 700;
  }

  .st-processing {
    color: var(--cpblue);
    font-weight: 700;
  }

  .st-confirmed {
    color: var(--cpgreen);
    font-weight: 700;
  }

  .st-rejected {
    color: var(--cpred);
    font-weight: 700;
  }

  .bg-pending {
    background: var(--cpamber) !important;
  }

  .bg-processing {
    background: var(--cpblue) !important;
  }

  .bg-confirmed {
    background: var(--cpgreen) !important;
  }

  .bg-rejected {
    background: var(--cpred) !important;
  }

  .cp-status-tab.active {
    background: #fff !important;
    color: var(--cptext) !important;
    box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
  }

  /* ── LIVE INDICATOR ── */
  .cp-live-badge {
    display: inline-flex;
    align-items: center;
    gap: 5px;
    padding: 3px 10px;
    border-radius: 14px;
    background: rgba(16, 185, 129, .08);
    font-size: 10px;
    font-weight: 800;
    color: var(--cpgreen);
    letter-spacing: .5px;
    margin-left: 8px;
    text-transform: uppercase;
    transition: opacity .3s
  }

  .cp-live-dot {
    width: 6px;
    height: 6px;
    border-radius: 50%;
    background: var(--cpgreen);
    animation: cp-pulse-live 1.5s ease-in-out infinite
  }

  .cp-live-badge.paused {
    opacity: .3
  }

  .cp-live-badge.paused .cp-live-dot {
    animation: none
  }

  /* ── COPY BUTTON ── */
  .cp-copy-btn {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    gap: 4px;
    padding: 2px 7px;
    background: #f1f5f9;
    color: #475569;
    border: 1px solid #cbd5e1;
    border-radius: 5px;
    font-size: 11px;
    font-weight: 600;
    cursor: pointer;
    transition: all .15s ease;
    line-height: 1.4;
    vertical-align: middle;
  }
  .cp-copy-btn:hover {
    background: #e2e8f0;
    color: #0f172a;
    border-color: #94a3b8;
    transform: scale(1.04);
  }
  .cp-copy-btn:active {
    transform: scale(0.96);
  }

  /* ── TOAST NOTIFICATIONS ── */
  .cp-toast-container {
    position: fixed;
    top: 20px;
    right: 20px;
    z-index: 200000;
    display: flex;
    flex-direction: column;
    gap: 10px;
    pointer-events: none
  }

  .cp-toast {
    pointer-events: auto;
    display: flex;
    align-items: center;
    gap: 12px;
    padding: 14px 20px;
    border-radius: 12px;
    background: #fff;
    border: 1px solid var(--cpbdr);
    box-shadow: 0 12px 40px rgba(0, 0, 0, .12), 0 4px 12px rgba(0, 0, 0, .06);
    min-width: 300px;
    max-width: 420px;
    animation: cp-toast-in .4s ease;
    font-size: 13px;
    font-weight: 600;
    color: var(--cptext)
  }

  .cp-toast.removing {
    animation: cp-toast-out .3s ease forwards
  }

  .cp-toast-icon {
    width: 34px;
    height: 34px;
    border-radius: 8px;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 15px;
    flex-shrink: 0
  }

  .cp-toast-icon.success {
    background: rgba(16, 185, 129, .1);
    color: var(--cpgreen)
  }

  .cp-toast-icon.info {
    background: rgba(59, 130, 246, .1);
    color: var(--cpblue)
  }

  .cp-toast-icon.warning {
    background: rgba(245, 158, 11, .1);
    color: var(--cpamber)
  }

  .cp-toast-icon.error {
    background: rgba(187, 0, 19, .1);
    color: var(--cpred)
  }

  .cp-toast-body {
    flex: 1;
    min-width: 0
  }

  .cp-toast-title {
    font-weight: 700;
    margin-bottom: 2px
  }

  .cp-toast-desc {
    font-size: 11px;
    color: var(--cptext2);
    font-weight: 500
  }

  @keyframes cp-toast-in {
    from {
      opacity: 0;
      transform: translateX(40px) scale(.95)
    }

    to {
      opacity: 1;
      transform: translateX(0) scale(1)
    }
  }

  @keyframes cp-toast-out {
    to {
      opacity: 0;
      transform: translateX(40px) scale(.95)
    }
  }

  /* ── ROW HIGHLIGHT ON CHANGE ── */
  @keyframes cp-row-highlight {
    0% {
      background: rgba(16, 185, 129, .12)
    }

    100% {
      background: transparent
    }
  }

  .cp-t tbody tr.cp-row-changed {
    animation: cp-row-highlight 2s ease-out
  }
</style>

<div class="cp-app" id="cp-app">

  <!-- MOBILE HEADER -->
  <div class="cp-mobile-header">
    <button class="cp-hamburger" onclick="cpToggleMobileSidebar()" aria-label="Open menu">
      <i class="fa-solid fa-bars"></i>
    </button>
    <div class="cp-mobile-brand">
      <img src="<?php echo esc_url(PE_CP_LOGO_URL); ?>" alt="PE">
      <div>
        <h3>Prince Express</h3>
        <p>Customer Portal</p>
      </div>
    </div>
  </div>

  <!-- SIDEBAR OVERLAY -->
  <div class="cp-sidebar-overlay" id="cp-sidebar-overlay" onclick="cpCloseMobileSidebar()"></div>

  <!-- SIDEBAR -->
  <aside class="cp-sidebar" id="cp-sidebar">
    <button class="cp-sidebar-close" onclick="cpCloseMobileSidebar()" aria-label="Close menu">
      <i class="fa-solid fa-xmark"></i>
    </button>
    <div class="cp-sidebar-brand">
      <img src="<?php echo esc_url(PE_CP_LOGO_URL); ?>" alt="PE">
      <div>
        <h3>Prince Express</h3>
        <p>Customer Portal</p>
      </div>
      <button class="cp-sidebar-toggle" onclick="cpToggleSidebarCollapse()" title="Collapse menu">
        <i class="fa-solid fa-angles-left" id="cp-collapse-icon"></i>
      </button>
    </div>

    <nav class="cp-sidebar-nav">
      <button class="cp-nav-item active" data-tooltip="My Shipments" onclick="cpSwitchTab('shipments', this); cpCloseMobileSidebar();">
        <i class="fa-solid fa-boxes-stacked"></i> <span class="cp-nav-text">My Shipments</span>
      </button>
      <button class="cp-nav-item" data-tooltip="My Requests" onclick="cpSwitchTab('requests', this); cpCloseMobileSidebar();">
        <i class="fa-solid fa-clipboard-list"></i> <span class="cp-nav-text">My Requests</span>
        <?php if ($pending_requests_count > 0): ?>
          <span class="cp-nav-badge"
            style="background:var(--cpamber);color:#fff;border-radius:10px;padding:1px 6px;font-size:10px;font-weight:700;margin-left:auto"><?php echo $pending_requests_count; ?></span>
        <?php endif; ?>
      </button>
      <button class="cp-nav-item" data-tooltip="Request Booking" onclick="cpSwitchTab('new-booking', this); cpCloseMobileSidebar();">
        <i class="fa-solid fa-plus"></i> <span class="cp-nav-text">Request Booking</span>
      </button>
      <button class="cp-nav-item" data-tooltip="Address Book" onclick="cpSwitchTab('addresses', this); cpCloseMobileSidebar();">
        <i class="fa-solid fa-address-book"></i> <span class="cp-nav-text">Address Book</span>
      </button>
      <button class="cp-nav-item" data-tooltip="My Documents" onclick="cpSwitchTab('documents', this); cpCloseMobileSidebar();">
        <i class="fa-solid fa-file-shield"></i> <span class="cp-nav-text">My Documents</span>
      </button>
      <button class="cp-nav-item" data-tooltip="My Profile" onclick="cpSwitchTab('profile', this); cpCloseMobileSidebar();">
        <i class="fa-solid fa-user-gear"></i> <span class="cp-nav-text">My Profile</span>
      </button>
    </nav>

    <div class="cp-sidebar-footer">
      <div class="cp-user-info">
        <div class="cp-user-avatar"><?php echo strtoupper(substr($cust['name'], 0, 1)); ?></div>
        <div class="cp-user-details">
          <div class="cp-user-name" id="cp-sidebar-uname"><?php echo esc_html($cust['name']); ?></div>
          <div class="cp-user-role" style="display:flex;align-items:center;gap:4px;flex-wrap:wrap;">
            <span>Customer</span>
            <?php if (!empty($cust['customer_id'])): ?>
              <span
                style="background:var(--cpblue);color:#fff;font-size:9px;font-weight:800;padding:1px 5px;border-radius:4px;letter-spacing:0.5px;">CUST-<?php echo str_pad(intval($cust['customer_id']), 4, '0', STR_PAD_LEFT); ?></span>
            <?php endif; ?>
          </div>
        </div>
      </div>
      <button class="cp-logout-btn" onclick="cpLogout()">
        <i class="fa-solid fa-right-from-bracket"></i> <span class="cp-logout-text">Sign Out</span>
      </button>
    </div>
  </aside>

  <!-- MAIN -->
  <main class="cp-main">

    <!-- TAB 1: SHIPMENTS -->
    <div class="cp-main-content active" id="tab-shipments">
      <div class="cp-hdr-wrap">
        <h1 class="cp-page-title">Welcome, <span
            id="cp-welcome-uname"><?php echo esc_html(ucfirst($cust['name'])); ?></span></h1>
        <p class="cp-page-sub">Manage your shipments, view detailed statuses, and request new bookings.</p>
      </div>

      <!-- Stats -->
      <div class="cp-stats" style="grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));">
        <div class="cp-stat">
          <div>
            <div class="cp-stat-label">Total Shipments</div>
            <div class="cp-stat-value" id="cp-stat-total-shipments"><?php echo number_format($ts); ?></div>
            <div class="cp-stat-desc r">All time</div>
          </div>
          <div class="cp-stat-icon"><i class="fa-solid fa-boxes-stacked"></i></div>
        </div>
        <div class="cp-stat">
          <div>
            <div class="cp-stat-label">In Transit</div>
            <div class="cp-stat-value" id="cp-stat-transit"><?php echo str_pad($tc, 2, '0', STR_PAD_LEFT); ?></div>
            <div class="cp-stat-desc w">On the way</div>
          </div>
          <div class="cp-stat-icon"><i class="fa-solid fa-truck"></i></div>
        </div>
        <div class="cp-stat">
          <div>
            <div class="cp-stat-label">Delivered</div>
            <div class="cp-stat-value" id="cp-stat-delivered"><?php echo number_format($dc); ?></div>
            <div class="cp-stat-desc g">Completed</div>
          </div>
          <div class="cp-stat-icon"><i class="fa-solid fa-circle-check"></i></div>
        </div>
        <div class="cp-stat">
          <div>
            <div class="cp-stat-label">Total Amount</div>
            <div class="cp-stat-value" id="cp-stat-total-amount" style="font-size:20px; font-weight:800; color:var(--cpgreen);">
              ₹<?php echo number_format($cust_total_amount, 2); ?></div>
            <div class="cp-stat-desc g">Total Amount</div>
          </div>
          <div class="cp-stat-icon"><i class="fa-solid fa-file-invoice-dollar"></i></div>
        </div>
      </div>

      <!-- Quick CTA -->
      <div class="cp-cta-card">
        <div class="cp-cta-info">
          <h3>Need to ship a package? 📦</h3>
          <p>Fill in your shipment details and our team will handle the rest. You'll receive your AWB number instantly.
          </p>
        </div>
        <button class="cp-cta-btn-link" onclick="cpSwitchTab('new-booking')" style="border:none;cursor:pointer;">
          <i class="fa-solid fa-plus"></i> Request Booking
        </button>
      </div>

      <!-- Search & Filters -->
      <div class="cp-fb">
        <div class="cp-fs" style="position:relative; width: 100%; max-width: 450px;">
          <i class="fa-solid fa-magnifying-glass"></i>
          <input type="text" id="cp-search" placeholder="Search AWB, consignee, destination..."
            oninput="cpDebounceShipmentsSearch()" onkeydown="if(event.key==='Enter')cpLoadShipments(1);">
          <button type="button" id="cp-search-clear" onclick="cpClearShipmentsSearch()"
            style="display:none; position:absolute; right:12px; top:50%; transform:translateY(-50%); background:transparent; border:none; color:var(--cptext3); cursor:pointer; font-size:13px;"><i
              class="fa-solid fa-xmark"></i></button>
        </div>
      </div>
      <div id="cp-shipments-container"></div>
    </div>

    <!-- TAB 2: REQUESTS -->
    <div class="cp-main-content" id="tab-requests">
      <div class="cp-hdr-wrap">
        <h1 class="cp-page-title">Booking Requests <span class="cp-live-badge" id="cp-live-badge"><span
              class="cp-live-dot"></span>Live</span></h1>
        <p class="cp-page-sub">Track progress and status updates for your submitted booking requests.</p>
      </div>

      <!-- Filters & Search -->
      <div class="cp-fb" style="flex-wrap: wrap; gap: 12px; margin-bottom: 20px;">
        <div class="cp-fs" style="position:relative; min-width: 250px; flex: 1; max-width: 450px;">
          <i class="fa-solid fa-magnifying-glass"></i>
          <input type="text" id="cp-req-search" placeholder="Search AWB, consignee, city..."
            oninput="cpDebounceRequestsSearch()" onkeydown="if(event.key==='Enter')cpLoadRequests(1);">
          <button type="button" id="cp-req-search-clear" onclick="cpClearRequestsSearch()"
            style="display:none; position:absolute; right:12px; top:50%; transform:translateY(-50%); background:transparent; border:none; color:var(--cptext3); cursor:pointer; font-size:13px;"><i
              class="fa-solid fa-xmark"></i></button>
        </div>

        <!-- Status Tabs for Requests -->
        <div class="cp-status-tabs"
          style="display: flex; gap: 6px; background: rgba(0,0,0,0.03); padding: 4px; border-radius: 8px; border: 1px solid var(--cpbdr);">
          <button class="cp-status-tab active" onclick="cpSetRequestStatusFilter('', this)"
            style="border:none; background:transparent; padding:6px 12px; border-radius:6px; font-size:12px; font-weight:700; color:var(--cptext2); cursor:pointer;">All
            Active</button>
          <button class="cp-status-tab" onclick="cpSetRequestStatusFilter('pending', this)"
            style="border:none; background:transparent; padding:6px 12px; border-radius:6px; font-size:12px; font-weight:700; color:var(--cptext2); cursor:pointer;">Pending</button>
          <button class="cp-status-tab" onclick="cpSetRequestStatusFilter('processing', this)"
            style="border:none; background:transparent; padding:6px 12px; border-radius:6px; font-size:12px; font-weight:700; color:var(--cptext2); cursor:pointer;">Processing</button>
          <button class="cp-status-tab" onclick="cpSetRequestStatusFilter('rejected', this)"
            style="border:none; background:transparent; padding:6px 12px; border-radius:6px; font-size:12px; font-weight:700; color:var(--cptext2); cursor:pointer;">Rejected</button>
        </div>
      </div>
      <div id="cp-requests-container"></div>
    </div>

    <!-- TAB 3: MY PROFILE -->
    <div class="cp-main-content" id="tab-profile">
      <div class="cp-hdr-wrap">
        <h1 class="cp-page-title">Account Settings</h1>
        <p class="cp-page-sub">Keep your contact information up-to-date and manage password security.</p>
      </div>

      <!-- Account Overview Banner -->
      <div
        style="display:grid; grid-template-columns:repeat(auto-fit, minmax(200px, 1fr)); gap:12px; margin-bottom:20px;">
        <div
          style="background:var(--cpcard); border:1px solid var(--cpbdr); border-radius:12px; padding:14px 18px; display:flex; align-items:center; gap:12px; box-shadow:var(--cpsh);">
          <div
            style="width:40px; height:40px; border-radius:10px; background:rgba(59,130,246,0.1); color:var(--cpblue); display:flex; align-items:center; justify-content:center; font-size:18px;">
            <i class="fa-solid fa-id-badge"></i></div>
          <div>
            <div
              style="font-size:11px; font-weight:700; text-transform:uppercase; color:var(--cptext3); letter-spacing:0.5px;">
              Customer ID</div>
            <div style="font-size:16px; font-weight:800; color:var(--cptext);">
              <?php echo !empty($cust['customer_id']) ? 'CUST-' . str_pad(intval($cust['customer_id']), 4, '0', STR_PAD_LEFT) : '—'; ?>
            </div>
          </div>
        </div>
        <div
          style="background:var(--cpcard); border:1px solid var(--cpbdr); border-radius:12px; padding:14px 18px; display:flex; align-items:center; gap:12px; box-shadow:var(--cpsh);">
          <div
            style="width:40px; height:40px; border-radius:10px; background:rgba(16,185,129,0.1); color:var(--cpgreen); display:flex; align-items:center; justify-content:center; font-size:18px;">
            <i class="fa-solid fa-file-invoice-dollar"></i></div>
          <div>
            <div
              style="font-size:11px; font-weight:700; text-transform:uppercase; color:var(--cptext3); letter-spacing:0.5px;">
              Total Amount</div>
            <div id="cp-profile-total-amount" style="font-size:16px; font-weight:800; color:var(--cpgreen);">
              ₹<?php echo number_format($cust_total_amount, 2); ?></div>
          </div>
        </div>
      </div>

      <div class="cp-profile-grid">
        <!-- Personal Details -->
        <div class="cp-profile-card">
          <h3><i class="fa-solid fa-address-card"></i> Personal Details</h3>
          <form id="cp-profile-form">
            <div class="cp-form-group">
              <label>Full Name</label>
              <input type="text" id="profile-name" class="cp-form-input" value="<?php echo esc_attr($cust['name']); ?>"
                required>
            </div>
            <div class="cp-form-group">
              <label>Email Address</label>
              <input type="email" id="profile-email" class="cp-form-input"
                value="<?php echo esc_attr($cust['email']); ?>" required>
            </div>
            <div class="cp-form-group">
              <label>Phone Number</label>
              <input type="text" id="profile-phone" class="cp-form-input"
                value="<?php echo esc_attr($cust['phone']); ?>">
            </div>
            <div class="cp-form-group">
              <label>Company Name</label>
              <input type="text" id="profile-company" class="cp-form-input"
                value="<?php echo esc_attr($cust['company'] ?? ''); ?>">
            </div>
            <button type="submit" class="cp-form-submit" id="profile-submit">Save Changes</button>
          </form>
        </div>

        <!-- Security -->
        <div class="cp-profile-card">
          <h3><i class="fa-solid fa-shield-halved"></i> Change Password</h3>
          <form id="cp-password-form">
            <div class="cp-form-group">
              <label>Current Password</label>
              <input type="password" id="pass-current" class="cp-form-input" placeholder="Enter current password"
                required>
            </div>
            <div class="cp-form-group">
              <label>New Password</label>
              <input type="password" id="pass-new" class="cp-form-input" placeholder="Min. 6 characters" required>
            </div>
            <div class="cp-form-group">
              <label>Confirm New Password</label>
              <input type="password" id="pass-confirm" class="cp-form-input" placeholder="Confirm new password"
                required>
            </div>
            <button type="submit" class="cp-form-submit" id="password-submit">Update Password</button>
          </form>
        </div>
      </div>
    </div>

    <!-- TAB 4: NEW BOOKING -->
    <div class="cp-main-content" id="tab-new-booking">
      <div class="cp-hdr-wrap" style="margin-bottom:16px;">
        <h1 class="cp-page-title">Submit Booking Request</h1>
        <p class="cp-page-sub">Fill out the details below to submit a shipment booking request.</p>
      </div>
      <div
        style="background:var(--cpcard); border-radius:16px; border:1px solid var(--cpbdr); overflow:hidden; box-shadow:var(--cpsh);">
        <iframe id="pe-booking-iframe" src="<?php echo $iframe_booking_url; ?>"
          style="width:100%; height:calc(100vh - 180px); border:none;" title="Booking Request Form"></iframe>
      </div>
    </div>

    <!-- TAB 5: ADDRESS BOOK -->
    <div class="cp-main-content" id="tab-addresses">
      <div class="cp-hdr-wrap"
        style="display:flex; justify-content:space-between; align-items:flex-start; flex-wrap:wrap; gap:12px;">
        <div>
          <h1 class="cp-page-title">Address Book</h1>
          <p class="cp-page-sub">Save and manage your frequently used pickup and delivery addresses.</p>
        </div>
        <div style="display:flex; gap:8px; flex-wrap:wrap;">
          <button onclick="cpOpenAddressModal(null, 'sender')"
            style="border:none; cursor:pointer; padding:10px 18px; border-radius:10px; background:linear-gradient(135deg, #1e40af, #3b82f6); color:#fff; font-weight:700; font-size:13px; display:inline-flex; align-items:center; gap:8px; box-shadow:0 4px 12px rgba(59,130,246,.25); transition:all .2s;">
            <i class="fa-solid fa-arrow-up-from-bracket"></i> Add Sender
          </button>
          <button onclick="cpOpenAddressModal(null, 'receiver')"
            style="border:none; cursor:pointer; padding:10px 18px; border-radius:10px; background:linear-gradient(135deg, #047857, #10b981); color:#fff; font-weight:700; font-size:13px; display:inline-flex; align-items:center; gap:8px; box-shadow:0 4px 12px rgba(16,185,129,.25); transition:all .2s;">
            <i class="fa-solid fa-arrow-down-to-bracket"></i> Add Receiver
          </button>
        </div>
      </div>

      <!-- Address Filter Tabs -->
      <div style="margin-bottom:16px;">
        <div class="cp-addr-filters" style="display:inline-flex;">
          <button class="cp-addr-filter active" onclick="cpSetAddrFilter('all', this)"><i
              class="fa-solid fa-layer-group" style="font-size:11px;"></i> All</button>
          <button class="cp-addr-filter" onclick="cpSetAddrFilter('sender', this)"><i
              class="fa-solid fa-arrow-up-from-bracket" style="font-size:11px; color:#3b82f6;"></i> Sender</button>
          <button class="cp-addr-filter" onclick="cpSetAddrFilter('receiver', this)"><i
              class="fa-solid fa-arrow-down-to-bracket" style="font-size:11px; color:#10b981;"></i> Receiver</button>
          <button class="cp-addr-filter" onclick="cpSetAddrFilter('both', this)"><i
              class="fa-solid fa-arrows-left-right" style="font-size:11px; color:#f59e0b;"></i> Both</button>
        </div>
      </div>

      <div id="cp-addresses-container">
        <div style="padding:40px; text-align:center;">
          <div
            style="width:30px;height:30px;border:3px solid #e5e7eb;border-top-color:#bb0013;border-radius:50%;animation:cp-spin .6s linear infinite;margin:0 auto 16px">
          </div>
          <p style="color:#94a3b8;">Loading address book...</p>
        </div>
      </div>
    </div>

    <!-- TAB 6: MY DOCUMENTS / KYC -->
    <div class="cp-main-content" id="tab-documents">
      <div class="cp-hdr-wrap">
        <h1 class="cp-page-title">My Documents & KYC</h1>
        <p class="cp-page-sub">Upload, view, and store your identity documents, invoices, and shipping certificates.</p>
      </div>

      <!-- Quick Upload Card -->
      <div class="cp-profile-card"
        style="margin-bottom:24px; background:var(--cpcard); border-radius:16px; border:1px solid var(--cpbdr); padding:24px; box-shadow:var(--cpsh);">
        <h3
          style="font-size:15px; font-weight:800; color:var(--cptext); margin:0 0 16px; display:flex; align-items:center; gap:8px;">
          <i class="fa-solid fa-cloud-arrow-up" style="color:var(--cpred);"></i> Upload New Document
        </h3>
        <form id="cp-doc-upload-form" enctype="multipart/form-data" onsubmit="cpHandleDocUpload(event)">
          <div
            style="display:grid; grid-template-columns:repeat(auto-fit, minmax(220px, 1fr)); gap:16px; margin-bottom:16px;">
            <div class="cp-form-group">
              <label
                style="font-size:11px; font-weight:700; color:var(--cptext2); text-transform:uppercase; display:block; margin-bottom:6px;">Document
                Type *</label>
              <select id="doc-upload-type" class="cp-form-input" required
                style="width:100%; padding:10px 12px; border-radius:10px; border:1px solid var(--cpbdr); font-size:13px;">
                <option value="Aadhaar Card">Aadhaar Card</option>
                <option value="PAN Card">PAN Card</option>
                <option value="Passport">Passport</option>
                <option value="GST Certificate">GST Certificate</option>
                <option value="IEC Certificate">IEC Certificate</option>
                <option value="Commercial Invoice">Commercial Invoice</option>
                <option value="Packing List">Packing List</option>
                <option value="Other">Other Document</option>
              </select>
            </div>
            <div class="cp-form-group">
              <label
                style="font-size:11px; font-weight:700; color:var(--cptext2); text-transform:uppercase; display:block; margin-bottom:6px;">Document
                Name (Optional)</label>
              <input type="text" id="doc-upload-name" class="cp-form-input" placeholder="e.g. Director Aadhaar Card"
                style="width:100%; padding:10px 12px; border-radius:10px; border:1px solid var(--cpbdr); font-size:13px;">
            </div>
            <div class="cp-form-group">
              <label
                style="font-size:11px; font-weight:700; color:var(--cptext2); text-transform:uppercase; display:block; margin-bottom:6px;">Document
                Number (Optional)</label>
              <input type="text" id="doc-upload-number" class="cp-form-input" placeholder="e.g. 12-digit Aadhaar / PAN"
                style="width:100%; padding:10px 12px; border-radius:10px; border:1px solid var(--cpbdr); font-size:13px;">
            </div>
          </div>
          <div style="display:flex; align-items:center; gap:16px; flex-wrap:wrap;">
            <input type="file" id="doc-upload-file" accept=".pdf,.jpg,.jpeg,.png,.webp,.doc,.docx" required
              style="font-size:13px;">
            <button type="submit" id="doc-upload-btn" class="cp-form-submit"
              style="padding:10px 20px; border-radius:10px; background:var(--cpred); color:#fff; font-weight:700; font-size:13px; border:none; cursor:pointer;">
              <i class="fa-solid fa-arrow-up-from-bracket"></i> Upload & Save Document
            </button>
          </div>
        </form>
      </div>

      <div id="cp-documents-container">
        <div style="padding:40px; text-align:center;">
          <div
            style="width:30px;height:30px;border:3px solid #e5e7eb;border-top-color:#bb0013;border-radius:50%;animation:cp-spin .6s linear infinite;margin:0 auto 16px">
          </div>
          <p style="color:#94a3b8;">Loading documents...</p>
        </div>
      </div>
    </div>

  </main>
</div>

<!-- ADDRESS MODAL -->
<div class="cp-do" id="cp-addr-modal-overlay" onclick="if(event.target===this)cpCloseAddressModal()">
  <div class="cp-dp"
    style="max-width:620px; padding:0; border-radius:24px; background:#fff; margin:auto; box-shadow:0 25px 50px -12px rgba(0,0,0,0.25); overflow:hidden; border:1px solid var(--cpbdr); max-height:92vh; display:flex; flex-direction:column;">
    
    <!-- Top Gradient Accent -->
    <div style="height:5px; background:linear-gradient(90deg, #bb0013, #ef4444, #f97316); width:100%;"></div>

    <!-- Modal Header -->
    <div style="padding:22px 28px 18px; border-bottom:1px solid var(--cpbdr); display:flex; justify-content:space-between; align-items:center; background:linear-gradient(180deg, #ffffff 0%, #f8fafc 100%);">
      <div style="display:flex; align-items:center; gap:12px;">
        <div style="width:40px; height:40px; border-radius:12px; background:rgba(187,0,19,0.08); border:1px solid rgba(187,0,19,0.15); display:flex; align-items:center; justify-content:center; color:var(--cpred); font-size:17px;">
          <i class="fa-solid fa-address-book"></i>
        </div>
        <div>
          <h3 style="font-size:17px; font-weight:900; color:var(--cptext); margin:0; letter-spacing:-0.2px;" id="cp-addr-modal-title">
            Add New Address
          </h3>
          <p style="font-size:11.5px; color:var(--cptext2); margin:2px 0 0;">
            Manage pickup and delivery contacts for fast, error-free courier bookings.
          </p>
        </div>
      </div>
      <button onclick="cpCloseAddressModal()"
        style="width:34px; height:34px; border-radius:10px; border:none; background:rgba(0,0,0,0.04); font-size:15px; color:var(--cptext3); cursor:pointer; display:flex; align-items:center; justify-content:center; transition:all .15s;"
        onmouseenter="this.style.background='rgba(0,0,0,0.08)';this.style.color='var(--cptext)'"
        onmouseleave="this.style.background='rgba(0,0,0,0.04)';this.style.color='var(--cptext3)'"
        title="Close">
        <i class="fa-solid fa-xmark"></i>
      </button>
    </div>

    <!-- Modal Form Body (Scrollable) -->
    <form id="cp-address-form" onsubmit="cpHandleAddressSubmit(event)" style="padding:24px 28px; overflow-y:auto; flex:1; display:flex; flex-direction:column; gap:20px;">
      <input type="hidden" id="addr-id" value="">

      <!-- Section 1: Contact Information -->
      <div style="background:#f8fafc; border:1px solid #e2e8f0; border-radius:16px; padding:16px 18px;">
        <div style="display:flex; align-items:center; gap:8px; margin-bottom:14px; padding-bottom:8px; border-bottom:1px solid #e2e8f0;">
          <i class="fa-solid fa-user-check" style="font-size:12px; color:var(--cpred);"></i>
          <span style="font-size:11.5px; font-weight:800; color:var(--cptext); text-transform:uppercase; letter-spacing:0.5px;">1. Contact Details</span>
        </div>

        <div style="display:grid; grid-template-columns:1fr 1fr; gap:12px; margin-bottom:12px;">
          <div class="cp-form-group">
            <label style="display:block; font-size:11px; font-weight:700; color:var(--cptext2); text-transform:uppercase; margin-bottom:5px;">Address Type *</label>
            <select id="addr-type" class="cp-form-input" style="width:100%; padding:9px 12px; border-radius:10px; border:1px solid var(--cpbdr); background:#fff; font-size:13px; font-weight:600; color:var(--cptext);">
              <option value="both">Both (Sender & Receiver)</option>
              <option value="sender">Sender (Pickup Address)</option>
              <option value="receiver">Receiver (Delivery Address)</option>
            </select>
          </div>
          <div class="cp-form-group">
            <label style="display:block; font-size:11px; font-weight:700; color:var(--cptext2); text-transform:uppercase; margin-bottom:5px;">Contact Person / Name *</label>
            <input type="text" id="addr-name" class="cp-form-input" required placeholder="Full Name" style="width:100%; padding:9px 12px; border-radius:10px; border:1px solid var(--cpbdr); background:#fff; font-size:13px; font-weight:600; color:var(--cptext);">
          </div>
        </div>

        <div style="display:grid; grid-template-columns:1fr 1fr; gap:12px; margin-bottom:12px;">
          <div class="cp-form-group">
            <label style="display:block; font-size:11px; font-weight:700; color:var(--cptext2); text-transform:uppercase; margin-bottom:5px;">Company Name</label>
            <input type="text" id="addr-company" class="cp-form-input" placeholder="Company Name" style="width:100%; padding:9px 12px; border-radius:10px; border:1px solid var(--cpbdr); background:#fff; font-size:13px; font-weight:600; color:var(--cptext); text-transform:uppercase;">
          </div>
          <div class="cp-form-group">
            <label style="display:block; font-size:11px; font-weight:700; color:var(--cptext2); text-transform:uppercase; margin-bottom:5px;">Phone Number *</label>
            <input type="tel" id="addr-phone" class="cp-form-input" required placeholder="+91 99999 99999" style="width:100%; padding:9px 12px; border-radius:10px; border:1px solid var(--cpbdr); background:#fff; font-size:13px; font-family:monospace; font-weight:700; color:var(--cptext);">
          </div>
        </div>

        <div style="display:grid; grid-template-columns:1fr 1fr; gap:12px;">
          <div class="cp-form-group">
            <label style="display:block; font-size:11px; font-weight:700; color:var(--cptext2); text-transform:uppercase; margin-bottom:5px;">Alternate Phone</label>
            <input type="tel" id="addr-phone2" class="cp-form-input" placeholder="Secondary Phone" style="width:100%; padding:9px 12px; border-radius:10px; border:1px solid var(--cpbdr); background:#fff; font-size:13px; font-family:monospace; color:var(--cptext);">
          </div>
          <div class="cp-form-group">
            <label style="display:block; font-size:11px; font-weight:700; color:var(--cptext2); text-transform:uppercase; margin-bottom:5px;">Email Address</label>
            <input type="email" id="addr-email" class="cp-form-input" placeholder="email@example.com" style="width:100%; padding:9px 12px; border-radius:10px; border:1px solid var(--cpbdr); background:#fff; font-size:13px; color:var(--cptext);">
          </div>
        </div>
      </div>

      <!-- Section 2: Address Information -->
      <div style="background:#f8fafc; border:1px solid #e2e8f0; border-radius:16px; padding:16px 18px;">
        <div style="display:flex; align-items:center; gap:8px; margin-bottom:14px; padding-bottom:8px; border-bottom:1px solid #e2e8f0;">
          <i class="fa-solid fa-location-dot" style="font-size:12px; color:var(--cpred);"></i>
          <span style="font-size:11.5px; font-weight:800; color:var(--cptext); text-transform:uppercase; letter-spacing:0.5px;">2. Address Location</span>
        </div>

        <div class="cp-form-group" style="margin-bottom:12px;">
          <label style="display:block; font-size:11px; font-weight:700; color:var(--cptext2); text-transform:uppercase; margin-bottom:5px;">Address Line 1 *</label>
          <input type="text" id="addr-line1" class="cp-form-input" required placeholder="Flat / Building / Street address" style="width:100%; padding:9px 12px; border-radius:10px; border:1px solid var(--cpbdr); background:#fff; font-size:13px; color:var(--cptext);">
        </div>

        <div class="cp-form-group" style="margin-bottom:12px;">
          <label style="display:block; font-size:11px; font-weight:700; color:var(--cptext2); text-transform:uppercase; margin-bottom:5px;">Address Line 2</label>
          <input type="text" id="addr-line2" class="cp-form-input" placeholder="Area / Landmark / Suite" style="width:100%; padding:9px 12px; border-radius:10px; border:1px solid var(--cpbdr); background:#fff; font-size:13px; color:var(--cptext);">
        </div>

        <div style="display:grid; grid-template-columns:1fr 1fr 1fr; gap:12px; margin-bottom:12px;">
          <div class="cp-form-group">
            <label style="display:block; font-size:11px; font-weight:700; color:var(--cptext2); text-transform:uppercase; margin-bottom:5px;">City *</label>
            <input type="text" id="addr-city" class="cp-form-input" required placeholder="City" style="width:100%; padding:9px 12px; border-radius:10px; border:1px solid var(--cpbdr); background:#fff; font-size:13px; font-weight:600; color:var(--cptext);">
          </div>
          <div class="cp-form-group">
            <label style="display:block; font-size:11px; font-weight:700; color:var(--cptext2); text-transform:uppercase; margin-bottom:5px;">State</label>
            <input type="text" id="addr-state" class="cp-form-input" placeholder="State" style="width:100%; padding:9px 12px; border-radius:10px; border:1px solid var(--cpbdr); background:#fff; font-size:13px; text-transform:uppercase; font-weight:600; color:var(--cptext);">
          </div>
          <div class="cp-form-group">
            <label style="display:block; font-size:11px; font-weight:700; color:var(--cptext2); text-transform:uppercase; margin-bottom:5px;">Pincode / Postal *</label>
            <input type="text" id="addr-pincode" class="cp-form-input" required placeholder="Pincode" style="width:100%; padding:9px 12px; border-radius:10px; border:1px solid var(--cpbdr); background:#fff; font-size:13px; font-family:monospace; font-weight:700; color:var(--cptext);">
          </div>
        </div>

        <div class="cp-form-group">
          <label style="display:block; font-size:11px; font-weight:700; color:var(--cptext2); text-transform:uppercase; margin-bottom:5px;">Country *</label>
          <input type="text" id="addr-country" list="cp-all-countries-list" class="cp-form-input" value="INDIA" placeholder="Search or enter country name (e.g. INDIA, UNITED STATES, UNITED ARAB EMIRATES)..." oninput="this.value=this.value.replace(/[-–—]/g,'').toUpperCase()" style="width:100%; padding:9px 12px; border-radius:10px; border:1px solid var(--cpbdr); background:#fff; font-size:13px; font-weight:800; color:var(--cpred); text-transform:uppercase;">
          <datalist id="cp-all-countries-list">
            <option value="AFGHANISTAN">AF - AFGHANISTAN</option>
            <option value="ALAND ISLANDS">AX - ALAND ISLANDS</option>
            <option value="ALBANIA">AL - ALBANIA</option>
            <option value="ALGERIA">DZ - ALGERIA</option>
            <option value="AMERICAN SAMOA">AS - AMERICAN SAMOA</option>
            <option value="ANDORRA">AD - ANDORRA</option>
            <option value="ANGOLA">AO - ANGOLA</option>
            <option value="ANGUILLA">AI - ANGUILLA</option>
            <option value="ANTARCTICA">AQ - ANTARCTICA</option>
            <option value="ANTIGUA AND BARBUDA">AG - ANTIGUA AND BARBUDA</option>
            <option value="ARGENTINA">AR - ARGENTINA</option>
            <option value="ARMENIA">AM - ARMENIA</option>
            <option value="ARUBA">AW - ARUBA</option>
            <option value="AUSTRALIA">AU - AUSTRALIA</option>
            <option value="AUSTRIA">AT - AUSTRIA</option>
            <option value="AZERBAIJAN">AZ - AZERBAIJAN</option>
            <option value="BAHAMAS">BS - BAHAMAS</option>
            <option value="BAHRAIN">BH - BAHRAIN</option>
            <option value="BANGLADESH">BD - BANGLADESH</option>
            <option value="BARBADOS">BB - BARBADOS</option>
            <option value="BELARUS">BY - BELARUS</option>
            <option value="BELGIUM">BE - BELGIUM</option>
            <option value="BELIZE">BZ - BELIZE</option>
            <option value="BENIN">BJ - BENIN</option>
            <option value="BERMUDA">BM - BERMUDA</option>
            <option value="BHUTAN">BT - BHUTAN</option>
            <option value="BOLIVIA">BO - BOLIVIA</option>
            <option value="BOSNIA AND HERZEGOVINA">BA - BOSNIA AND HERZEGOVINA</option>
            <option value="BOTSWANA">BW - BOTSWANA</option>
            <option value="BOUVET ISLAND">BV - BOUVET ISLAND</option>
            <option value="BRAZIL">BR - BRAZIL</option>
            <option value="BRITISH INDIAN OCEAN TERRITORY">IO - BRITISH INDIAN OCEAN TERRITORY</option>
            <option value="BRUNEI">BN - BRUNEI</option>
            <option value="BULGARIA">BG - BULGARIA</option>
            <option value="BURKINA FASO">BF - BURKINA FASO</option>
            <option value="BURUNDI">BI - BURUNDI</option>
            <option value="CAMBODIA">KH - CAMBODIA</option>
            <option value="CAMEROON">CM - CAMEROON</option>
            <option value="CANADA">CA - CANADA</option>
            <option value="CAPE VERDE">CV - CAPE VERDE</option>
            <option value="CAYMAN ISLANDS">KY - CAYMAN ISLANDS</option>
            <option value="CENTRAL AFRICAN REPUBLIC">CF - CENTRAL AFRICAN REPUBLIC</option>
            <option value="CHAD">TD - CHAD</option>
            <option value="CHILE">CL - CHILE</option>
            <option value="CHINA">CN - CHINA</option>
            <option value="CHRISTMAS ISLAND">CX - CHRISTMAS ISLAND</option>
            <option value="COCOS (KEELING) ISLANDS">CC - COCOS (KEELING) ISLANDS</option>
            <option value="COLOMBIA">CO - COLOMBIA</option>
            <option value="COMOROS">KM - COMOROS</option>
            <option value="CONGO">CG - CONGO</option>
            <option value="CONGO (DRC)">CD - CONGO (DRC)</option>
            <option value="COOK ISLANDS">CK - COOK ISLANDS</option>
            <option value="COSTA RICA">CR - COSTA RICA</option>
            <option value="IVORY COAST">CI - IVORY COAST</option>
            <option value="CROATIA">HR - CROATIA</option>
            <option value="CUBA">CU - CUBA</option>
            <option value="CURACAO">CW - CURACAO</option>
            <option value="CYPRUS">CY - CYPRUS</option>
            <option value="CZECH REPUBLIC">CZ - CZECH REPUBLIC</option>
            <option value="DENMARK">DK - DENMARK</option>
            <option value="DJIBOUTI">DJ - DJIBOUTI</option>
            <option value="DOMINICA">DM - DOMINICA</option>
            <option value="DOMINICAN REPUBLIC">DO - DOMINICAN REPUBLIC</option>
            <option value="ECUADOR">EC - ECUADOR</option>
            <option value="EGYPT">EG - EGYPT</option>
            <option value="EL SALVADOR">SV - EL SALVADOR</option>
            <option value="EQUATORIAL GUINEA">GQ - EQUATORIAL GUINEA</option>
            <option value="ERITREA">ER - ERITREA</option>
            <option value="ESTONIA">EE - ESTONIA</option>
            <option value="ESWATINI">SZ - ESWATINI</option>
            <option value="ETHIOPIA">ET - ETHIOPIA</option>
            <option value="FALKLAND ISLANDS">FK - FALKLAND ISLANDS</option>
            <option value="FAROE ISLANDS">FO - FAROE ISLANDS</option>
            <option value="FIJI">FJ - FIJI</option>
            <option value="FINLAND">FI - FINLAND</option>
            <option value="FRANCE">FR - FRANCE</option>
            <option value="FRENCH GUIANA">GF - FRENCH GUIANA</option>
            <option value="FRENCH POLYNESIA">PF - FRENCH POLYNESIA</option>
            <option value="FRENCH SOUTHERN TERRITORIES">TF - FRENCH SOUTHERN TERRITORIES</option>
            <option value="GABON">GA - GABON</option>
            <option value="GAMBIA">GM - GAMBIA</option>
            <option value="GEORGIA">GE - GEORGIA</option>
            <option value="GERMANY">DE - GERMANY</option>
            <option value="GHANA">GH - GHANA</option>
            <option value="GIBRALTAR">GI - GIBRALTAR</option>
            <option value="GREECE">GR - GREECE</option>
            <option value="GREENLAND">GL - GREENLAND</option>
            <option value="GRENADA">GD - GRENADA</option>
            <option value="GUADELOUPE">GP - GUADELOUPE</option>
            <option value="GUAM">GU - GUAM</option>
            <option value="GUATEMALA">GT - GUATEMALA</option>
            <option value="GUERNSEY">GG - GUERNSEY</option>
            <option value="GUINEA">GN - GUINEA</option>
            <option value="GUINEA-BISSAU">GW - GUINEA-BISSAU</option>
            <option value="GUYANA">GY - GUYANA</option>
            <option value="HAITI">HT - HAITI</option>
            <option value="HEARD ISLAND AND MCDONALD ISLANDS">HM - HEARD ISLAND AND MCDONALD ISLANDS</option>
            <option value="VATICAN CITY">VA - VATICAN CITY</option>
            <option value="HONDURAS">HN - HONDURAS</option>
            <option value="HONG KONG">HK - HONG KONG</option>
            <option value="HUNGARY">HU - HUNGARY</option>
            <option value="ICELAND">IS - ICELAND</option>
            <option value="INDIA">IN - INDIA</option>
            <option value="INDONESIA">ID - INDONESIA</option>
            <option value="IRAN">IR - IRAN</option>
            <option value="IRAQ">IQ - IRAQ</option>
            <option value="IRELAND">IE - IRELAND</option>
            <option value="ISLE OF MAN">IM - ISLE OF MAN</option>
            <option value="ISRAEL">IL - ISRAEL</option>
            <option value="ITALY">IT - ITALY</option>
            <option value="JAMAICA">JM - JAMAICA</option>
            <option value="JAPAN">JP - JAPAN</option>
            <option value="JERSEY">JE - JERSEY</option>
            <option value="JORDAN">JO - JORDAN</option>
            <option value="KAZAKHSTAN">KZ - KAZAKHSTAN</option>
            <option value="KENYA">KE - KENYA</option>
            <option value="KIRIBATI">KI - KIRIBATI</option>
            <option value="NORTH KOREA">KP - NORTH KOREA</option>
            <option value="SOUTH KOREA">KR - SOUTH KOREA</option>
            <option value="KUWAIT">KW - KUWAIT</option>
            <option value="KYRGYZSTAN">KG - KYRGYZSTAN</option>
            <option value="LAOS">LA - LAOS</option>
            <option value="LATVIA">LV - LATVIA</option>
            <option value="LEBANON">LB - LEBANON</option>
            <option value="LESOTHO">LS - LESOTHO</option>
            <option value="LIBERIA">LR - LIBERIA</option>
            <option value="LIBYA">LY - LIBYA</option>
            <option value="LIECHTENSTEIN">LI - LIECHTENSTEIN</option>
            <option value="LITHUANIA">LT - LITHUANIA</option>
            <option value="LUXEMBOURG">LU - LUXEMBOURG</option>
            <option value="MACAU">MO - MACAU</option>
            <option value="MADAGASCAR">MG - MADAGASCAR</option>
            <option value="MALAWI">MW - MALAWI</option>
            <option value="MALAYSIA">MY - MALAYSIA</option>
            <option value="MALDIVES">MV - MALDIVES</option>
            <option value="MALI">ML - MALI</option>
            <option value="MALTA">MT - MALTA</option>
            <option value="MARSHALL ISLANDS">MH - MARSHALL ISLANDS</option>
            <option value="MARTINIQUE">MQ - MARTINIQUE</option>
            <option value="MAURITANIA">MR - MAURITANIA</option>
            <option value="MAURITIUS">MU - MAURITIUS</option>
            <option value="MAYOTTE">YT - MAYOTTE</option>
            <option value="MEXICO">MX - MEXICO</option>
            <option value="MICRONESIA">FM - MICRONESIA</option>
            <option value="MOLDOVA">MD - MOLDOVA</option>
            <option value="MONACO">MC - MONACO</option>
            <option value="MONGOLIA">MN - MONGOLIA</option>
            <option value="MONTENEGRO">ME - MONTENEGRO</option>
            <option value="MONTSERRAT">MS - MONTSERRAT</option>
            <option value="MOROCCO">MA - MOROCCO</option>
            <option value="MOZAMBIQUE">MZ - MOZAMBIQUE</option>
            <option value="MYANMAR">MM - MYANMAR</option>
            <option value="NAMIBIA">NA - NAMIBIA</option>
            <option value="NAURU">NR - NAURU</option>
            <option value="NEPAL">NP - NEPAL</option>
            <option value="NETHERLANDS">NL - NETHERLANDS</option>
            <option value="NEW CALEDONIA">NC - NEW CALEDONIA</option>
            <option value="NEW ZEALAND">NZ - NEW ZEALAND</option>
            <option value="NICARAGUA">NI - NICARAGUA</option>
            <option value="NIGER">NE - NIGER</option>
            <option value="NIGERIA">NG - NIGERIA</option>
            <option value="NIUE">NU - NIUE</option>
            <option value="NORFOLK ISLAND">NF - NORFOLK ISLAND</option>
            <option value="NORTH MACEDONIA">MK - NORTH MACEDONIA</option>
            <option value="NORTHERN MARIANA ISLANDS">MP - NORTHERN MARIANA ISLANDS</option>
            <option value="NORWAY">NO - NORWAY</option>
            <option value="OMAN">OM - OMAN</option>
            <option value="PAKISTAN">PK - PAKISTAN</option>
            <option value="PALAU">PW - PALAU</option>
            <option value="PALESTINE">PS - PALESTINE</option>
            <option value="PANAMA">PA - PANAMA</option>
            <option value="PAPUA NEW GUINEA">PG - PAPUA NEW GUINEA</option>
            <option value="PARAGUAY">PY - PARAGUAY</option>
            <option value="PERU">PE - PERU</option>
            <option value="PHILIPPINES">PH - PHILIPPINES</option>
            <option value="PITCAIRN">PN - PITCAIRN</option>
            <option value="POLAND">PL - POLAND</option>
            <option value="PORTUGAL">PT - PORTUGAL</option>
            <option value="PUERTO RICO">PR - PUERTO RICO</option>
            <option value="QATAR">QA - QATAR</option>
            <option value="REUNION">RE - REUNION</option>
            <option value="ROMANIA">RO - ROMANIA</option>
            <option value="RUSSIA">RU - RUSSIA</option>
            <option value="RWANDA">RW - RWANDA</option>
            <option value="SAINT BARTHELEMY">BL - SAINT BARTHELEMY</option>
            <option value="SAINT HELENA">SH - SAINT HELENA</option>
            <option value="SAINT KITTS AND NEVIS">KN - SAINT KITTS AND NEVIS</option>
            <option value="SAINT LUCIA">LC - SAINT LUCIA</option>
            <option value="SAINT MARTIN">MF - SAINT MARTIN</option>
            <option value="SAINT PIERRE AND MIQUELON">PM - SAINT PIERRE AND MIQUELON</option>
            <option value="SAINT VINCENT AND THE GRENADINES">VC - SAINT VINCENT AND THE GRENADINES</option>
            <option value="SAMOA">WS - SAMOA</option>
            <option value="SAN MARINO">SM - SAN MARINO</option>
            <option value="SAO TOME AND PRINCIPE">ST - SAO TOME AND PRINCIPE</option>
            <option value="SAUDI ARABIA">SA - SAUDI ARABIA</option>
            <option value="SENEGAL">SN - SENEGAL</option>
            <option value="SERBIA">RS - SERBIA</option>
            <option value="SEYCHELLES">SC - SEYCHELLES</option>
            <option value="SIERRA LEONE">SL - SIERRA LEONE</option>
            <option value="SINGAPORE">SG - SINGAPORE</option>
            <option value="SINT MAARTEN">SX - SINT MAARTEN</option>
            <option value="SLOVAKIA">SK - SLOVAKIA</option>
            <option value="SLOVENIA">SI - SLOVENIA</option>
            <option value="SOLOMON ISLANDS">SB - SOLOMON ISLANDS</option>
            <option value="SOMALIA">SO - SOMALIA</option>
            <option value="SOUTH AFRICA">ZA - SOUTH AFRICA</option>
            <option value="SOUTH GEORGIA">GS - SOUTH GEORGIA</option>
            <option value="SOUTH SUDAN">SS - SOUTH SUDAN</option>
            <option value="SPAIN">ES - SPAAIN</option>
            <option value="SRI LANKA">LK - SRI LANKA</option>
            <option value="SUDAN">SD - SUDAN</option>
            <option value="SURINAME">SR - SURINAME</option>
            <option value="SVALBARD AND JAN MAYEN">SJ - SVALBARD AND JAN MAYEN</option>
            <option value="SWEDEN">SE - SWEDEN</option>
            <option value="SWITZERLAND">CH - SWITZERLAND</option>
            <option value="SYRIA">SY - SYRIA</option>
            <option value="TAIWAN">TW - TAIWAN</option>
            <option value="TAJIKISTAN">TJ - TAJIKISTAN</option>
            <option value="TANZANIA">TZ - TANZANIA</option>
            <option value="THAILAND">TH - THAILAND</option>
            <option value="TIMOR-LESTE">TL - TIMOR-LESTE</option>
            <option value="TOGO">TG - TOGO</option>
            <option value="TOKELAU">TK - TOKELAU</option>
            <option value="TONGA">TO - TONGA</option>
            <option value="TRINIDAD AND TOBAGO">TT - TRINIDAD AND TOBAGO</option>
            <option value="TUNISIA">TN - TUNISIA</option>
            <option value="TURKEY">TR - TURKEY</option>
            <option value="TURKMENISTAN">TM - TURKMENISTAN</option>
            <option value="TURKS AND CAICOS ISLANDS">TC - TURKS AND CAICOS ISLANDS</option>
            <option value="TUVALU">TV - TUVALU</option>
            <option value="UGANDA">UG - UGANDA</option>
            <option value="UKRAINE">UA - UKRAINE</option>
            <option value="UNITED ARAB EMIRATES">AE - UNITED ARAB EMIRATES</option>
            <option value="UNITED KINGDOM">GB - UNITED KINGDOM</option>
            <option value="UNITED STATES">US - UNITED STATES</option>
            <option value="UNITED STATES MINOR OUTLYING ISLANDS">UM - UNITED STATES MINOR OUTLYING ISLANDS</option>
            <option value="URUGUAY">UY - URUGUAY</option>
            <option value="UZBEKISTAN">UZ - UZBEKISTAN</option>
            <option value="VANUATU">VU - VANUATU</option>
            <option value="VENEZUELA">VE - VENEZUELA</option>
            <option value="VIETNAM">VN - VIETNAM</option>
            <option value="VIRGIN ISLANDS (BRITISH)">VG - VIRGIN ISLANDS (BRITISH)</option>
            <option value="VIRGIN ISLANDS (U.S.)">VI - VIRGIN ISLANDS (U.S.)</option>
            <option value="WALLIS AND FUTUNA">WF - WALLIS AND FUTUNA</option>
            <option value="WESTERN SAHARA">EH - WESTERN SAHARA</option>
            <option value="YEMEN">YE - YEMEN</option>
            <option value="ZAMBIA">ZM - ZAMBIA</option>
            <option value="ZIMBABWE">ZW - ZIMBABWE</option>
            <option value="KOSOVO">XK - KOSOVO</option>
          </datalist>
        </div>
      </div>

      <!-- Section 3: Tax & Identification -->
      <div style="background:#f8fafc; border:1px solid #e2e8f0; border-radius:16px; padding:16px 18px;">
        <div style="display:flex; align-items:center; gap:8px; margin-bottom:14px; padding-bottom:8px; border-bottom:1px solid #e2e8f0;">
          <i class="fa-solid fa-file-invoice" style="font-size:12px; color:var(--cpred);"></i>
          <span style="font-size:11.5px; font-weight:800; color:var(--cptext); text-transform:uppercase; letter-spacing:0.5px;">3. Tax & Identification</span>
        </div>

        <div class="cp-form-group">
          <label style="display:block; font-size:11px; font-weight:700; color:var(--cptext2); text-transform:uppercase; margin-bottom:5px;">GST / Tax ID / Passport / Aadhaar Number</label>
          <input type="text" id="addr-gstin" class="cp-form-input" placeholder="e.g. GSTIN, PAN, EIN, Tax ID" style="width:100%; padding:9px 12px; border-radius:10px; border:1px solid var(--cpbdr); background:#fff; font-size:13px; font-family:monospace; font-weight:600; color:var(--cptext);">
        </div>
      </div>

      <!-- Footer Buttons -->
      <div style="display:flex; justify-content:flex-end; align-items:center; gap:12px; padding-top:10px; border-top:1px solid var(--cpbdr);">
        <button type="button" onclick="cpCloseAddressModal()"
          style="padding:10px 20px; border-radius:12px; border:1px solid var(--cpbdr); background:#fff; font-size:13px; font-weight:700; color:var(--cptext2); cursor:pointer; transition:all .15s;"
          onmouseenter="this.style.background='#f1f5f9'"
          onmouseleave="this.style.background='#fff'">
          Cancel
        </button>
        <button type="submit" id="addr-submit-btn"
          style="padding:10px 24px; border-radius:12px; border:none; background:linear-gradient(135deg, #bb0013, #dc2626); color:#fff; font-size:13px; font-weight:800; cursor:pointer; box-shadow:0 4px 12px rgba(187,0,19,0.25); transition:all .15s;"
          onmouseenter="this.style.transform='translateY(-1px)';this.style.boxShadow='0 6px 16px rgba(187,0,19,0.35)'"
          onmouseleave="this.style.transform='none';this.style.boxShadow='0 4px 12px rgba(187,0,19,0.25)'">
          Save Address
        </button>
      </div>
    </form>
  </div>
</div>

<!-- DETAIL PANEL -->
<div class="cp-do" id="cp-detail-overlay" onclick="if(event.target===this)cpCloseDetail()">
  <div class="cp-dp" id="cp-detail-panel"></div>
</div>

<!-- TOAST CONTAINER -->
<div class="cp-toast-container" id="cp-toast-container"></div>

<script>
  var cpPage = 1, cpSearch = '', cpShipSearchTimer = null;
  var cpReqPage = 1, cpReqSearch = '', cpReqStatus = '', cpReqSearchTimer = null;

  // Universal ISO Country Dictionary
  // Universal ISO Country Dictionary (all 249 ISO 3166-1 alpha-2 countries + 3-letter codes + aliases)
  var cpCountryDictionary = {
    'AF': 'AFGHANISTAN', 'AX': 'ALAND ISLANDS', 'AL': 'ALBANIA', 'DZ': 'ALGERIA', 'AS': 'AMERICAN SAMOA', 'AD': 'ANDORRA',
    'AO': 'ANGOLA', 'AI': 'ANGUILLA', 'AQ': 'ANTARCTICA', 'AG': 'ANTIGUA AND BARBUDA', 'AR': 'ARGENTINA', 'AM': 'ARMENIA',
    'AW': 'ARUBA', 'AU': 'AUSTRALIA', 'AT': 'AUSTRIA', 'AZ': 'AZERBAIJAN', 'BS': 'BAHAMAS', 'BH': 'BAHRAIN',
    'BD': 'BANGLADESH', 'BB': 'BARBADOS', 'BY': 'BELARUS', 'BE': 'BELGIUM', 'BZ': 'BELIZE', 'BJ': 'BENIN',
    'BM': 'BERMUDA', 'BT': 'BHUTAN', 'BO': 'BOLIVIA', 'BA': 'BOSNIA AND HERZEGOVINA', 'BW': 'BOTSWANA', 'BV': 'BOUVET ISLAND',
    'BR': 'BRAZIL', 'IO': 'BRITISH INDIAN OCEAN TERRITORY', 'BN': 'BRUNEI', 'BG': 'BULGARIA', 'BF': 'BURKINA FASO', 'BI': 'BURUNDI',
    'KH': 'CAMBODIA', 'CM': 'CAMEROON', 'CA': 'CANADA', 'CV': 'CAPE VERDE', 'KY': 'CAYMAN ISLANDS', 'CF': 'CENTRAL AFRICAN REPUBLIC',
    'TD': 'CHAD', 'CL': 'CHILE', 'CN': 'CHINA', 'CX': 'CHRISTMAS ISLAND', 'CC': 'COCOS (KEELING) ISLANDS', 'CO': 'COLOMBIA',
    'KM': 'COMOROS', 'CG': 'CONGO', 'CD': 'CONGO (DRC)', 'CK': 'COOK ISLANDS', 'CR': 'COSTA RICA', 'CI': 'IVORY COAST',
    'HR': 'CROATIA', 'CU': 'CUBA', 'CW': 'CURACAO', 'CY': 'CYPRUS', 'CZ': 'CZECH REPUBLIC', 'DK': 'DENMARK',
    'DJ': 'DJIBOUTI', 'DM': 'DOMINICA', 'DO': 'DOMINICAN REPUBLIC', 'EC': 'ECUADOR', 'EG': 'EGYPT', 'SV': 'EL SALVADOR',
    'GQ': 'EQUATORIAL GUINEA', 'ER': 'ERITREA', 'EE': 'ESTONIA', 'SZ': 'ESWATINI', 'ET': 'ETHIOPIA', 'FK': 'FALKLAND ISLANDS',
    'FO': 'FAROE ISLANDS', 'FJ': 'FIJI', 'FI': 'FINLAND', 'FR': 'FRANCE', 'GF': 'FRENCH GUIANA', 'PF': 'FRENCH POLYNESIA',
    'TF': 'FRENCH SOUTHERN TERRITORIES', 'GA': 'GABON', 'GM': 'GAMBIA', 'GE': 'GEORGIA', 'DE': 'GERMANY', 'GH': 'GHANA',
    'GI': 'GIBRALTAR', 'GR': 'GREECE', 'GL': 'GREENLAND', 'GD': 'GRENADA', 'GP': 'GUADELOUPE', 'GU': 'GUAM',
    'GT': 'GUATEMALA', 'GG': 'GUERNSEY', 'GN': 'GUINEA', 'GW': 'GUINEA-BISSAU', 'GY': 'GUYANA', 'HT': 'HAITI',
    'HM': 'HEARD ISLAND AND MCDONALD ISLANDS', 'VA': 'VATICAN CITY', 'HN': 'HONDURAS', 'HK': 'HONG KONG', 'HU': 'HUNGARY',
    'IS': 'ICELAND', 'IN': 'INDIA', 'ID': 'INDONESIA', 'IR': 'IRAN', 'IQ': 'IRAQ', 'IE': 'IRELAND',
    'IM': 'ISLE OF MAN', 'IL': 'ISRAEL', 'IT': 'ITALY', 'JM': 'JAMAICA', 'JP': 'JAPAN', 'JE': 'JERSEY',
    'JO': 'JORDAN', 'KZ': 'KAZAKHSTAN', 'KE': 'KENYA', 'KI': 'KIRIBATI', 'KP': 'NORTH KOREA', 'KR': 'SOUTH KOREA',
    'KW': 'KUWAIT', 'KG': 'KYRGYZSTAN', 'LA': 'LAOS', 'LV': 'LATVIA', 'LB': 'LEBANON', 'LS': 'LESOTHO',
    'LR': 'LIBERIA', 'LY': 'LIBYA', 'LI': 'LIECHTENSTEIN', 'LT': 'LITHUANIA', 'LU': 'LUXEMBOURG', 'MO': 'MACAU',
    'MG': 'MADAGASCAR', 'MW': 'MALAWI', 'MY': 'MALAYSIA', 'MV': 'MALDIVES', 'ML': 'MALI', 'MT': 'MALTA',
    'MH': 'MARSHALL ISLANDS', 'MQ': 'MARTINIQUE', 'MR': 'MAURITANIA', 'MU': 'MAURITIUS', 'YT': 'MAYOTTE', 'MX': 'MEXICO',
    'FM': 'MICRONESIA', 'MD': 'MOLDOVA', 'MC': 'MONACO', 'MN': 'MONGOLIA', 'ME': 'MONTENEGRO', 'MS': 'MONTSERRAT',
    'MA': 'MOROCCO', 'MZ': 'MOZAMBIQUE', 'MM': 'MYANMAR', 'NA': 'NAMIBIA', 'NR': 'NAURU', 'NP': 'NEPAL',
    'NL': 'NETHERLANDS', 'NC': 'NEW CALEDONIA', 'NZ': 'NEW ZEALAND', 'NI': 'NICARAGUA', 'NE': 'NIGER', 'NG': 'NIGERIA',
    'NU': 'NIUE', 'NF': 'NORFOLK ISLAND', 'MK': 'NORTH MACEDONIA', 'MP': 'NORTHERN MARIANA ISLANDS', 'NO': 'NORWAY',
    'OM': 'OMAN', 'PK': 'PAKISTAN', 'PW': 'PALAU', 'PS': 'PALESTINE', 'PA': 'PANAMA', 'PG': 'PAPUA NEW GUINEA',
    'PY': 'PARAGUAY', 'PE': 'PERU', 'PH': 'PHILIPPINES', 'PN': 'PITCAIRN', 'PL': 'POLAND', 'PT': 'PORTUGAL',
    'PR': 'PUERTO RICO', 'QA': 'QATAR', 'RE': 'REUNION', 'RO': 'ROMANIA', 'RU': 'RUSSIA', 'RW': 'RWANDA',
    'BL': 'SAINT BARTHELEMY', 'SH': 'SAINT HELENA', 'KN': 'SAINT KITTS AND NEVIS', 'LC': 'SAINT LUCIA',
    'MF': 'SAINT MARTIN', 'PM': 'SAINT PIERRE AND MIQUELON', 'VC': 'SAINT VINCENT AND THE GRENADINES',
    'WS': 'SAMOA', 'SM': 'SAN MARINO', 'ST': 'SAO TOME AND PRINCIPE', 'SA': 'SAUDI ARABIA', 'SN': 'SENEGAL',
    'RS': 'SERBIA', 'SC': 'SEYCHELLES', 'SL': 'SIERRA LEONE', 'SG': 'SINGAPORE', 'SX': 'SINT MAARTEN',
    'SK': 'SLOVAKIA', 'SI': 'SLOVENIA', 'SB': 'SOLOMON ISLANDS', 'SO': 'SOMALIA', 'ZA': 'SOUTH AFRICA',
    'GS': 'SOUTH GEORGIA', 'SS': 'SOUTH SUDAN', 'ES': 'SPAIN', 'LK': 'SRI LANKA', 'SD': 'SUDAN',
    'SR': 'SURINAME', 'SJ': 'SVALBARD AND JAN MAYEN', 'SE': 'SWEDEN', 'CH': 'SWITZERLAND', 'SY': 'SYRIA',
    'TW': 'TAIWAN', 'TJ': 'TAJIKISTAN', 'TZ': 'TANZANIA', 'TH': 'THAILAND', 'TL': 'TIMOR-LESTE',
    'TG': 'TOGO', 'TK': 'TOKELAU', 'TO': 'TONGA', 'TT': 'TRINIDAD AND TOBAGO', 'TN': 'TUNISIA',
    'TR': 'TURKEY', 'TM': 'TURKMENISTAN', 'TC': 'TURKS AND CAICOS ISLANDS', 'TV': 'TUVALU', 'UG': 'UGANDA',
    'UA': 'UKRAINE', 'AE': 'UNITED ARAB EMIRATES', 'GB': 'UNITED KINGDOM', 'US': 'UNITED STATES',
    'UM': 'UNITED STATES MINOR OUTLYING ISLANDS', 'UY': 'URUGUAY', 'UZ': 'UZBEKISTAN', 'VU': 'VANUATU',
    'VE': 'VENEZUELA', 'VN': 'VIETNAM', 'VG': 'VIRGIN ISLANDS (BRITISH)', 'VI': 'VIRGIN ISLANDS (U.S.)',
    'WF': 'WALLIS AND FUTUNA', 'EH': 'WESTERN SAHARA', 'YE': 'YEMEN', 'ZM': 'ZAMBIA', 'ZW': 'ZIMBABWE',
    'XK': 'KOSOVO',

    // 3-letter ISO and common legacy aliases
    'USA': 'UNITED STATES', 'UK': 'UNITED KINGDOM', 'UAE': 'UNITED ARAB EMIRATES',
    'FRA': 'FRANCE', 'DUBAI': 'UNITED ARAB EMIRATES', 'DXB': 'UNITED ARAB EMIRATES',
    'SHARJAH': 'UNITED ARAB EMIRATES', 'SHJ': 'UNITED ARAB EMIRATES',
    'ABU DHABI': 'UNITED ARAB EMIRATES', 'ABUDHABI': 'UNITED ARAB EMIRATES', 'AUH': 'UNITED ARAB EMIRATES',
    'AJMAN': 'UNITED ARAB EMIRATES', 'FUJAIRAH': 'UNITED ARAB EMIRATES',
    'DEU': 'GERMANY', 'GER': 'GERMANY', 'CAN': 'CANADA', 'SGP': 'SINGAPORE', 'SIN': 'SINGAPORE',
    'IND': 'INDIA', 'AUS': 'AUSTRALIA', 'GBR': 'UNITED KINGDOM', 'NZL': 'NEW ZEALAND', 'NLD': 'NETHERLANDS',
    'HOL': 'NETHERLANDS', 'ITA': 'ITALY', 'ESP': 'SPAIN', 'CHE': 'SWITZERLAND', 'SUI': 'SWITZERLAND',
    'CHN': 'CHINA', 'JPN': 'JAPAN', 'KOR': 'SOUTH KOREA', 'MYS': 'MALAYSIA', 'MAS': 'MALAYSIA',
    'THA': 'THAILAND', 'IDN': 'INDONESIA', 'PHL': 'PHILIPPINES', 'VNM': 'VIETNAM', 'SAU': 'SAUDI ARABIA',
    'KSA': 'SAUDI ARABIA', 'QAT': 'QATAR', 'KWT': 'KUWAIT', 'BHR': 'BAHRAIN', 'OMN': 'OMAN',
    'TUR': 'TURKEY', 'EGY': 'EGYPT', 'ZAF': 'SOUTH AFRICA', 'RSA': 'SOUTH AFRICA', 'RUS': 'RUSSIA',
    'BRA': 'BRAZIL', 'MEX': 'MEXICO', 'ARG': 'ARGENTINA', 'COL': 'COLOMBIA', 'CHL': 'CHILE',
    'POL': 'POLAND', 'SWE': 'SWEDEN', 'NOR': 'NORWAY', 'DNK': 'DENMARK', 'FIN': 'FINLAND',
    'IRL': 'IRELAND', 'BEL': 'BELGIUM', 'AUT': 'AUSTRIA', 'PRT': 'PORTUGAL', 'POR': 'PORTUGAL',
    'GRC': 'GREECE', 'CZE': 'CZECH REPUBLIC', 'HUN': 'HUNGARY', 'ROU': 'ROMANIA', 'ISR': 'ISRAEL',
    'LKA': 'SRI LANKA', 'BGD': 'BANGLADESH', 'NPL': 'NEPAL', 'PAK': 'PAKISTAN', 'HKG': 'HONG KONG', 'TWN': 'TAIWAN'
  };

  function cpGetFullCountryName(val) {
    if (!val || typeof val !== 'string') return '';
    var clean = val.trim();
    // Strip leading/trailing dashes and hyphens
    clean = clean.replace(/^[\s\-–—]+|[\s\-–—]+$/g, '').trim().toUpperCase();
    if (!clean || clean === '-' || clean === '–' || clean === '—' || clean === 'NULL' || clean === 'UNDEFINED' || clean === 'N/A' || clean === 'NONE') return '';
    
    // Strip trailing ISO code pattern like " - AE" or " (AE)"
    var simplified = clean.replace(/\s*[-–—]\s*[A-Z]{2,3}$/, '').replace(/\s*\([A-Z]{2,3}\)$/, '').trim();
    if (simplified && cpCountryDictionary[simplified]) return cpCountryDictionary[simplified];

    // Check direct dictionary
    if (cpCountryDictionary[clean]) return cpCountryDictionary[clean];

    // Check if clean matches any value directly
    for (var k in cpCountryDictionary) {
      if (cpCountryDictionary[k] === clean || cpCountryDictionary[k] === simplified) return cpCountryDictionary[k];
    }

    // Check if city/country combined like "DUBAI, UAE"
    if (clean.indexOf(',') >= 0) {
      var parts = clean.split(',');
      for (var i = parts.length - 1; i >= 0; i--) {
        var part = parts[i].trim();
        if (cpCountryDictionary[part]) return cpCountryDictionary[part];
      }
    }

    return (simplified || clean).replace(/^[\s\-–—]+|[\s\-–—]+$/g, '');
  }

  function cpDebounceShipmentsSearch() {
    var val = (document.getElementById('cp-search')?.value || '').trim();
    var clearBtn = document.getElementById('cp-search-clear');
    if (clearBtn) clearBtn.style.display = val ? 'block' : 'none';
    clearTimeout(cpShipSearchTimer);
    cpShipSearchTimer = setTimeout(function () {
      cpLoadShipments(1);
    }, 350);
  }

  function cpClearShipmentsSearch() {
    var inp = document.getElementById('cp-search');
    if (inp) { inp.value = ''; }
    var clearBtn = document.getElementById('cp-search-clear');
    if (clearBtn) clearBtn.style.display = 'none';
    cpLoadShipments(1);
  }

  function cpDebounceRequestsSearch() {
    var val = (document.getElementById('cp-req-search')?.value || '').trim();
    var clearBtn = document.getElementById('cp-req-search-clear');
    if (clearBtn) clearBtn.style.display = val ? 'block' : 'none';
    clearTimeout(cpReqSearchTimer);
    cpReqSearchTimer = setTimeout(function () {
      cpLoadRequests(1);
    }, 350);
  }

  function cpClearRequestsSearch() {
    var inp = document.getElementById('cp-req-search');
    if (inp) { inp.value = ''; }
    var clearBtn = document.getElementById('cp-req-search-clear');
    if (clearBtn) clearBtn.style.display = 'none';
    cpLoadRequests(1);
  }

  // Tab Switching Engine
  function cpSwitchTab(tabId, btn) {
    document.querySelectorAll('.cp-main-content').forEach(c => c.classList.remove('active'));
    document.querySelectorAll('.cp-nav-item').forEach(i => i.classList.remove('active'));

    if (!btn) {
      var items = document.querySelectorAll('.cp-nav-item');
      items.forEach(item => {
        var onclickAttr = item.getAttribute('onclick') || '';
        if (onclickAttr.indexOf("'" + tabId + "'") >= 0) {
          btn = item;
        }
      });
    }

    document.getElementById('tab-' + tabId).classList.add('active');
    if (btn) btn.classList.add('active');

    // Reload iframe when hitting tab 2
    if (tabId === 'new-booking') {
      var frame = document.getElementById('pe-booking-iframe');
      if (frame) frame.src = frame.src;
    }
    if (tabId === 'requests') {
      cpLoadRequests(1);
    }
  }

  function cpSetRequestStatusFilter(st, btn) {
    document.querySelectorAll('.cp-status-tab').forEach(t => t.classList.remove('active'));
    if (btn) btn.classList.add('active');
    cpReqStatus = st;
    cpLoadRequests(1);
  }

  function cpLoadRequests(p, silent) {
    cpReqPage = p || 1;
    cpReqSearch = document.getElementById('cp-req-search').value;
    if (!silent) document.getElementById('cp-requests-container').innerHTML = cpSkeleton();
    cpAjax('pe_cp_my_requests', { page: cpReqPage, search: cpReqSearch, status: cpReqStatus }, function (d) {
      if (!d.success) {
        if (!silent) {
          document.getElementById('cp-requests-container').innerHTML = '<div style="text-align:center;padding:50px;color:var(--cptext3);"><i class="fa-solid fa-triangle-exclamation" style="font-size:28px;display:block;margin-bottom:10px;color:var(--cpred);"></i>' + (d.data?.message || 'Unable to load booking requests. Please try refreshing.') + '<br><button class="cp-cta-btn-link" onclick="cpLoadRequests(1)" style="margin-top:14px;border:none;cursor:pointer;">Retry</button></div>';
        }
        return;
      }
      var r = d.data;
      // Store hash to detect changes for polling
      var newHash = JSON.stringify(r.rows.map(function (rw) { return rw.request_awb + ':' + rw.status }));

      // Detect status changes and show toast notifications
      if (silent && cpReqLastHash && newHash !== cpReqLastHash) {
        try {
          var oldItems = JSON.parse(cpReqLastHash);
          var newItems = JSON.parse(newHash);
          var oldMap = {};
          oldItems.forEach(function (item) {
            var parts = item.split(':');
            oldMap[parts[0]] = parts[1];
          });
          newItems.forEach(function (item) {
            var parts = item.split(':');
            var awb = parts[0], st = parts[1];
            if (oldMap[awb] && oldMap[awb] !== st) {
              var stLabel = st.charAt(0).toUpperCase() + st.slice(1);
              var iconType = st === 'confirmed' ? 'success' : st === 'rejected' ? 'error' : st === 'processing' ? 'info' : 'warning';
              cpShowToast(iconType, 'Status Updated', 'Request ' + awb + ' is now ' + stLabel);
            }
          });
        } catch (e) { }
      }

      if (silent && newHash === cpReqLastHash) return; // No change, skip re-render
      var prevHash = cpReqLastHash;
      cpReqLastHash = newHash;
      var h = '';
      h += '<div class="cp-tc"><div class="cp-th"><h3><i class="fa-solid fa-clipboard-list"></i> Booking Requests <span class="badge">' + r.total + '</span></h3></div>';
      h += '<div class="cp-tw"><table class="cp-t"><thead><tr><th>Request AWB</th><th>Date Submitted</th><th>Receiver</th><th>Destination</th><th>Package</th><th>Status</th><th style="text-align:center;">Action</th></tr></thead><tbody>';
      if (!r.rows.length) h += '<tr><td colspan="7" style="text-align:center;padding:50px;color:var(--cptext3)"><i class="fa-solid fa-inbox" style="font-size:28px;display:block;margin-bottom:10px;opacity:.2"></i>No booking requests found</td></tr>';

      r.rows.forEach(function (rw) {
        var stLabel = rw.status.charAt(0).toUpperCase() + rw.status.slice(1);
        var stClass = 'st-' + rw.status;
        var dotClass = 'bg-' + rw.status;

        var formattedDate = rw.created_at ? new Date(rw.created_at).toLocaleDateString('en-IN', { day: '2-digit', month: 'short', year: 'numeric' }) : '—';

        var actionHtml = '';
        if (rw.status !== 'confirmed' && rw.status !== 'cancelled' && rw.status !== 'rejected') {
          actionHtml = '<button onclick="event.stopPropagation(); cpCancelBookingRequest(\'' + rw.request_awb + '\')" title="Cancel this request" style="background:#fee2e2;color:#dc2626;border:1px solid #fecaca;padding:4px 9px;border-radius:6px;font-size:11px;font-weight:700;cursor:pointer;display:inline-flex;align-items:center;gap:4px;"><i class="fa-solid fa-trash-can"></i> Cancel</button>';
        }

        var statusHtml = '<div class="cp-st"><span class="cp-dot ' + dotClass + '"></span><span class="' + stClass + '">' + stLabel + '</span></div>';
        if (rw.status === 'rejected') {
          statusHtml = '<div class="cp-st"><span class="cp-dot bg-rejected"></span><span class="st-rejected" style="font-weight:800;">Rejected</span></div>';
          if (rw.admin_notes) {
            statusHtml += '<div style="font-size:10.5px;color:var(--cpred);margin-top:2px;max-width:140px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;" title="' + rw.admin_notes.replace(/"/g, '&quot;') + '"><i class="fa-solid fa-circle-exclamation" style="font-size:9px;margin-right:2px;"></i>' + rw.admin_notes + '</div>';
          }
        }

        h += '<tr onclick="cpShowRequestDetail(\'' + rw.request_awb + '\')">';
        h += '<td class="awbc"><div style="display:inline-flex;align-items:center;gap:6px;"><span>' + rw.request_awb + '</span><button type="button" class="cp-copy-btn" onclick="cpCopyText(\'' + rw.request_awb + '\', \'Request AWB\', event)" title="Copy Request AWB"><i class="fa-regular fa-copy"></i></button></div></td>';
        h += '<td style="font-weight:600;color:var(--cptext2)">' + formattedDate + '</td>';
        h += '<td class="nmc">' + (rw.receiver_name || '—') + '</td>';
        h += '<td><i class="fa-solid fa-location-dot" style="color:var(--cptext3);font-size:10px;margin-right:4px"></i>' + (rw.receiver_city || '—') + (rw.receiver_country ? ' (' + cpGetFullCountryName(rw.receiver_country) + ')' : '') + '</td>';
        h += '<td style="font-weight:600">' + (rw.weight || '—') + ' kg (' + (rw.package_type || 'parcel') + ')</td>';
        h += '<td>' + statusHtml + '</td>';
        h += '<td style="text-align:center;">' + actionHtml + '</td></tr>';
      });
      h += '</tbody></table></div>';
      h += '<div class="cp-pg"><div class="cp-pi">Showing <strong>' + r.rows.length + '</strong> of <strong>' + r.total + '</strong> · Page ' + r.page + '/' + r.pages + '</div><div class="cp-pbs">';
      h += '<button class="cp-pb" onclick="cpLoadRequests(' + (r.page - 1) + ')" ' + (r.page <= 1 ? 'disabled' : '') + '><i class="fa-solid fa-chevron-left" style="font-size:10px"></i></button>';
      for (var i = Math.max(1, r.page - 2); i <= Math.min(r.pages, r.page + 2); i++) h += '<button class="cp-pb' + (i === r.page ? ' on' : '') + '" onclick="cpLoadRequests(' + i + ')">' + i + '</button>';
      h += '<button class="cp-pb" onclick="cpLoadRequests(' + (r.page + 1) + ')" ' + (r.page >= r.pages ? 'disabled' : '') + '><i class="fa-solid fa-chevron-right" style="font-size:10px"></i></button>';
      h += '</div></div></div>';
      document.getElementById('cp-requests-container').innerHTML = h;
    });
  }

  function cpShowRequestDetail(awb) {
    cpDetailOpenAwb = awb; // Track which detail is open for polling
    var panel = document.getElementById('cp-detail-panel');
    panel.innerHTML = '<div style="padding:40px;text-align:center"><div style="width:30px;height:30px;border:3px solid #e5e7eb;border-top-color:#bb0013;border-radius:50%;animation:cp-spin .6s linear infinite;margin:0 auto 16px"></div><p style="color:#94a3b8;font-size:14px">Loading request details...</p></div>';
    document.getElementById('cp-detail-overlay').classList.add('show');
    cpRenderRequestDetail(awb, false);
    cpStartDetailPolling();
  }

  function cpRenderRequestDetail(awb, silent) {
    var panel = document.getElementById('cp-detail-panel');
    cpAjax('pe_cp_request_detail', { request_awb: awb }, function (d) {
      if (!d.success) { if (!silent) panel.innerHTML = '<div style="padding:40px;text-align:center;color:#dc2626">Failed to load details</div>'; return; }
      var r = d.data.request, tl = d.data.timeline;
      // Hash check for silent updates
      var newHash = r.status + ':' + tl.length + ':' + (tl.length ? tl[0].title : '');
      if (silent && newHash === cpDetailLastHash) return;
      cpDetailLastHash = newHash;
      var stLabel = r.status.charAt(0).toUpperCase() + r.status.slice(1);
      var dotClass = 'bg-' + r.status;
      var stClass = 'st-' + r.status;

      var formattedDate = r.created_at ? new Date(r.created_at).toLocaleDateString('en-IN', { day: '2-digit', month: 'short', year: 'numeric', hour: '2-digit', minute: '2-digit' }) : '—';

      var h = '';
      h += '<div class="cp-dh"><div style="display:flex;align-items:center;gap:8px;"><h3><i class="fa-solid fa-clipboard-list"></i> Request ' + r.request_awb + '</h3><button type="button" class="cp-copy-btn" onclick="cpCopyText(\'' + r.request_awb + '\', \'Request AWB\', event)" title="Copy Request AWB"><i class="fa-regular fa-copy"></i> Copy</button><span class="cp-live-badge" style="font-size:9px"><span class="cp-live-dot"></span>Live</span></div>';
      h += '<div style="display:flex;align-items:center;gap:8px;">';
      if (r.status !== 'confirmed' && r.status !== 'cancelled' && r.status !== 'rejected') {
        h += '<button onclick="cpCancelBookingRequest(\'' + r.request_awb + '\')" style="background:#fee2e2;color:#dc2626;border:1px solid #fecaca;padding:6px 12px;border-radius:8px;font-size:12px;font-weight:700;cursor:pointer;display:inline-flex;align-items:center;gap:5px;"><i class="fa-solid fa-trash-can"></i> Cancel Request</button>';
      }
      h += '<button class="cp-dc" onclick="cpCloseDetail()"><i class="fa-solid fa-xmark"></i></button></div></div>';
      h += '<div class="cp-db-body">';

      // Status & Link to Shipment
      h += '<div class="cp-ds"><h4><i class="fa-solid fa-circle-info"></i> Current Status</h4>';
      h += '<div style="display:flex; justify-content:space-between; align-items:center; padding:12px 16px; background:#f8fafc; border-radius:10px; border:1px solid #e2e8f0">';
      h += '  <div style="display:flex; align-items:center; gap:8px;">';
      h += '    <span class="cp-dot ' + dotClass + '" style="width:10px;height:10px"></span>';
      h += '    <span class="' + stClass + '" style="font-size:15px;font-weight:800">' + stLabel + '</span>';
      h += '  </div>';

      if (r.tracking_number) {
        h += '  <button onclick="cpCloseDetail(); cpSwitchTab(\'shipments\'); document.getElementById(\'cp-search\').value=\'' + r.tracking_number + '\'; cpLoadShipments(1);" style="border:1px solid var(--cpbdr); background:#fff; padding:6px 12px; border-radius:8px; font-size:12px; font-weight:700; color:var(--cptext2); cursor:pointer;">';
        h += '    <i class="fa-solid fa-truck-ramp-box" style="margin-right:4px;"></i> Track Shipment ' + r.tracking_number;
        h += '  </button>';
      }
      h += '</div>';
      if (r.status === 'rejected' && r.admin_notes) {
        h += '<div style="margin-top:8px; padding:10px 14px; background:#fef2f2; border:1px solid #fecaca; border-radius:8px; font-size:12px; color:#991b1b;"><strong style="display:block; margin-bottom:2px;"><i class="fa-solid fa-triangle-exclamation" style="margin-right:4px;"></i>Reason for Rejection:</strong>' + r.admin_notes + '</div>';
      }
      h += '</div>';

      // Sender/Receiver Details
      h += '<div class="cp-ds"><h4><i class="fa-solid fa-route"></i> Route Details</h4><div class="cp-dg">';
      h += '<div class="cp-df"><div class="l">Sender Name</div><div class="v">' + (r.sender_name || '—') + '</div></div>';
      h += '<div class="cp-df"><div class="l">Receiver Name</div><div class="v">' + (r.receiver_name || '—') + '</div></div>';
      h += '<div class="cp-df"><div class="l">Sender City</div><div class="v">' + (r.sender_city || '—') + '</div></div>';
      h += '<div class="cp-df"><div class="l">Receiver City</div><div class="v">' + (r.receiver_city || '—') + '</div></div>';
      h += '<div class="cp-df fl"><div class="l">Sender Address</div><div class="v">' + [r.sender_address, r.sender_address_2, r.sender_city, r.sender_pincode, r.sender_state, cpGetFullCountryName(r.sender_country || 'INDIA')].filter(Boolean).join(', ') + '</div></div>';
      h += '<div class="cp-df fl"><div class="l">Receiver Address</div><div class="v">' + [r.receiver_address, r.receiver_address_2, r.receiver_city, r.receiver_pincode, r.receiver_state, cpGetFullCountryName(r.receiver_country)].filter(Boolean).join(', ') + '</div></div>';
      h += '</div></div>';

      // Package Details
      h += '<div class="cp-ds"><h4><i class="fa-solid fa-box"></i> Package Details</h4><div class="cp-dg">';
      h += '<div class="cp-df"><div class="l">Package Type</div><div class="v" style="text-transform:capitalize;">' + (r.package_type || '—') + '</div></div>';
      h += '<div class="cp-df"><div class="l">Weight</div><div class="v">' + (r.weight || '—') + ' kg</div></div>';
      h += '<div class="cp-df"><div class="l">No. of Pieces</div><div class="v">' + (r.no_of_pieces || '1') + '</div></div>';
      h += '<div class="cp-df"><div class="l">Declared Value</div><div class="v">₹' + (r.declared_value || '0') + '</div></div>';
      if (r.total_amount || r.shipping_charge) {
        h += '<div class="cp-df"><div class="l">Final Amount / Charges</div><div class="v" style="font-weight:800; color:var(--cpred);">₹' + (r.total_amount || r.shipping_charge || '0') + '</div></div>';
      }
      if (r.content_description) h += '<div class="cp-df fl"><div class="l">Content Description</div><div class="v">' + r.content_description + '</div></div>';
      if (r.remarks) h += '<div class="cp-df fl"><div class="l">Special Instructions / Remarks</div><div class="v">' + r.remarks + '</div></div>';
      if (r.admin_notes) h += '<div class="cp-df fl" style="border-color:rgba(187,0,19,.15); background:rgba(187,0,19,.02);"><div class="l" style="color:var(--cpred)">Admin Notes</div><div class="v">' + r.admin_notes + '</div></div>';
      h += '</div></div>';

      // Parcels & Dimensions Table (multi-box)
      if (r.parcels && Array.isArray(r.parcels) && r.parcels.length > 0) {
        h += '<div class="cp-ds"><h4><i class="fa-solid fa-boxes-stacked"></i> Parcels & Dimensions (' + r.parcels.length + ' boxes)</h4>';
        h += '<div style="overflow-x:auto; border:1px solid var(--cpbdr); border-radius:10px;">';
        h += '<table style="width:100%; border-collapse:collapse; font-size:12px;">';
        h += '<thead><tr style="background:var(--cpbg2); border-bottom:1px solid var(--cpbdr);">';
        h += '<th style="padding:8px 10px; text-align:left; font-size:9px; font-weight:800; color:var(--cptext3); text-transform:uppercase; letter-spacing:.5px;">Box</th>';
        h += '<th style="padding:8px 10px; text-align:left; font-size:9px; font-weight:800; color:var(--cptext3); text-transform:uppercase; letter-spacing:.5px;">Weight (kg)</th>';
        h += '<th style="padding:8px 10px; text-align:left; font-size:9px; font-weight:800; color:var(--cptext3); text-transform:uppercase; letter-spacing:.5px;">L × B × H (cm)</th>';
        h += '<th style="padding:8px 10px; text-align:left; font-size:9px; font-weight:800; color:var(--cptext3); text-transform:uppercase; letter-spacing:.5px;">Vol. Wt</th>';
        h += '<th style="padding:8px 10px; text-align:left; font-size:9px; font-weight:800; color:var(--cptext3); text-transform:uppercase; letter-spacing:.5px;">Chg. Wt</th>';
        h += '</tr></thead><tbody>';
        r.parcels.forEach(function (p, i) {
          h += '<tr style="border-bottom:1px solid rgba(0,0,0,.05);">';
          h += '<td style="padding:8px 10px; font-weight:600; color:var(--cptext1);">' + (p.box_no || (i + 1)) + '</td>';
          h += '<td style="padding:8px 10px; color:var(--cptext2);">' + (p.weight || '—') + '</td>';
          h += '<td style="padding:8px 10px; color:var(--cptext2);">' + (p.length || 0) + ' × ' + (p.breadth || 0) + ' × ' + (p.height || 0) + '</td>';
          h += '<td style="padding:8px 10px; color:var(--cptext2);">' + (p.volumetric_weight || '—') + '</td>';
          h += '<td style="padding:8px 10px; font-weight:600; color:var(--cptext1);">' + (p.chargeable_weight || '—') + '</td>';
          h += '</tr>';
        });
        h += '</tbody></table></div></div>';
      }

      // Invoice Items Table
      var reqInvItems = r.invoice_items;
      if (typeof reqInvItems === 'string') {
        try { reqInvItems = JSON.parse(reqInvItems); } catch(e) { reqInvItems = []; }
      }
      if (reqInvItems && Array.isArray(reqInvItems) && reqInvItems.length > 0) {
        h += '<div class="cp-ds"><h4><i class="fa-solid fa-file-invoice"></i> Invoice Items (' + reqInvItems.length + ')</h4>';
        h += '<div style="overflow-x:auto; border:1px solid var(--cpbdr); border-radius:10px;">';
        h += '<table style="width:100%; border-collapse:collapse; font-size:12px;">';
        h += '<thead><tr style="background:var(--cpbg2); border-bottom:1px solid var(--cpbdr);">';
        h += '<th style="padding:8px 10px; text-align:left; font-size:9px; font-weight:800; color:var(--cptext3); text-transform:uppercase; letter-spacing:.5px;">#</th>';
        h += '<th style="padding:8px 10px; text-align:left; font-size:9px; font-weight:800; color:var(--cptext3); text-transform:uppercase; letter-spacing:.5px;">Box</th>';
        h += '<th style="padding:8px 10px; text-align:left; font-size:9px; font-weight:800; color:var(--cptext3); text-transform:uppercase; letter-spacing:.5px;">Description</th>';
        h += '<th style="padding:8px 10px; text-align:left; font-size:9px; font-weight:800; color:var(--cptext3); text-transform:uppercase; letter-spacing:.5px;">Qty</th>';
        h += '</tr></thead><tbody>';
        reqInvItems.forEach(function (item, i) {
          h += '<tr style="border-bottom:1px solid rgba(0,0,0,.05);">';
          h += '<td style="padding:8px 10px; color:var(--cptext3);">' + (item.sr_no || (i + 1)) + '</td>';
          h += '<td style="padding:8px 10px; color:var(--cptext2);">' + (item.box_no || '—') + '</td>';
          h += '<td style="padding:8px 10px; font-weight:600; color:var(--cptext1); max-width:180px; overflow:hidden; text-overflow:ellipsis; white-space:nowrap;">' + (item.description || item.item_name || item.name || '—') + '</td>';
          h += '<td style="padding:8px 10px; color:var(--cptext2);">' + (item.quantity || item.qty || '—') + ' ' + (item.unit_type || item.unit || '') + '</td>';
          h += '</tr>';
        });
        h += '</tbody></table></div></div>';
      }

      // Attached Documents
      if (r.documents && Array.isArray(r.documents) && r.documents.length > 0) {
        h += '<div class="cp-ds"><h4><i class="fa-solid fa-paperclip"></i> Attached Documents (' + r.documents.length + ')</h4><div class="cp-dg">';
        r.documents.forEach(function (doc, i) {
          h += '<div class="cp-df fl" style="display:flex; align-items:center; gap:10px;">';
          h += '<i class="fa-solid fa-file-lines" style="color:var(--cpred); font-size:16px;"></i>';
          h += '<div style="flex:1; min-width:0;"><div class="l" style="font-size:12px; font-weight:600; color:var(--cptext1);">' + (doc.doc_type || doc.name || 'Document ' + (i + 1)) + '</div>';
          if (doc.doc_number) h += '<div style="font-size:10px; color:var(--cptext3);">No: ' + doc.doc_number + '</div>';
          h += '</div>';
          if (doc.file_url) h += '<a href="' + doc.file_url + '" target="_blank" rel="noopener noreferrer" download style="font-size:11px; font-weight:700; color:var(--cpred); text-decoration:none; display:inline-flex; align-items:center; gap:4px;"><i class="fa-solid fa-arrow-up-right-from-square" style="font-size:10px;"></i> View / Download</a>';
          h += '</div>';
        });
        h += '</div></div>';
      }

      // Official Box Labels & Shipping Documents
      var labelAwb = r.tracking_number || r.request_awb;
      var labelUrl = 'https://purple-raccoon-753399.hostingersite.com/api/customer/labels-pdf/' + encodeURIComponent(labelAwb);
      var waybillUrl = 'https://purple-raccoon-753399.hostingersite.com/api/customer/waybill-pdf/' + encodeURIComponent(labelAwb);

      h += '<div class="cp-ds"><h4><i class="fa-solid fa-tags"></i> Official Labels & Documents</h4>';
      h += '<div style="display:flex; gap:8px; flex-wrap:wrap; margin-top:6px;">';
      h += '  <a href="' + labelUrl + '" target="_blank" rel="noopener noreferrer" download style="display:inline-flex; align-items:center; gap:6px; background:#ebf5ff; color:#1e40af; border:1px solid #bfdbfe; padding:8px 14px; border-radius:8px; font-size:12px; font-weight:700; text-decoration:none;"><i class="fa-solid fa-tag"></i> Download Box Label</a>';
      h += '  <a href="' + waybillUrl + '" target="_blank" rel="noopener noreferrer" download style="display:inline-flex; align-items:center; gap:6px; background:#f0fdf4; color:#166534; border:1px solid #bbf7d0; padding:8px 14px; border-radius:8px; font-size:12px; font-weight:700; text-decoration:none;"><i class="fa-solid fa-file-invoice-dollar"></i> Download Shipping Bill</a>';
      h += '</div></div>';

      // Timeline Section (Merges Status Changes + Shipping Events)
      h += '<div class="cp-ds"><h4><i class="fa-solid fa-clock-rotate-left"></i> Progress Timeline</h4>';
      if (tl.length) {
        h += '<ul class="cp-tl">';
        tl.forEach(function (t, i) {
          var iconHtml = '<i class="fa-solid fa-circle-dot"></i>';
          var borderStyle = '';
          var dotColorClass = 'bg-pending';

          if (t.type === 'status_change') {
            if (t.description.indexOf('confirmed') >= 0) {
              dotColorClass = 'bg-confirmed';
              iconHtml = '<i class="fa-solid fa-circle-check"></i>';
            } else if (t.description.indexOf('rejected') >= 0) {
              dotColorClass = 'bg-rejected';
              iconHtml = '<i class="fa-solid fa-circle-xmark"></i>';
            } else {
              dotColorClass = 'bg-processing';
              iconHtml = '<i class="fa-solid fa-circle-dot"></i>';
            }
          } else if (t.type === 'shipment_created') {
            dotColorClass = 'bg-confirmed';
            iconHtml = '<i class="fa-solid fa-truck-fast"></i>';
          } else if (t.type === 'tracking_update') {
            dotColorClass = 'bg-processing';
            iconHtml = '<i class="fa-solid fa-location-arrow"></i>';
            if (t.title.toLowerCase().indexOf('deliver') >= 0) {
              dotColorClass = 'bg-confirmed';
              iconHtml = '<i class="fa-solid fa-house-chimney-check"></i>';
            }
          }

          h += '<li style="animation-delay:' + (.03 * i) + 's; border-left-color: ' + (i === 0 ? 'var(--cpgreen)' : 'var(--cpbdr)') + ';"><div class="cp-tl-card"><div class="cp-tla" style="display:flex; align-items:center; gap:6px;">' + iconHtml + t.title + '</div><div style="font-size:12px; color:var(--cptext2); margin:4px 0;">' + t.description + '</div><div class="cp-tlm"><i class="fa-solid fa-calendar"></i> ' + t.date + '</div></div></li>';
        });
        h += '</ul>';
      } else {
        h += '<div class="cp-tl-empty"><i class="fa-solid fa-route"></i><p>No timeline updates yet</p></div>';
      }
      h += '</div></div>';

      panel.innerHTML = h;
    });
  }

  function cpCancelBookingRequest(awb) {
    if (!confirm('Are you sure you want to cancel booking request ' + awb + '? This cannot be undone.')) {
      return;
    }
    cpAjax('pe_cp_cancel_request', { request_awb: awb }, function (d) {
      if (d.success) {
        cpShowToast('success', 'Cancelled', d.data?.message || 'Booking request has been cancelled.');
        cpLoadRequests(1);
        if (cpDetailOpenAwb === awb) {
          cpCloseDetail();
        }
      } else {
        cpShowToast('error', 'Cancellation Failed', d.data?.message || 'Failed to cancel booking request.');
      }
    });
  }

  // AJAX request wrapper
  function cpAjax(action, params, callback, retried) {
    var fd = new FormData();
    fd.append('action', action);
    fd.append('nonce', PE_CP.nonce);
    if (params) {
      for (var k in params) {
        if (params.hasOwnProperty(k)) fd.append(k, params[k]);
      }
    }
    fetch(PE_CP.ajax_url, { method: 'POST', body: fd, credentials: 'same-origin' })
      .then(r => r.json())
      .then(d => {
        if (!d.success && d.data) {
          if (d.data.nonce_expired && d.data.new_nonce && !retried) {
            PE_CP.nonce = d.data.new_nonce;
            return cpAjax(action, params, callback, true);
          }
          if (d.data.expired) {
            location.reload();
            return;
          }
        }
        if (callback) callback(d);
      })
      .catch(err => console.error('CP AJAX Error:', action, err));
  }

  // Toast Notification System
  function cpShowToast(type, title, desc) {
    var container = document.getElementById('cp-toast-container');
    if (!container) return;
    var iconMap = {
      success: 'fa-circle-check',
      info: 'fa-circle-info',
      warning: 'fa-triangle-exclamation',
      error: 'fa-circle-xmark'
    };
    var toast = document.createElement('div');
    toast.className = 'cp-toast';
    toast.innerHTML = '<div class="cp-toast-icon ' + type + '"><i class="fa-solid ' + (iconMap[type] || 'fa-circle-info') + '"></i></div>'
      + '<div class="cp-toast-body"><div class="cp-toast-title">' + title + '</div><div class="cp-toast-desc">' + desc + '</div></div>';
    container.appendChild(toast);
    // Auto-remove after 5 seconds
    setTimeout(function () {
      toast.classList.add('removing');
      setTimeout(function () { toast.remove(); }, 300);
    }, 5000);
  }

  // Copy to clipboard helper
  function cpCopyText(text, label, e) {
    if (e) {
      if (typeof e.stopPropagation === 'function') e.stopPropagation();
      if (typeof e.preventDefault === 'function') e.preventDefault();
    }
    if (!text) return;
    var clean = String(text).trim().replace(/^FWD\s*:\s*/i, '');
    var lbl = label || 'Number';
    if (navigator.clipboard && window.isSecureContext) {
      navigator.clipboard.writeText(clean).then(function () {
        cpShowToast('success', 'Copied!', lbl + ' ' + clean + ' copied to clipboard');
      }).catch(function () {
        cpFallbackCopy(clean, lbl);
      });
    } else {
      cpFallbackCopy(clean, lbl);
    }
  }

  function cpFallbackCopy(clean, lbl) {
    var ta = document.createElement('textarea');
    ta.value = clean;
    ta.style.position = 'fixed';
    ta.style.left = '-9999px';
    ta.style.top = '0';
    ta.style.opacity = '0';
    document.body.appendChild(ta);
    ta.focus();
    ta.select();
    try {
      document.execCommand('copy');
      cpShowToast('success', 'Copied!', lbl + ' ' + clean + ' copied to clipboard');
    } catch (err) {
      cpShowToast('error', 'Copy Failed', 'Please copy manually: ' + clean);
    }
    document.body.removeChild(ta);
  }

  function cpLogout() {
    cpAjax('pe_cp_logout', {}, function () {
      location.reload();
    });
  }

  function cpGetStatusDot(st, isDelivered) {
    if (!st) return { dot: 'db', label: 'Shipment Booked' };
    var s = st.toLowerCase().trim();
    var dot = 'dt'; // default: transit/orange
    // Force delivered if backend confirmed or status indicates delivered / proof of delivery
    if (isDelivered || s.indexOf('deliver') >= 0 || s.indexOf('dlvd') >= 0 || s.indexOf('proof of delivery') >= 0 || s.indexOf('signed by') >= 0 || s === 'pod') {
      dot = 'dd';
    }
    // Out for delivery (orange/transit)
    else if (s.indexOf('out for') >= 0 || s.indexOf('ofd') >= 0) dot = 'dt';
    // Cancelled / Failed (red)
    else if (s.indexOf('cancel') >= 0 || s.indexOf('reject') >= 0 || s.indexOf('fail') >= 0 || s.indexOf('rto') >= 0 || s.indexOf('return') >= 0) dot = 'dr';
    // Booked / Created (blue)
    else if (s.indexOf('book') >= 0 || s.indexOf('order') >= 0 || s.indexOf('created') >= 0 || s.indexOf('information received') >= 0 || s.indexOf('data received') >= 0) dot = 'db';
    // Customs / Picked up (blue-light)
    else if (s.indexOf('custom') >= 0 || s.indexOf('clearance') >= 0 || s.indexOf('pick') >= 0 || s.indexOf('collect') >= 0) dot = 'dbl';
    // Show FULL status text without truncation, allowing multi-line wrapping
    var label = st || 'Shipment Booked';
    return { dot: dot, label: label };
  }

  function cpSkeleton() {
    var h = '<div class="cp-tc"><div class="cp-th"><h3><i class="fa-solid fa-layer-group"></i> Loading...</h3></div><div class="cp-tw"><table class="cp-t"><tbody>';
    for (var i = 0; i < 5; i++) h += '<tr><td colspan="7" style="padding:18px 16px"><div class="cp-skeleton" style="width:' + (50 + Math.random() * 40) + '%;height:16px"></div></td></tr>';
    h += '</tbody></table></div></div>';
    return h;
  }

  function cpLoadShipments(p) {
    cpPage = p || 1;
    cpSearch = document.getElementById('cp-search').value;
    document.getElementById('cp-shipments-container').innerHTML = cpSkeleton();
    cpAjax('pe_cp_shipments', { page: cpPage, search: cpSearch }, function (d) {
      if (!d.success) {
        document.getElementById('cp-shipments-container').innerHTML = '<div style="text-align:center;padding:50px;color:var(--cptext3);"><i class="fa-solid fa-triangle-exclamation" style="font-size:28px;display:block;margin-bottom:10px;color:var(--cpred);"></i>' + (d.data?.message || 'Unable to load shipments. Please try refreshing.') + '<br><button class="cp-cta-btn-link" onclick="cpLoadShipments(1)" style="margin-top:14px;border:none;cursor:pointer;">Retry</button></div>';
        return;
      }
      var r = d.data, h = '';
      var totalAmt = (typeof r.total_amount !== 'undefined' && Number(r.total_amount) > 0) ? Number(r.total_amount) : ((typeof r.total_billed_amount !== 'undefined' && Number(r.total_billed_amount) > 0) ? Number(r.total_billed_amount) : 0);
      var allAmt = (typeof r.total_all_amount !== 'undefined' && Number(r.total_all_amount) > 0) ? Number(r.total_all_amount) : totalAmt;

      // Always update profile total amount with grand total across ALL shipments
      if (allAmt > 0) {
        var formattedAllAmt = '₹' + Number(allAmt).toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
        var elProfAmt = document.getElementById('cp-profile-total-amount');
        if (elProfAmt) {
          elProfAmt.textContent = formattedAllAmt;
        }
      }

      // If user is searching, show total of matching search results across all matching pages
      // When not searching (or browsing pages 1, 2, 3...), show grand total across all shipments
      var statAmt = cpSearch ? (totalAmt > 0 ? totalAmt : allAmt) : (allAmt > 0 ? allAmt : totalAmt);
      if (statAmt > 0) {
        var formattedStatAmt = '₹' + Number(statAmt).toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
        var elStatAmt = document.getElementById('cp-stat-total-amount');
        if (elStatAmt) {
          elStatAmt.textContent = formattedStatAmt;
        }
      }

      var deliveredCount = Number(r.count_delivered) || 0;
      var pageDelivered = 0;
      if (r.rows && r.rows.length > 0) {
        r.rows.forEach(function (rw) {
          var isDel = Boolean(rw.is_delivered);
          var sLow = (rw.status || '').toLowerCase();
          if (isDel || sLow.indexOf('deliver') >= 0 || sLow.indexOf('proof of delivery') >= 0 || sLow.indexOf('signed by') >= 0 || sLow === 'pod') {
            pageDelivered++;
            rw.is_delivered = true;
          }
        });
      }
      if (pageDelivered > deliveredCount) {
        deliveredCount = pageDelivered;
      }
      if (!cpSearch) {
        var elDel = document.getElementById('cp-stat-delivered');
        if (elDel) {
          elDel.textContent = Number(deliveredCount).toLocaleString('en-IN');
        }
      }

      if (typeof r.count_transit !== 'undefined' && (!cpSearch || Number(r.count_transit) > 0)) {
        var elTr = document.getElementById('cp-stat-transit');
        if (elTr) elTr.textContent = String(r.count_transit).padStart(2, '0');
      }
      if (typeof r.count_all !== 'undefined' && (!cpSearch || Number(r.count_all) > 0)) {
        var elTot = document.getElementById('cp-stat-total-shipments');
        if (elTot) elTot.textContent = Number(r.count_all).toLocaleString('en-IN');
      }
      h += '<div class="cp-tc"><div class="cp-th"><h3><i class="fa-solid fa-layer-group"></i> Your Shipments <span class="badge">' + r.total + '</span></h3></div>';
      h += '<div class="cp-tw"><table class="cp-t"><thead><tr><th>AWB</th><th>Forwarding</th><th>Booking Date</th><th>Consignee</th><th>Destination</th><th>Weight</th><th>Amount</th><th>Status</th></tr></thead><tbody>';
      if (!r.rows.length) h += '<tr><td colspan="8" style="text-align:center;padding:50px;color:var(--cptext3)"><i class="fa-solid fa-inbox" style="font-size:28px;display:block;margin-bottom:10px;opacity:.2"></i>No shipments found</td></tr>';
      r.rows.forEach(function (rw) {
        var stDot = cpGetStatusDot(rw.status, rw.is_delivered);
        var fwdCopyBtn = rw.forwarding_number ? ' <button type="button" class="cp-copy-btn" onclick="cpCopyText(\'' + String(rw.forwarding_number).replace(/'/g, "\\'") + '\', \'Forwarding Number\', event)" title="Copy Forwarding Number"><i class="fa-regular fa-copy"></i></button>' : '';
        var fwdHtml = (rw.forwarding_number ? '<div style="display:inline-flex;align-items:center;gap:5px;font-size:12px;font-weight:700;color:#1e40af;"><i class="fa-solid fa-plane-departure" style="font-size:9px;margin-right:2px;"></i><span>' + rw.forwarding_number + '</span>' + fwdCopyBtn + '</div>' : '<span style="color:var(--cptext3);font-size:11px;">—</span>');
        var rowIsDeliv = Boolean(rw.is_delivered);
        h += '<tr onclick="cpShowDetail(\'' + rw.awb + '\')" data-awb="' + rw.awb + '" data-delivered="' + (rowIsDeliv ? '1' : '0') + '">';
        h += '<td class="awbc"><div style="display:inline-flex;align-items:center;gap:6px;"><span>' + rw.awb + '</span><button type="button" class="cp-copy-btn" onclick="cpCopyText(\'' + rw.awb + '\', \'AWB\', event)" title="Copy AWB"><i class="fa-regular fa-copy"></i></button></div></td>';
        h += '<td>' + fwdHtml + '</td>';
        h += '<td style="font-weight:600;color:var(--cptext2)">' + (rw.booking_date || '—') + '</td>';
        h += '<td class="nmc">' + rw.consignee + '</td>';
        h += '<td><i class="fa-solid fa-location-dot" style="color:var(--cptext3);font-size:10px;margin-right:4px"></i>' + cpGetFullCountryName(rw.destination) + '</td>';
        h += '<td style="font-weight:600">' + (rw.weight || '—') + ' kg</td>';
        h += '<td style="font-weight:700;color:var(--cptext)">' + (rw.amount ? '₹' + Number(rw.amount).toLocaleString('en-IN') : '—') + '</td>';
        h += '<td class="cp-status-cell"><div class="cp-st"><span class="cp-dot ' + stDot.dot + '"></span><span>' + stDot.label + '</span></div></td></tr>';
      });
      h += '</tbody></table></div>';
      h += '<div class="cp-pg"><div class="cp-pi">Showing <strong>' + r.rows.length + '</strong> of <strong>' + r.total + '</strong> · Page ' + r.page + '/' + r.pages + '</div><div class="cp-pbs">';
      h += '<button class="cp-pb" onclick="cpLoadShipments(' + (r.page - 1) + ')" ' + (r.page <= 1 ? 'disabled' : '') + '><i class="fa-solid fa-chevron-left" style="font-size:10px"></i></button>';
      for (var i = Math.max(1, r.page - 2); i <= Math.min(r.pages, r.page + 2); i++) h += '<button class="cp-pb' + (i === r.page ? ' on' : '') + '" onclick="cpLoadShipments(' + i + ')">' + i + '</button>';
      h += '<button class="cp-pb" onclick="cpLoadShipments(' + (r.page + 1) + ')" ' + (r.page >= r.pages ? 'disabled' : '') + '><i class="fa-solid fa-chevron-right" style="font-size:10px"></i></button>';
      h += '</div></div></div>';
      document.getElementById('cp-shipments-container').innerHTML = h;
      // Progressively update statuses with live real-time tracking
      cpUpdateLiveStatuses();
    });
  }

  // Progressive real-time status updates for visible shipments
  function cpUpdateLiveStatuses() {
    var rows = document.querySelectorAll('#cp-shipments-container table tbody tr[data-awb]');
    if (!rows.length) return;
    var queue = Array.from(rows);
    var active = 0;
    var maxConcurrent = 3;

    function processNext() {
      while (active < maxConcurrent && queue.length > 0) {
        var row = queue.shift();
        var awb = row.getAttribute('data-awb');
        if (!awb) continue;
        active++;
        (function(r, a) {
          cpAjax('pe_cp_track_status', { awb: a }, function(d) {
            active--;
            if (d.success && d.data) {
              // Dynamically update forwarding number in table row if returned by live tracking
              if (d.data.forwarding_number) {
                var fwdCell = r.children[1];
                if (fwdCell) {
                  var curFwdText = fwdCell.textContent.trim();
                  if (!curFwdText || curFwdText === '—' || curFwdText === '-') {
                    var rawFwd = String(d.data.forwarding_number).trim();
                    var fwdCopyBtn = ' <button type="button" class="cp-copy-btn" onclick="cpCopyText(\'' + rawFwd.replace(/'/g, "\\'") + '\', \'Forwarding Number\', event)" title="Copy Forwarding Number"><i class="fa-regular fa-copy"></i></button>';
                    var fwdHtml = '<div style="display:inline-flex;align-items:center;gap:5px;font-size:12px;font-weight:700;color:#1e40af;"><i class="fa-solid fa-plane-departure" style="font-size:9px;margin-right:2px;"></i><span>' + rawFwd + '</span>' + fwdCopyBtn + '</div>';
                    fwdCell.innerHTML = fwdHtml;
                  }
                }
              }

              if (d.data.status) {
                var statusCell = r.querySelector('.cp-status-cell');
                if (statusCell) {
                  var liveDelivered = Boolean(d.data.is_delivered);
                  var displayStatus = d.data.status || '';
                  var sLow = displayStatus.toLowerCase();
                  if (sLow.indexOf('deliver') >= 0 || sLow.indexOf('proof of delivery') >= 0 || sLow.indexOf('signed by') >= 0 || sLow === 'pod') {
                    liveDelivered = true;
                  }
                  var wasDelivered = r.getAttribute('data-delivered') === '1';
                  if (wasDelivered && !liveDelivered) {
                    liveDelivered = true;
                  }
                  var stDot = cpGetStatusDot(displayStatus, liveDelivered);
                  statusCell.innerHTML = '<div class="cp-st"><span class="cp-dot ' + stDot.dot + '"></span><span>' + stDot.label + '</span></div>';
                  if (liveDelivered) {
                    var wasAlreadyDel = r.getAttribute('data-delivered') === '1';
                    r.setAttribute('data-delivered', '1');
                    var elDel = document.getElementById('cp-stat-delivered');
                    if (elDel && !wasAlreadyDel) {
                      var curStat = parseInt((elDel.textContent || '0').replace(/,/g, '')) || 0;
                      elDel.textContent = Number(curStat + 1).toLocaleString('en-IN');
                    }
                  }
                }
              }
            }
            processNext();
          });
        })(row, awb);
      }
    }
    processNext();
  }

  function cpShowDetail(awb) {
    var panel = document.getElementById('cp-detail-panel');
    panel.innerHTML = '<div style="padding:40px;text-align:center"><div style="width:30px;height:30px;border:3px solid #e5e7eb;border-top-color:#bb0013;border-radius:50%;animation:cp-spin .6s linear infinite;margin:0 auto 16px"></div><p style="color:#94a3b8;font-size:14px">Loading shipment details...</p></div>';
    document.getElementById('cp-detail-overlay').classList.add('show');
    cpAjax('pe_cp_shipment_detail', { awb: awb }, function (d) {
      if (!d.success) { panel.innerHTML = '<div style="padding:40px;text-align:center;color:#dc2626">Failed to load details</div>'; return; }
      var s = d.data.shipment, tr = d.data.tracking || [];
      var stDot = cpGetStatusDot(s.status || (tr.length ? tr[0].activity : ''));
      var h = '';
      h += '<div class="cp-dh"><h3><i class="fa-solid fa-box"></i> AWB ' + s.awb + '</h3><button class="cp-dc" onclick="cpCloseDetail()"><i class="fa-solid fa-xmark"></i></button></div>';
      h += '<div class="cp-db-body">';
      h += '<div class="cp-ds"><h4><i class="fa-solid fa-circle-info"></i> Current Status</h4><div style="display:flex;align-items:center;gap:8px;padding:12px 16px;background:#f8fafc;border-radius:10px;border:1px solid #e2e8f0"><span class="cp-dot ' + stDot.dot + '" style="width:10px;height:10px"></span><span style="font-size:15px;font-weight:700;color:#0f172a">' + (s.status || stDot.label) + '</span></div></div>';
      h += '<div class="cp-ds"><h4><i class="fa-solid fa-box"></i> Shipment Details</h4><div class="cp-dg">';
      h += '<div class="cp-df"><div class="l">AWB Number</div><div class="v" style="font-weight:800;color:var(--cptext);display:flex;align-items:center;gap:8px;"><span>' + s.awb + '</span><button type="button" class="cp-copy-btn" onclick="cpCopyText(\'' + s.awb + '\', \'AWB\', event)" title="Copy AWB"><i class="fa-regular fa-copy"></i> Copy</button></div></div>';
      if (s.forwarding_number) {
        var rawFwd = String(s.forwarding_number).trim().replace(/^FWD\s*:\s*/i, '');
        var blockMatches = rawFwd.match(/\b\d{4}\s+\d{4}\s+\d{4}\s+[0-9A-Za-z]+\b/g);
        var fwdDisplay = (blockMatches && blockMatches.length > 1) ? blockMatches.join('<br>') : rawFwd;
        h += '<div class="cp-df"><div class="l">Forwarding Number</div><div class="v" style="font-weight:700;color:#1e40af;line-height:1.4;"><div style="display:flex;align-items:center;gap:8px;"><span>' + fwdDisplay + '</span><button type="button" class="cp-copy-btn" onclick="cpCopyText(\'' + rawFwd.replace(/'/g, "\\'") + '\', \'Forwarding Number\', event)" title="Copy Forwarding Number"><i class="fa-regular fa-copy"></i> Copy</button></div></div></div>';
      }
      h += '<div class="cp-df"><div class="l">Booking Date</div><div class="v">' + (s.date || '—') + '</div></div>';
      if (s.chargeable_weight) {
        h += '<div class="cp-df"><div class="l">Chargeable Weight</div><div class="v" style="font-weight:700;">' + s.chargeable_weight + ' kg</div></div>';
      }
      if (s.dimensions || (s.length && s.breadth && s.height)) {
        var dims = s.dimensions || (s.length + ' × ' + s.breadth + ' × ' + s.height + ' cm');
        h += '<div class="cp-df"><div class="l">Dimensions (L×B×H)</div><div class="v">' + dims + '</div></div>';
      }
      h += '<div class="cp-df"><div class="l">Pieces (Boxes)</div><div class="v">' + (s.pieces || '1') + '</div></div>';
      if (s.content_description) {
        h += '<div class="cp-df fl"><div class="l">Content Description</div><div class="v">' + s.content_description + '</div></div>';
      }
      if (s.amount) {
        h += '<div class="cp-df"><div class="l">Total Amount</div><div class="v" style="font-weight:800;color:var(--cpgreen)">₹' + Number(s.amount).toLocaleString('en-IN') + '</div></div>';
      }
      h += '</div></div>';

      // Invoice / Items Details Table
      var shpInvItems = s.invoice_items;
      if (typeof shpInvItems === 'string') {
        try { shpInvItems = JSON.parse(shpInvItems); } catch(e) { shpInvItems = []; }
      }
      // Fallback: extract nested items from parcels if invoice_items is empty
      if ((!shpInvItems || !shpInvItems.length) && s.parcels && Array.isArray(s.parcels)) {
        shpInvItems = [];
        s.parcels.forEach(function(prc, pIdx) {
          if (prc.items && Array.isArray(prc.items)) {
            prc.items.forEach(function(pi) {
              pi.box_no = pi.box_no || prc.box_no || (pIdx + 1);
              shpInvItems.push(pi);
            });
          }
        });
      }
      if (shpInvItems && Array.isArray(shpInvItems) && shpInvItems.length > 0) {
        h += '<div class="cp-ds"><h4><i class="fa-solid fa-boxes-packing"></i> Items Details (' + shpInvItems.length + ')</h4>';
        h += '<div style="overflow-x:auto; border:1px solid var(--cpbdr); border-radius:10px;">';
        h += '<table style="width:100%; border-collapse:collapse; font-size:12px;">';
        h += '<thead><tr style="background:var(--cpbg2); border-bottom:1px solid var(--cpbdr);">';
        h += '<th style="padding:8px 10px; text-align:left; font-size:9px; font-weight:800; color:var(--cptext3); text-transform:uppercase; letter-spacing:.5px;">#</th>';
        h += '<th style="padding:8px 10px; text-align:left; font-size:9px; font-weight:800; color:var(--cptext3); text-transform:uppercase; letter-spacing:.5px;">Box</th>';
        h += '<th style="padding:8px 10px; text-align:left; font-size:9px; font-weight:800; color:var(--cptext3); text-transform:uppercase; letter-spacing:.5px;">Description</th>';
        h += '<th style="padding:8px 10px; text-align:left; font-size:9px; font-weight:800; color:var(--cptext3); text-transform:uppercase; letter-spacing:.5px;">Qty</th>';
        h += '</tr></thead><tbody>';
        shpInvItems.forEach(function (item, i) {
          h += '<tr style="border-bottom:1px solid rgba(0,0,0,.05);">';
          h += '<td style="padding:8px 10px; color:var(--cptext3);">' + (item.sr_no || (i + 1)) + '</td>';
          h += '<td style="padding:8px 10px; color:var(--cptext2);">' + (item.box_no || '—') + '</td>';
          h += '<td style="padding:8px 10px; font-weight:600; color:var(--cptext1); max-width:180px; overflow:hidden; text-overflow:ellipsis; white-space:nowrap;">' + (item.description || item.item_name || item.name || '—') + '</td>';
          h += '<td style="padding:8px 10px; color:var(--cptext2);">' + (item.quantity || item.qty || '—') + ' ' + (item.unit_type || item.unit || '') + '</td>';
          h += '</tr>';
        });
        h += '</tbody></table></div></div>';
      }

      // Sender & Receiver Route and Address Details
      h += '<div class="cp-ds"><h4><i class="fa-solid fa-location-dot"></i> Route & Address Information</h4><div class="cp-dg">';
      h += '<div class="cp-df fl"><div class="l">Shipper (Sender)</div><div class="v" style="font-weight:700;">' + (s.shipper || '—') + (s.shipper_phone ? ' (' + s.shipper_phone + ')' : '') + '<div style="font-size:12px;font-weight:500;color:var(--cptext2);margin-top:2px;">' + (s.shipper_address || cpGetFullCountryName(s.origin || '') || '—') + '</div></div></div>';
      h += '<div class="cp-df fl"><div class="l">Consignee (Receiver)</div><div class="v" style="font-weight:700;">' + (s.consignee || '—') + (s.consignee_phone ? ' (' + s.consignee_phone + ')' : '') + '<div style="font-size:12px;font-weight:500;color:var(--cptext2);margin-top:2px;">' + (s.consignee_address || cpGetFullCountryName(s.destination || '') || '—') + '</div></div></div>';
      h += '</div></div>';

      // Official Box Labels & Shipping Documents
      var shpLabelUrl = 'https://purple-raccoon-753399.hostingersite.com/api/customer/labels-pdf/' + encodeURIComponent(s.awb);
      var shpWaybillUrl = 'https://purple-raccoon-753399.hostingersite.com/api/customer/waybill-pdf/' + encodeURIComponent(s.awb);

      h += '<div class="cp-ds"><h4><i class="fa-solid fa-tags"></i> Official Labels & Documents</h4>';
      h += '<div style="display:flex; gap:8px; flex-wrap:wrap; margin-top:6px;">';
      h += '  <a href="' + shpLabelUrl + '" target="_blank" rel="noopener noreferrer" download style="display:inline-flex; align-items:center; gap:6px; background:#ebf5ff; color:#1e40af; border:1px solid #bfdbfe; padding:8px 14px; border-radius:8px; font-size:12px; font-weight:700; text-decoration:none;"><i class="fa-solid fa-tag"></i> Download Box Label</a>';
      h += '  <a href="' + shpWaybillUrl + '" target="_blank" rel="noopener noreferrer" download style="display:inline-flex; align-items:center; gap:6px; background:#f0fdf4; color:#166534; border:1px solid #bbf7d0; padding:8px 14px; border-radius:8px; font-size:12px; font-weight:700; text-decoration:none;"><i class="fa-solid fa-file-invoice-dollar"></i> Download Shipping Bill</a>';
      h += '</div></div>';

      h += '<div class="cp-ds"><h4><i class="fa-solid fa-route"></i> Tracking History</h4>';
      if (tr.length) {
        h += '<ul class="cp-tl">';
        tr.forEach(function (t, i) {
          h += '<li style="animation-delay:' + (.03 * i) + 's"><div class="cp-tl-card"><div class="cp-tla"><i class="fa-solid ' + (i === 0 ? 'fa-circle-check' : 'fa-circle-dot') + '"></i>' + t.activity + '</div><div class="cp-tlm"><i class="fa-solid fa-calendar"></i> ' + t.date + ' ' + t.time + (t.location ? ' &nbsp;·&nbsp; <i class="fa-solid fa-location-dot"></i> ' + t.location : '') + '</div></div></li>';
        });
        h += '</ul>';
      } else {
        h += '<div class="cp-tl-empty"><i class="fa-solid fa-route"></i><p>No tracking events yet</p></div>';
      }
      h += '</div></div>';
      panel.innerHTML = h;
    });
  }

  function cpCloseDetail() {
    document.getElementById('cp-detail-overlay').classList.remove('show');
    cpDetailOpenAwb = null;
    cpDetailLastHash = null;
    cpStopDetailPolling();
  }

  // listen to iframe events (e.g. successful booking or cancelled back click)
  window.addEventListener('message', function (event) {
    if (event.data && event.data.type === 'PE_GO_BACK') {
      cpSwitchTab('shipments', document.querySelectorAll('.cp-nav-item')[0]);
    }
    if (event.data && event.data.type === 'PE_BOOKING_SUCCESS') {
      cpLoadRequests(1); // refresh requests list
      // Switch to requests tab after brief delay
      setTimeout(function () {
        cpSwitchTab('requests');
      }, 1500);
    }
  });

  // Profile update form handler
  document.getElementById('cp-profile-form').addEventListener('submit', function (e) {
    e.preventDefault();
    var btn = document.getElementById('profile-submit');
    btn.disabled = true; btn.textContent = 'Saving...';
    cpAjax('pe_cp_update_profile', {
      name: document.getElementById('profile-name').value,
      email: document.getElementById('profile-email').value,
      phone: document.getElementById('profile-phone').value,
      company: document.getElementById('profile-company').value
    }, function (res) {
      btn.disabled = false; btn.textContent = 'Save Changes';
      if (res.success) {
        alert('Profile updated successfully!');
        document.getElementById('cp-sidebar-uname').textContent = res.data.user.name;
        document.getElementById('cp-welcome-uname').textContent = res.data.user.name;
      } else {
        alert(res.data.message || 'Failed to update profile');
      }
    });
  });

  // Password change form handler
  document.getElementById('cp-password-form').addEventListener('submit', function (e) {
    e.preventDefault();
    var pass = document.getElementById('pass-new').value;
    var confirm = document.getElementById('pass-confirm').value;
    if (pass !== confirm) {
      alert("New passwords do not match!");
      return;
    }
    var btn = document.getElementById('password-submit');
    btn.disabled = true; btn.textContent = 'Updating...';
    cpAjax('pe_cp_update_password', {
      current_pwd: document.getElementById('pass-current').value,
      new_pwd: pass
    }, function (res) {
      btn.disabled = false; btn.textContent = 'Update Password';
      if (res.success) {
        alert('Password updated successfully!');
        document.getElementById('cp-password-form').reset();
      } else {
        alert(res.data.message || 'Failed to update password');
      }
    });
  });

  // ══════════════════════════════════════
  //  AUTO-POLLING ENGINE (Real-Time Updates)
  // ══════════════════════════════════════
  var cpReqLastHash = null;
  var cpDetailOpenAwb = null;
  var cpDetailLastHash = null;
  var cpReqPollTimer = null;
  var cpDetailPollTimer = null;
  var cpActiveTab = 'shipments';
  var CP_REQ_POLL_MS = 15000;  // 15 seconds
  var CP_DETAIL_POLL_MS = 10000; // 10 seconds

  function cpStartReqPolling() {
    cpStopReqPolling();
    cpReqPollTimer = setInterval(function () {
      if (document.hidden) return; // skip if tab not visible
      cpLoadRequests(cpReqPage, true); // silent refresh
    }, CP_REQ_POLL_MS);
    cpUpdateLiveBadge(true);
  }

  function cpStopReqPolling() {
    if (cpReqPollTimer) { clearInterval(cpReqPollTimer); cpReqPollTimer = null; }
    cpUpdateLiveBadge(false);
  }

  function cpStartDetailPolling() {
    cpStopDetailPolling();
    if (!cpDetailOpenAwb) return;
    cpDetailPollTimer = setInterval(function () {
      if (document.hidden) return;
      if (!cpDetailOpenAwb) { cpStopDetailPolling(); return; }
      cpRenderRequestDetail(cpDetailOpenAwb, true);
    }, CP_DETAIL_POLL_MS);
  }

  function cpStopDetailPolling() {
    if (cpDetailPollTimer) { clearInterval(cpDetailPollTimer); cpDetailPollTimer = null; }
  }

  function cpUpdateLiveBadge(active) {
    var badge = document.getElementById('cp-live-badge');
    if (badge) {
      badge.classList.toggle('paused', !active);
    }
  }

  // Hook into tab switching to start/stop polling & load data
  var _origCpSwitchTab = cpSwitchTab;
  cpSwitchTab = function (tabId, btn) {
    _origCpSwitchTab(tabId, btn);
    cpActiveTab = tabId;
    if (tabId === 'requests') {
      cpStartReqPolling();
    } else if (tabId === 'addresses') {
      cpStopReqPolling();
      cpLoadAddresses();
    } else if (tabId === 'new-booking') {
      cpStopReqPolling();
      cpSyncAddressesToIframe();
    } else if (tabId === 'documents') {
      cpStopReqPolling();
      cpLoadDocuments();
    } else {
      cpStopReqPolling();
      cpReqLastHash = null;
    }
  };

  // ══════════════════════════════════════
  //  ADDRESS BOOK CONTROLLER
  // ══════════════════════════════════════
  var cpSavedAddresses = [];
  var cpAddrFilter = 'all';

  function cpSyncAddressesToIframe() {
    var iframe = document.getElementById('pe-booking-iframe');
    if (iframe && iframe.contentWindow) {
      if (cpSavedAddresses && cpSavedAddresses.length > 0) {
        iframe.contentWindow.postMessage({ type: 'PE_SAVED_ADDRESSES', addresses: cpSavedAddresses }, '*');
      } else {
        cpAjax('pe_cp_get_addresses', {}, function (res) {
          if (res.success && res.data?.addresses) {
            cpSavedAddresses = res.data.addresses;
            if (iframe && iframe.contentWindow) {
              iframe.contentWindow.postMessage({ type: 'PE_SAVED_ADDRESSES', addresses: cpSavedAddresses }, '*');
            }
          }
        });
      }
    }
  }

  // Listen for iframe requests for saved addresses
  window.addEventListener('message', function (e) {
    if (e.data && e.data.type === 'PE_REQUEST_SAVED_ADDRESSES') {
      cpSyncAddressesToIframe();
    }
  });

  function cpSetAddrFilter(filter, btn) {
    cpAddrFilter = filter;
    document.querySelectorAll('.cp-addr-filter').forEach(function (b) { b.classList.remove('active'); });
    if (btn) btn.classList.add('active');
    cpRenderAddresses();
  }

  function cpLoadAddresses() {
    var c = document.getElementById('cp-addresses-container');
    if (!c) return;
    cpAjax('pe_cp_get_addresses', {}, function (res) {
      if (!res.success) {
        c.innerHTML = '<div style="padding:40px;text-align:center;color:#dc2626;">Failed to load addresses.</div>';
        return;
      }
      cpSavedAddresses = res.data.addresses || [];
      cpRenderAddresses();
      cpSyncAddressesToIframe();
    });
  }

  function cpRenderAddresses() {
    var c = document.getElementById('cp-addresses-container');
    if (!c) return;

    // Filter addresses (Sender shows sender & both, Receiver shows receiver & both)
    var filtered = cpSavedAddresses;
    if (cpAddrFilter !== 'all') {
      filtered = cpSavedAddresses.filter(function (a) {
        var rawType = (a.address_type || 'both').toLowerCase();
        if (cpAddrFilter === 'sender') {
          return rawType === 'sender' || rawType === 'both';
        }
        if (cpAddrFilter === 'receiver') {
          return rawType === 'receiver' || rawType === 'both';
        }
        if (cpAddrFilter === 'both') {
          return rawType === 'both';
        }
        return rawType === cpAddrFilter;
      });
    }

    if (!filtered.length) {
      var emptyMsg = cpSavedAddresses.length ? 'No <strong>' + cpAddrFilter + '</strong> addresses found.' : 'Save your pickup and delivery contacts here to quickly autofill them when creating shipments.';
      var emptyTitle = cpSavedAddresses.length ? 'No Matching Addresses' : 'No Saved Addresses';
      c.innerHTML = '<div style="background:var(--cpcard); border-radius:16px; border:1px dashed var(--cpbdr); padding:48px 24px; text-align:center;">' +
        '<div style="width:48px; height:48px; border-radius:12px; background:rgba(187,0,19,0.08); color:var(--cpred); display:flex; align-items:center; justify-content:center; margin:0 auto 12px; font-size:20px;"><i class="fa-solid fa-address-book"></i></div>' +
        '<h3 style="font-size:16px; font-weight:800; color:var(--cptext); margin:0 0 6px;">' + emptyTitle + '</h3>' +
        '<p style="font-size:13px; color:var(--cptext2); margin:0 0 16px;">' + emptyMsg + '</p>' +
        '<div style="display:flex; gap:8px; justify-content:center; flex-wrap:wrap;">' +
        '<button onclick="cpOpenAddressModal(null, \'sender\')" style="border:none; cursor:pointer; padding:9px 18px; border-radius:10px; background:linear-gradient(135deg,#1e40af,#3b82f6); color:#fff; font-weight:700; font-size:13px;"><i class="fa-solid fa-arrow-up-from-bracket"></i> Add Sender</button>' +
        '<button onclick="cpOpenAddressModal(null, \'receiver\')" style="border:none; cursor:pointer; padding:9px 18px; border-radius:10px; background:linear-gradient(135deg,#047857,#10b981); color:#fff; font-weight:700; font-size:13px;"><i class="fa-solid fa-arrow-down-to-bracket"></i> Add Receiver</button>' +
        '</div></div>';
      return;
    }

    var h = '<div style="display:grid; grid-template-columns:repeat(auto-fill, minmax(320px, 1fr)); gap:16px;">';
    filtered.forEach(function (a) {
      var rawType = (a.address_type || 'both').toLowerCase();
      var typeColors = { sender: { bg: 'rgba(59,130,246,0.08)', color: '#1e40af', border: 'rgba(59,130,246,0.2)' }, receiver: { bg: 'rgba(16,185,129,0.08)', color: '#047857', border: 'rgba(16,185,129,0.2)' }, both: { bg: 'rgba(245,158,11,0.08)', color: '#92400e', border: 'rgba(245,158,11,0.2)' } };
      var tc = typeColors[rawType] || typeColors.both;
      var typeIcon = rawType === 'sender' ? 'fa-arrow-up-from-bracket' : rawType === 'receiver' ? 'fa-arrow-down-to-bracket' : 'fa-arrows-left-right';
      var typeBadge = '<span style="background:' + tc.bg + '; color:' + tc.color + '; padding:3px 8px; border-radius:6px; font-size:10px; font-weight:800; text-transform:uppercase; display:inline-flex; align-items:center; gap:4px;"><i class="fa-solid ' + typeIcon + '" style="font-size:9px;"></i>' + (a.address_type || 'BOTH') + '</span>';
      if (a.is_default) {
        typeBadge += ' <span style="background:#ecfdf5; color:#059669; padding:3px 8px; border-radius:6px; font-size:10px; font-weight:800; text-transform:uppercase;">DEFAULT</span>';
      }
      h += '<div style="background:var(--cpcard); border-radius:16px; border:1px solid var(--cpbdr); border-left:4px solid ' + tc.color + '; padding:20px; box-shadow:var(--cpsh); display:flex; flex-direction:column; justify-content:space-between; transition:all .2s;" onmouseenter="this.style.transform=\'translateY(-2px)\';this.style.boxShadow=\'var(--cpsh2)\'" onmouseleave="this.style.transform=\'none\';this.style.boxShadow=\'var(--cpsh)\'">';
      h += '<div>';
      h += '<div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:10px;">' + typeBadge + '<div style="display:flex; gap:6px;">' +
        '<button onclick="cpEditAddress(' + a.id + ')" title="Edit" style="border:none; background:rgba(0,0,0,0.04); width:28px; height:28px; border-radius:6px; color:var(--cptext2); cursor:pointer; transition:all .15s;" onmouseenter="this.style.background=\'rgba(59,130,246,0.1)\';this.style.color=\'#1e40af\'" onmouseleave="this.style.background=\'rgba(0,0,0,0.04)\';this.style.color=\'var(--cptext2)\'"><i class="fa-solid fa-pen" style="font-size:11px;"></i></button>' +
        '<button onclick="cpDeleteAddress(' + a.id + ')" title="Delete" style="border:none; background:rgba(220,38,38,0.08); width:28px; height:28px; border-radius:6px; color:#dc2626; cursor:pointer; transition:all .15s;" onmouseenter="this.style.background=\'rgba(220,38,38,0.15)\'" onmouseleave="this.style.background=\'rgba(220,38,38,0.08)\'"><i class="fa-solid fa-trash" style="font-size:11px;"></i></button>' +
        '</div></div>';
      h += '<h4 style="font-size:15px; font-weight:800; color:var(--cptext); margin:0 0 2px;">' + (a.name || '—') + '</h4>';
      if (a.company) h += '<div style="font-size:12px; font-weight:600; color:var(--cpred); margin-bottom:8px; text-transform:uppercase;">' + a.company + '</div>';
      h += '<div style="font-size:13px; color:var(--cptext2); line-height:1.4; margin-bottom:12px;">' + (a.address || '') + (a.address_2 ? ', ' + a.address_2 : '') + '<br><strong>' + (a.city || '') + '</strong>' + (a.state ? ', ' + a.state : '') + (a.pincode ? ' - ' + a.pincode : '') + '<br><span style="font-weight:700; color:var(--cptext);">' + cpGetFullCountryName(a.country || 'INDIA') + '</span></div>';
      h += '</div>';
      h += '<div style="border-top:1px solid var(--cpbdr); padding-top:10px; font-size:12px; color:var(--cptext2); display:flex; flex-direction:column; gap:4px;">';
      if (a.phone) h += '<div><i class="fa-solid fa-phone" style="width:14px; margin-right:6px; color:var(--cptext3);"></i>' + a.phone + (a.phone_2 ? ' / ' + a.phone_2 : '') + '</div>';
      if (a.email) h += '<div><i class="fa-solid fa-envelope" style="width:14px; margin-right:6px; color:var(--cptext3);"></i>' + a.email + '</div>';
      if (a.gstin_no) h += '<div><i class="fa-solid fa-id-card" style="width:14px; margin-right:6px; color:var(--cptext3);"></i>' + (a.gstin_type ? a.gstin_type + ': ' : '') + a.gstin_no + '</div>';
      h += '</div>';
      h += '</div>';
    });
    h += '</div>';
    c.innerHTML = h;
  }

  function cpOpenAddressModal(addr, presetType) {
    document.getElementById('cp-address-form').reset();
    document.getElementById('addr-id').value = addr ? addr.id : '';
    var titleIcon, titleText;
    if (addr) {
      titleIcon = 'fa-pen'; titleText = 'Edit Address';
    } else if (presetType === 'sender') {
      titleIcon = 'fa-arrow-up-from-bracket'; titleText = 'Add Sender Address';
    } else if (presetType === 'receiver') {
      titleIcon = 'fa-arrow-down-to-bracket'; titleText = 'Add Receiver Address';
    } else {
      titleIcon = 'fa-address-book'; titleText = 'Add New Address';
    }
    document.getElementById('cp-addr-modal-title').innerHTML = '<i class="fa-solid ' + titleIcon + '" style="color:var(--cpred); margin-right:8px;"></i> ' + titleText;
    if (addr) {
      document.getElementById('addr-type').value = addr.address_type || 'both';
      document.getElementById('addr-name').value = addr.name || '';
      document.getElementById('addr-company').value = addr.company || '';
      document.getElementById('addr-phone').value = addr.phone || '';
      document.getElementById('addr-phone2').value = addr.phone_2 || '';
      document.getElementById('addr-email').value = addr.email || '';
      document.getElementById('addr-line1').value = addr.address || '';
      document.getElementById('addr-line2').value = addr.address_2 || '';
      document.getElementById('addr-city').value = addr.city || '';
      document.getElementById('addr-state').value = addr.state || '';
      document.getElementById('addr-pincode').value = addr.pincode || '';
      document.getElementById('addr-country').value = cpGetFullCountryName(addr.country) || 'INDIA';
      document.getElementById('addr-gstin').value = addr.gstin_no || '';
    } else if (presetType) {
      document.getElementById('addr-type').value = presetType;
    }
    document.getElementById('cp-addr-modal-overlay').classList.add('show');
  }

  function cpCloseAddressModal() {
    document.getElementById('cp-addr-modal-overlay').classList.remove('show');
  }

  function cpEditAddress(id) {
    var addr = cpSavedAddresses.find(a => a.id == id);
    if (addr) cpOpenAddressModal(addr);
  }

  function cpHandleAddressSubmit(e) {
    e.preventDefault();
    var btn = document.getElementById('addr-submit-btn');
    btn.disabled = true; btn.textContent = 'Saving...';
    var payload = {
      id: document.getElementById('addr-id').value,
      address_type: document.getElementById('addr-type').value,
      name: document.getElementById('addr-name').value,
      company: document.getElementById('addr-company').value,
      phone: document.getElementById('addr-phone').value,
      phone_2: document.getElementById('addr-phone2').value,
      email: document.getElementById('addr-email').value,
      address: document.getElementById('addr-line1').value,
      address_2: document.getElementById('addr-line2').value,
      city: document.getElementById('addr-city').value,
      state: document.getElementById('addr-state').value,
      pincode: document.getElementById('addr-pincode').value,
      country: cpGetFullCountryName(document.getElementById('addr-country').value) || document.getElementById('addr-country').value.replace(/[-–—]/g, '').trim() || 'INDIA',
      gstin_no: document.getElementById('addr-gstin').value
    };
    cpAjax('pe_cp_save_address', payload, function (res) {
      btn.disabled = false; btn.textContent = 'Save Address';
      if (res.success) {
        cpCloseAddressModal();
        cpLoadAddresses();
        cpShowToast('success', 'Address Saved', res.data?.message || 'Address saved successfully!');
        var iframe = document.getElementById('pe-booking-iframe');
        if (iframe && iframe.contentWindow && res.data?.address) {
          iframe.contentWindow.postMessage({ type: 'PE_ADDRESS_SAVED', address: res.data.address }, '*');
        }
      } else {
        cpShowToast('error', 'Save Failed', res.data?.message || 'Failed to save address');
      }
    });
  }

  function cpDeleteAddress(id) {
    if (!confirm('Are you sure you want to delete this address?')) return;
    cpAjax('pe_cp_delete_address', { id: id }, function (res) {
      if (res.success) {
        cpLoadAddresses();
        cpShowToast('success', 'Address Deleted', res.data?.message || 'Address deleted');
      } else {
        cpShowToast('error', 'Delete Failed', res.data?.message || 'Failed to delete address');
      }
    });
  }

  // ══════════════════════════════════════
  //  DOCUMENTS & KYC CONTROLLER
  // ══════════════════════════════════════
  var cpSavedDocs = [];

  function cpLoadDocuments() {
    var c = document.getElementById('cp-documents-container');
    if (!c) return;
    cpAjax('pe_cp_get_documents', {}, function (res) {
      if (!res.success) {
        c.innerHTML = '<div style="padding:40px;text-align:center;color:#dc2626;">Failed to load documents.</div>';
        return;
      }
      cpSavedDocs = res.data.documents || [];
      cpRenderDocuments();
    });
  }

  function cpRenderDocuments() {
    var c = document.getElementById('cp-documents-container');
    if (!c) return;
    if (!cpSavedDocs.length) {
      c.innerHTML = '<div style="background:var(--cpcard); border-radius:16px; border:1px dashed var(--cpbdr); padding:48px 24px; text-align:center;">' +
        '<div style="width:48px; height:48px; border-radius:12px; background:rgba(187,0,19,0.08); color:var(--cpred); display:flex; align-items:center; justify-content:center; margin:0 auto 12px; font-size:20px;"><i class="fa-solid fa-file-shield"></i></div>' +
        '<h3 style="font-size:16px; font-weight:800; color:var(--cptext); margin:0 0 6px;">No Documents Uploaded Yet</h3>' +
        '<p style="font-size:13px; color:var(--cptext2); margin:0;">Upload your KYC documents or invoices above to save them securely for all future courier bookings.</p>' +
        '</div>';
      return;
    }

    var h = '<div style="display:grid; grid-template-columns:repeat(auto-fill, minmax(300px, 1fr)); gap:16px;">';
    cpSavedDocs.forEach(function (d) {
      var sizeKb = d.file_size ? Math.round(d.file_size / 1024) + ' KB' : '';
      h += '<div style="background:var(--cpcard); border-radius:16px; border:1px solid var(--cpbdr); padding:20px; box-shadow:var(--cpsh); display:flex; flex-direction:column; justify-content:space-between;">';
      h += '<div>';
      h += '<div style="display:flex; justify-content:space-between; align-items:flex-start; margin-bottom:12px;">';
      h += '<div style="display:flex; align-items:center; gap:10px;">';
      h += '<div style="width:36px; height:36px; border-radius:10px; background:rgba(187,0,19,0.08); color:var(--cpred); display:flex; align-items:center; justify-content:center; font-size:16px;"><i class="fa-solid fa-file-lines"></i></div>';
      h += '<div>';
      h += '<div style="font-size:14px; font-weight:800; color:var(--cptext);">' + (d.doc_name || d.file_name || d.doc_type) + '</div>';
      h += '<span style="background:rgba(0,0,0,0.05); color:var(--cptext2); padding:2px 6px; border-radius:4px; font-size:10px; font-weight:700; text-transform:uppercase;">' + d.doc_type + '</span>';
      h += '</div></div>';
      h += '<button onclick="cpDeleteDocument(' + d.id + ')" title="Delete" style="border:none; background:rgba(220,38,38,0.08); width:28px; height:28px; border-radius:6px; color:#dc2626; cursor:pointer;"><i class="fa-solid fa-trash" style="font-size:11px;"></i></button>';
      h += '</div>';

      if (d.doc_number) {
        h += '<div style="font-size:12px; color:var(--cptext2); margin-bottom:8px;"><strong>Doc No:</strong> ' + d.doc_number + '</div>';
      }
      h += '</div>';

      h += '<div style="border-top:1px solid var(--cpbdr); padding-top:10px; display:flex; justify-content:space-between; align-items:center;">';
      h += '<span style="font-size:11px; color:var(--cptext3); font-weight:600;">' + (sizeKb ? sizeKb + ' · ' : '') + (d.created_at ? d.created_at.substring(0, 10) : '') + '</span>';
      if (d.file_url) {
        h += '<a href="' + d.file_url + '" target="_blank" rel="noopener noreferrer" download style="font-size:12px; font-weight:700; color:var(--cpred); text-decoration:none; display:inline-flex; align-items:center; gap:4px;"><i class="fa-solid fa-arrow-up-right-from-square" style="font-size:10px;"></i> View / Download</a>';
      }
      h += '</div>';
      h += '</div>';
    });
    h += '</div>';
    c.innerHTML = h;
  }

  function cpHandleDocUpload(e) {
    e.preventDefault();
    var fileInput = document.getElementById('doc-upload-file');
    if (!fileInput.files || !fileInput.files[0]) {
      alert('Please choose a file to upload');
      return;
    }
    var btn = document.getElementById('doc-upload-btn');
    btn.disabled = true; btn.innerHTML = '<i class="fa-solid fa-spinner fa-spin"></i> Uploading...';

    var formData = new FormData();
    formData.append('action', 'pe_cp_upload_document');
    formData.append('nonce', PE_CP.nonce);
    formData.append('file', fileInput.files[0]);
    formData.append('doc_type', document.getElementById('doc-upload-type').value);
    formData.append('doc_name', document.getElementById('doc-upload-name').value);
    formData.append('doc_number', document.getElementById('doc-upload-number').value);

    fetch(PE_CP.ajax_url, {
      method: 'POST',
      body: formData
    })
      .then(r => r.json())
      .then(res => {
        btn.disabled = false; btn.innerHTML = '<i class="fa-solid fa-arrow-up-from-bracket"></i> Upload & Save Document';
        if (res.success) {
          document.getElementById('cp-doc-upload-form').reset();
          cpLoadDocuments();
        } else {
          alert(res.data?.message || 'Upload failed');
        }
      })
      .catch(err => {
        btn.disabled = false; btn.innerHTML = '<i class="fa-solid fa-arrow-up-from-bracket"></i> Upload & Save Document';
        alert('Upload error: ' + err.message);
      });
  }

  function cpDeleteDocument(id) {
    if (!confirm('Are you sure you want to delete this document?')) return;
    cpAjax('pe_cp_delete_document', { id: id }, function (res) {
      if (res.success) {
        cpLoadDocuments();
      } else {
        alert(res.data?.message || 'Failed to delete document');
      }
    });
  }

  // Pause/resume polling on tab visibility change
  document.addEventListener('visibilitychange', function () {
    if (document.hidden) {
      cpUpdateLiveBadge(false);
    } else {
      if (cpActiveTab === 'requests') {
        cpUpdateLiveBadge(true);
        cpLoadRequests(cpReqPage, true); // immediate refresh on return
      }
      if (cpDetailOpenAwb) {
        cpRenderRequestDetail(cpDetailOpenAwb, true);
      }
    }
  });

  // ══════════════════════════════════════
  //  MOBILE SIDEBAR SLIDE MENU
  // ══════════════════════════════════════
  function cpToggleMobileSidebar() {
    var sidebar = document.getElementById('cp-sidebar');
    var overlay = document.getElementById('cp-sidebar-overlay');
    sidebar.classList.add('open');
    overlay.classList.add('show');
    document.body.style.overflow = 'hidden';
  }

  function cpCloseMobileSidebar() {
    var sidebar = document.getElementById('cp-sidebar');
    var overlay = document.getElementById('cp-sidebar-overlay');
    sidebar.classList.remove('open');
    overlay.classList.remove('show');
    document.body.style.overflow = '';
  }

  // ══════════════════════════════════════
  //  DESKTOP SIDEBAR COLLAPSE
  // ══════════════════════════════════════
  function cpToggleSidebarCollapse() {
    var sidebar = document.getElementById('cp-sidebar');
    var icon = document.getElementById('cp-collapse-icon');
    var isCollapsed = sidebar.classList.toggle('collapsed');
    if (icon) {
      icon.className = isCollapsed ? 'fa-solid fa-angles-right' : 'fa-solid fa-angles-left';
    }
    try { localStorage.setItem('pe_cp_sidebar_collapsed', isCollapsed ? '1' : '0'); } catch(e) {}
  }

  // Auto-restore collapsed state on desktop
  (function() {
    try {
      if (window.innerWidth > 960 && localStorage.getItem('pe_cp_sidebar_collapsed') === '1') {
        var sidebar = document.getElementById('cp-sidebar');
        var icon = document.getElementById('cp-collapse-icon');
        if (sidebar) sidebar.classList.add('collapsed');
        if (icon) icon.className = 'fa-solid fa-angles-right';
      }
    } catch(e) {}
  })();

  // Init
  cpLoadShipments(1);
</script>